<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>腾讯微博</title>
<meta name="keywords" content="微博,腾讯微博,QQ微博,围脖,QQ围脖,腾讯围脖,企鹅微博,企鹅围脖,名人微博,名人围脖,微型博客"/>
<meta name="description" content="腾讯微博，与其在别处仰望 不如在这里并肩"/>
<?php require_once 'config.view.php';?>
<style type="text/css">
body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,p,blockquote,th,td{margin:0;padding:0}
table{border-collapse:collapse;border-spacing:0}
fieldset,img{border:0}
address,caption,cite,code,dfn,em,strong,th,var{font-style:normal;font-weight:normal}
ol,ul{list-style:none}
caption,th{text-align:left}
h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:normal}
q:before,q:after{content:''}
body{height:100%;font:bold 18px/2 "MicroSoft YaHei",Arial;color:#333;background:#CCE6E9 url(http://mat1.gtimg.com/www/mb/images/wbWall/kldby/kldbyBg1c.jpg) center top no-repeat;overflow:hidden}
input,button,select,textarea{outline:none;resize:none}
strong{font-weight:800}
a{color:#333;text-decoration:none}
a:focus{outline:none}
.header{width:768px;height:86px;margin:0 auto;position:relative}
#logo{position:absolute;top:36px;right:172px;width:178px;height:50px;overflow:hidden;background:url(http://mat1.gtimg.com/www/mb/images/wbWall/kldby/kldbyBg2a.png) no-repeat;cursor:pointer}
#logo a,.sideLogo,.btn_ctrl{display:block;line-height:20em;overflow:hidden}
.topSide{position:absolute;top:24px;right:-7px;width:151px;height:60px}
.content{position:relative;width:742px;height:533px;margin:0 auto;padding:54px 13px 13px;background:url(http://mat1.gtimg.com/www/mb/images/wbWall/kldby/kldbyBg5.png) no-repeat;-webkit-border-radius:13px;-webkit-box-shadow:2px 2px 7px rgba(143,143,143,0.7)}
.content:after{content:" ";position:absolute;width:742px;height:573px;top:14px;left:13px;background:-webkit-gradient(linear,0 6%,0 100%,from(#E6E6E6),to(#fff),color-stop(0.49,#fff),color-stop(0.5,#F8F8F8),color-stop(0.57,#EBEBEB),color-stop(0.58,#D9D9D9),color-stop(0.65,#E0E0E0))}
.rateList{position:relative;z-index:2;width:690px;margin:0 auto}
.rateList td{height:495px;text-align:center;vertical-align:bottom}
.userPic{width:115px;height:180px;margin:30px auto 0;overflow:hidden;white-space:nowrap}
.userPic img{display:block;width:100px;height:100px;margin:0 auto;padding:2px;border:1px solid #C0C0C0;background:#A3A3A3}
.userPic span{font:bold 28px/1 Arial,Verdana,sans-serif}
.rateWrap{position:relative;width:60%;height:270px;margin:0 auto}
.rateWrap div{position:absolute;width:100%}.rateBox{bottom:0}
.tface{z-index:3;height:20px;top:-10px;-webkit-border-radius:50%;font:bold 40px/1 Arial,Verdana,sans-serif}.rateName{position:absolute;top:-36px}
.mface{z-index:2;bottom:0;height:100%}
.bface{z-index:1;height:20px;bottom:-10px;-webkit-border-radius:50%;-webkit-box-shadow:8px -2px 10px #333}
.c1 .tface{background:#3B9EA8;color:#035A62}.c1 .mface,.c1 .bface{background:#0B8591}
.c2 .tface{background:#D1A054;color:#573604}.c2 .mface,.c2 .bface{background:#CE8009}
.c3 .tface{background:#B6C547;color:#454E02}.c3 .mface,.c3 .bface{background:#96A811}
.c4 .tface{background:#DC67AB;color:#540332}.c4 .mface,.c4 .bface{background:#CF1481}
.c5 .tface{background:#B5AEF5;color:#313058}.c5 .mface,.c5 .bface{background:#817FB8}
.c6 .tface{background:#58C2DA;color:#01404E}.c6 .mface,.c6 .bface{background:#14A9CA}
.pageNav{position:absolute;z-index:2;right:20px;bottom:20px;width:122px;height:30px;}
.btn_ctrl{width:122px;height:30px;background:url(http://mat1.gtimg.com/www/mb/images/wbWall/kldby/kldbyBtn1a.png) no-repeat}.disabled{background-position:-127px 0}
</style>
</head>

<body>
<div class="header">
	<h1 id="logo"><a href="/" title="t.qq.com">腾讯微博</a></h1>
	<div class="topSide"><p class="sideLogo"><img src="http://mat1.gtimg.com/www/mb/images/wbWall/kldby/kldbyImg1a.png" alt="快乐大本营" /></p></div>
</div>
<div class="content"><table border="0" cellspacing="0" cellpadding="0" class="rateList" id="voteList"></table>
<div class="pageNav"><a href="#" class="btn_ctrl" id="voteCtrl">停止</a></div>
</div>
<?php if ($_GET["jsDebug"])
{?><script type="text/javascript" src="http://mat1.gtimg.com/www/mb/js/ui.js" charset="gb2312"></script>
<script type="text/javascript" src="http://mat1.gtimg.com/www/mb/js/mi.TV.js" charset="gb2312"></script><?
}
else
{
?><script type="text/javascript"src="http://mat1.gtimg.com/www/mb/js/mi.TV_<?php echo $jsVersion; ?>.js"></script><?
}
?>
<script type="text/javascript">
MI.TV.vote({
	ids : '<?php echo $ids; ?>'
});
MI.TV.voteUpdateTime=3000;
</script>
</body>
</html>