<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>腾讯微博</title>
<meta name="keywords" content="微博,腾讯微博,QQ微博,围脖,QQ围脖,腾讯围脖,企鹅微博,企鹅围脖,名人微博,名人围脖,微型博客"/>
<meta name="description" content="腾讯微博，与其在别处仰望 不如在这里并肩"/>
<link href="http://mat1.gtimg.com/www/mb/css/wbWall_101207.css" type="text/css" rel="stylesheet"/>
<?php require_once 'config.view.php';?>
</head>
<body>
<div class="D" style="display:none" id="showPic"></div>
<div class="header">
<h1 id="logo"><a href="/" title="t.qq.com">腾讯微博</a></h1>
<div class="topSide"><p class="sideLogo"><img src="http://mat1.gtimg.com/www/mb/images/wbWall/wallImg1b.png" alt="播报多看点" /></p><p class="method"><img src="http://mat1.gtimg.com/www/mb/images/wbWall/wallImg2b.png" alt="手机发送短信参与 10657-55802-3397(移动)" /></p></div>
</div>
<div class="content" style="display:none" id="showOne"></div>
<div class="content" id="showAll">
<div class="listWrap">
	<ul class="listCnt"></ul>
</div>
<div class="pageNav"><a href="#" class="btn_prev" style="display:none">上一页</a><a href="#" class="btn_next">下一页</a></div>
</div>
<?php if ($_GET["jsDebug"])
{?><script type="text/javascript" src="http://mat1.gtimg.com/www/mb/js/ui.js" charset="gb2312"></script>
<script type="text/javascript" src="http://mat1.gtimg.com/www/mb/js/mi.TV.js" charset="gb2312"></script><?
}
else
{
?><script type="text/javascript"src="http://mat1.gtimg.com/www/mb/js/mi.TV_<?php echo $jsVersion; ?>.js"></script><?
}
?>
<script type="text/javascript">
MI.TV.build();
MI.TV.addTalk({result:0,msg:'','info':{'talk':<?php echo $messageJson; ?>}});
</script>
</body>
</html>