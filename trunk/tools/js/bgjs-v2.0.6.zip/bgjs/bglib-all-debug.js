/**
 * Javascript Utility for web development.
 * R&D : www.bgscript.com/forum
 * @author javeejy@126.com
 * www.bgscript.com © 2009 - 构建自由的WEB应用 
 */

/**
 * 空函数,什么也不干,象征意义居多.
 * 空调用有什么用?
 * 常见的就有在一个超链接中,可设为<pre><a href="Javascript:fGo()" onclick="funcToRun()"></a></pre>
 * 其次当一个类未实现它的某个方法,但其它类又可能调用到该方法时,为了避免null调用,就可把这方法设为fGo.
 */
function fGo(){};

/**@global */
(function(){
	  //
	  // 以下为CC对象内部变量.
	  //
	  
    var ua = navigator.userAgent.toLowerCase();
    /**是否合法EMAIL字符串.
     * 参见 CC.isMail()
     */
    var mailReg = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/,
    
    //产生全局一个唯一ID, 参见CC.uniqueID().
    uniqueId = 0,
   
    //浏览器检测, thanks extJS here, copy & paste, so easy.
    isStrict = document.compatMode == "CSS1Compat",
    isOpera = ua.indexOf("opera") > -1,
    isSafari = (/webkit|khtml/).test(ua),
    isSafari3 = isSafari && ua.indexOf('webkit/5') != -1,
    isIE = !isOpera && ua.indexOf("msie") > -1,
    isIE7 = !isOpera && ua.indexOf("msie 7") > -1,
    isIE6 = !isOpera && ua.indexOf("msie 6") > -1,
    isGecko = !isSafari && ua.indexOf("gecko") > -1,
    isGecko3 = !isSafari && ua.indexOf("rv:1.9") > -1,
    //盒模型?
    isBorderBox = isIE && !isStrict;

    // 修复在IE的一些版本中通过CSS改变元素背景图片会出现重新请求闪烁现象,IE6犹为明显.
    if(isIE && !isIE7){
        try{
            document.execCommand("BackgroundImageCache", false, true);
        }catch(e){}
    }
	  
	 /**
	  * 该方法在创建新类时被调用,依次执行父类构造函数以给子类添加父类属性.
	  * 参见 CC.create()
	  */
    function applyCustructors(obj, superclass, cts){
        for(var i=0,len=cts.length;i<len;i++){
            var c = cts[i];
            if(CC.isArray(c)){
                arguments.callee(obj, superclass,c);
            }
            else if(CC.isFunction(c)){
                CC.extend(obj,c(superclass));
            }
            else { CC.extend(obj, c);}
        }
    }

    if(!window.CUtil)
		window.CUtil = {};
    /*
     * 生成CC对象
     */
    var bg = ({
    		version : '2009.8',
    	  /**
    	   * 根据结点ID值返回该DOM结点.
    	   * 该遍历为广度优先
    	   *@param a {String|DOMElement} id 结点ID,直接一个DOM也没关系
    	   *@param b {DOMElement} 父结点,如果该值指定,将在该结点下查找
    	   *@return {DOMElement} 对应ID的结点,如果不存在返回null
    	   */
        $: function(a,b) {
            var iss = a instanceof String || typeof a == "string";
            if (iss && !b){
                return document.getElementById(a);
            }
            if(!iss){
                return a;
	          }
            if(b.id == a){
                return b;
	          }
            var child = b.firstChild;
            var tmp = [];
            while (child) {
                if (child.id == a){
                    return child;
							  }
                //
                if(child.firstChild)
                	tmp.push(child);
                child = child.nextSibling;
                if(!child){
                	child = tmp.pop();
                	if(child)
                		child = child.firstChild;
                }
            }
            return null;
        }
        ,
        /**
         * 遍历可以枚举的对象,
         *@param {Object} object 可枚兴的对象,如果为数组或arguments时遍历下标数据,为普通对象时遍历对象所有属性. 
         *@param {function} callback
         *@param args
         */
        each: function(object, callback, args) {

            if (!object) {
                return object;
            }

            if (args) {
                if (object.length === undefined) {
                    for (var name in object)
                        if (callback.apply(object[name], args) === false)
                            break;
                } else
                    for (var i = 0, length = object.length; i < length; i++)
                        if (callback.apply(object[i], args) === false)
                            break;
            } else {
                if (object.length == undefined) {
                    for (var name in object)
                        if (callback.call(object[name], name, object[name]) === false)
                            break;
                } else
                    for (var i = 0, length = object.length, value = object[0]; i < length && callback.call(value, i, value) !== false; value = object[++i]){}
            }

            return object;
        },

        eachH : function(obj, nextAttr, callback){
            var p = obj,b;
            while(p){
                b = callback.call(p);
                if(b !== undefined){
                    return b;
                }
                p = p[nextAttr];
            }
        }
        ,

        extend: function(des, src) {
            if (!des) {
                des = {};
            }
            if (src) {
                for (var i in src) {
                    des[i] = src[i];
                }
            }
            return des;
        }
        ,
				
				extendIf : function(des, src) {
					if(!des)
						des = {};
						
					if(src)
						for(var i in src){
							if(des[i] === undefined)
								des[i] = src[i];
						}
					
					return des;
				},
				
        create: function() {
            var clazz = (function() {
                this.initialize.apply(this, arguments);
            });
    				
    				if(arguments.length == 0)
    					return clazz;
    				
            var absObj = clazz.prototype, parentClass, superclass, type, ags = this.$A(arguments);
            if(CC.isString(ags[0])) {
            	type = ags[0];
            	parentClass = ags[1];
            	ags.shift();
				Event.fire('create class '+type, absObj, clazz);
            }else{
            	parentClass = ags[0];
            }
            ags.shift();
            
            if(parentClass)
                superclass = parentClass.prototype;
            
            if(superclass){
                //用于访问父类方法
                clazz.superclass = superclass;
				this.extend(absObj, superclass);
                absObj.superclass = superclass;
            }
            if(type){
	            absObj.type = type;
	            if(type.indexOf('.')>0){
	            	this.$attr(window, type, clazz);  	
	            }else 
	            window[type]=clazz;
            }
            clazz.constructors = ags;
            applyCustructors(absObj, superclass, ags);
            if(type){
			   Event.fire('created class '+type,absObj, clazz);
			}
            return clazz;
        }
        ,

        ajaxRequest: function() {
            try {
                if (window.XMLHttpRequest) {
                    return new XMLHttpRequest();
                } else {
                    if (window.ActiveXObject) {
                        try {
                            return new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            try {
                                return new ActiveXObject("Microsoft.XMLHTTP");
                            } catch (e) {
                                return null;
                            }
                        }
                    }
                }
            } catch (ex) {
                console.debug('createXMLHttpRequest', ex);
                return false;
            }
        }
        ,
        
        $attr: function(obj, attrList, value) {
            if (this.isString(attrList)) {
                attrList = attrList.split('.');
            }
						var t1;
            for (var i = 0, idx = attrList.length - 1; i < idx; i++) {
                t1 = obj;
                obj = obj[attrList[i]];
                if(typeof obj == 'undefined' || obj === null)
                	t1[attrList[i]] = obj = {};
            }
            if (value == undefined) {
                return obj[attrList[i]];
            }
            obj[attrList[i]] = value;
        }
        ,
        
        queryString : function(obj) {
            if(!obj)
                return '';
            var arr = [];
            for(var k in obj){
                var ov = obj[k], k = encodeURIComponent(k);
                var type = typeof ov;
                if(type == 'undefined'){
                    arr.push(k, "=&");
                }else if(type != "function" && type != "object"){
                    arr.push(k, "=", encodeURIComponent(ov), "&");
                }else if(this.isArray(ov)){
                    if (ov.length) {
                        for(var i = 0, len = ov.length; i < len; i++) {
                            arr.push(k, "=", encodeURIComponent(ov[i] === undefined ? '' : ov[i]), "&");
                        }
                    } else {
                        arr.push(k, "=&");
                    }
                }
            }
            arr.pop();
            return arr.join("");
        },
  
        formQuery: function(f) {
            var formData = "", elem = "", f = CC.$(f);
            var elements = f.elements;
            var length = elements.length;
            for (var s = 0; s < length; s++) {
                elem = elements[s];
                if (elem.tagName == 'INPUT') {
                    if (elem.type == 'radio' || elem.type == 'checkbox') {
                        if (!elem.checked) {
                            continue;
                        }
                    }
                }
                if (formData != "") {
                    formData += "&";
                }
                formData += encodeURIComponent(elem.name||elem.id) + "=" + encodeURIComponent(elem.value);
            }
            return formData;
        }
        ,

        validate: function() {
				  var args = CC.$A(arguments),
				  form = null;
				  //form如果不为空元素,应置于第一个参数中.
				  if (!CC.isArray(args[0])) {
				    form = CC.$(args[0]);
				    args.remove(0);
				  }
				  //如果存在设置项,应置于最后一个参数中.
				  //cfg.queryString = true|false;
				  //cfg.callback = function
				  //cfg.ignoreNull
				  //nofocus:true|false
				  var b = CC.isArray(b) ? {}: args.pop();
				  var queryStr = b.queryString;
				  var result = queryStr ? '': {};
				  CC.each(args, function(i, v) {
				    //如果在fomr中不存在该name元素,就当id来获得
				    var obj = v[0].tagName ? v[0] : form ? form[v[0]] : CC.$(v[0]);
				    //console.debug('checking field:',v, 'current value:'+obj.value);
				    var value = obj.value, msg = v[1], d = CC.isFunction(v[2])?v[3]:v[2];
				    //选项
				    if(!d || typeof d != 'object')
				    	d = b;
				    
				    //是否忽略空
				    if (!d.ignoreNull &&
				    (value == '' || value == null)) {
				      //如果不存在回调函数,就调用alert来显示错误信息
				      if (!d.callback) 
				      	CC.alert(msg, obj, form);
				      //如果存在回调,注意传递的三个参数
				      //msg:消息,obj:该结点,form:对应的表单,如果存在的话
				      else d.callback(msg, obj, form);
				      //出错后是否聚集
				      if (!d.nofocus) 
				      	obj.focus();
				      result = false;
				      return false;
				    }
				    //自定义验证方法
				    if (CC.isFunction(v[2])) {
				      var ret = v[2](value, obj, form);
				      var pass = (ret !== false);
				      if (CC.isString(ret)) {
				        msg = ret;
				        pass = false;
				      }
				
				      if (!pass) {
				        if (!d.callback) CC.alert(msg, obj, form);
				        //同上
				        else d.callback(msg, obj, form);
				
				        if (!d.nofocus) 
				        	obj.focus();
				        result = false;
				        return false;
				      }
				    }
						//如果不设置queryString并通过验证,不存在form,就返回一个对象,该对象包含形如{elementName|elementId:value}的数据.
				    if (queryStr && !form) {
				      result += (result == '') ? ((typeof obj.name == 'undefined' || obj.name=='') ? obj.id : obj.name) + '=' + value: '&' + v[0] + '=' + value;
				    } else if (!form) {
				      result[v[0]] = value;
				    }
				  });
				  //如果设置的queryString:true并通过验证,就返回form的提交字符串.
				  if (result !== false && form && queryStr) 
				  	result = CC.formQuery(form);
				  return result;
        }
        ,

        uniqueID: function() {
            return uniqueId++;
        }
        ,
        /**
         * 应用对象替换模板内容
         * templ({name:'Rock'},'<html><title>{name}</title></html>');
         * st:0,1:未找到属性是是否保留
         */
        templ : function(obj, str, st) {
            return str.replace(/\{([\w_$]+)\}/g,function(c,$1){
                var a = obj[$1];
                if(a === undefined || a === null){
                    if(st === undefined)
                        return '';
                    switch(st){
                        case 0: return '';
                        case 1: return $1;
                        default : return c;
                    }
                }
                return a;
            });
        },

        isFunction: function(obj) {
            return (obj instanceof Function || typeof obj == "function");
        }
        ,

        isString: function(obj, canEmpty) {
            if (canEmpty) {
                return ((obj instanceof String || typeof obj == "string") && obj != "");
            } else {
                return (obj instanceof String || typeof obj == "string");
            }
        }
        ,

        isArray: function(obj) {
            return (obj instanceof Array || typeof obj == "array");
        }
        ,

        isDate: function(obj) {
            return (obj instanceof Date);
        }
        ,
	
        alert: function(msg) {
            alert(msg);
        }
        ,
	
        tip: function(msg, title, proxy, timeout, getFocus) {
            alert(msg);
        }
        ,
        /**
         * 移除并返回对象属性
         */
        delAttr : function(obj, attrName) {
            if(obj) {
                var t = obj[attrName];
                if(t !== undefined)
                	delete obj[attrName];
                return t;
            }
        },

        addClass: function(o, s) {
            var ss = o.className.replace(s, '');
            ss += ' ' + s;
            o.className = ss;
        }
        ,
        
        addClassIf: function(o, s) {
            if(this.hasClass(o,s))
			  return;
			var ss = o.className.replace(s, '');
            ss += ' ' + s;
            o.className = ss;
        },

        delClass: function(o, s) {
            o.className = o.className.replace(s, "");
        }
        ,
	
        hasClass : function(o, s) {
            return s && (' ' + o.className + ' ').indexOf(' ' + s + ' ') != -1;
        },

        switchClass: function(a, oldSty, newSty) {
            CC.delClass(a, oldSty);
            CC.addClass(a, newSty);
        }
        ,

        setClass: function(o, s) {
            o.className = s;
        },
        /**
         * 以style.display方式设置元素是否可见
         * inline为true时将display设为空,而不是block.
         */
        display: function(v, b, inline) {
            if (b === undefined) {
                return CC.$(v).style.display != 'none';
            }
						var blm = inline !== undefined ? '' : 'block';
            CC.$(v).style.display = b ? blm : 'none';
        }
        ,
				/**
				 * 以visibility方式设置元素是否可见
				 */
				seeMe: function(v, b){
					if(b === undefined){
						return CC.$(v).style.visibility != 'hidden';
					}
					
					CC.$(v).style.visibility = b ? 'visible' : 'hidden';
				},
				
        disable: function(v, b) {
            if(arguments.length==1){
                return CC.$(v).disabled;
            }
            CC.$(v).disabled = b;
        }
        ,

        insertAfter: function(oNew, oSelf) {
            var oNext = oSelf.nextSibling;
            if (oNext == null) {
                oSelf.parentNode.insertBefore(oNew, oSelf);
            } else {
                oSelf.parentNode.insertBefore(oNew, oNext);
            }
            return oNew;
        },
  
        isNumber: function(ob) {
            return (ob instanceof Number || typeof ob == "number");
        }
        ,

        isMail : function(strMail) {
            return mailReg.test(strMail);
        },
	
        isUndefined: function(object) {
            return typeof object == "undefined";
        }
        ,
  
        today: function() {
            return new Date();
        }
        ,


        dateFormat: function(date, fmt) {
        	  if(!fmt){
        	  	return date.toLocaleString();
        	  }
        	  var sep = fmt.charAt(2);
        	  var ss = fmt.split(sep);
        	  var cc = '';
        	  for(var i=0,len=ss.length;i<len;i++){
        	  	switch(ss[i]){
        	  		case 'mm' :
        	  		  var month = date.getMonth()+1;
        	  		  if (month < 10) 
                		month = "0" + month;
        	  			cc+=month;
        	  			break;
        	  		case 'yy' :
        	  		  cc+=date.getFullYear();break;	
        	  		case 'dd' :
        	  		  var d = date.getDate();
        	  		  if (d < 10) 
                		d = "0" + d;
        	  			cc += d;
        	  			break;
        	  	}
        	  	if(i!=len-1)
        	  		cc+=sep;
        	  }
        	  return cc;
       }
       ,

       dateParse : function(str, fmt){
       	if(!fmt){
       		return new Date(str);
       	}
       	var arr = [0,0,0];
        var sep = fmt.charAt(2);
        var ss = fmt.split(sep);
        var tar = str.split(sep);
        var cc = '';
        for(var i=0,len=ss.length;i<len;i++){
        	if(ss[i]=='mm')
        		arr[0] = tar[i];
        	else if(ss[i]=='dd')
        		arr[1]=tar[i];
        	else arr[2]=tar[i];
        }
        return new Date(arr.join(sep));
       },
       
        addDate: function(field, date, delta) {
            var newDate = null;
            switch (field) {
                case "year":
                    newDate = new Date(parseInt(date.getFullYear()) + 1, date.getMonth(), date.getDate());
                    break;
                case "month":
                    newDate = new Date(date.getFullYear(), date.getMonth() + delta, date.getDate());
                    break;
                case "day":
                    newDate = new Date(date.getFullYear(), date.getMonth(), date.getDate() + delta);
                    break;
            }
            return newDate;
        },
  
        $C: function(a) {
            if (this.isString(a)) {
                return document.createElement(a);
            }
            var tag = a.tagName;
            delete a.tagName;
            var b = this.extend(document.createElement(tag), a);
            a.tagName = tag;
            return b;
        }
        ,
        $N: function(name) {
            return document.getElementsByName(name);
        },
        $T: function(tagName) {
          return document.getElementsByTagName(tagName);
		    }
		    ,
       	tagUp : function(dom, tag){
        	while(dom && dom.tagName != tag){
        		dom = dom.parentNode;
        		if(dom && dom.tagName == 'BODY')
        			return null;
        	}
        	return dom;
        },
         
        loadScript: function(id, url) {
            var oHead = this. $T('head')[0];
            var script = this. $C( {
                tagName: 'SCRIPT',
                id: id,
                type: 'text/javascript',
                src: url
            }
            );
            oHead.appendChild(script);
            return script;
        }
        ,
        
        loadCSS: function(id, url) {
            var oHead = this. $T('head')[0];
            var css = this. $C( {
                tagName: 'link',
                id: id,
                rel: 'stylesheet',
                href: url,
                type: 'text/css'
            }
            );
            oHead.appendChild(css);
            return css;
        }
        ,

        loadStyle: function(id, ss) {
            var o;
            if (document.createStyleSheet) {
                window[id] = ss;
                o = document.createStyleSheet('javascript:' + id);
                return o;
            }
            var css = this.$C( {
                tagName: 'style',
                id: id,
                type: 'text/css'
            }
            );
            css.innerHTML = ss;
            this.$T('head')[0].appendChild(css);
            return ss;
        }
        ,

        noCache: function() {
            return '&noCacheReq=' + (new Date()).getTime();
        }
        ,

        $A : function(iterable) {
            if (!iterable)return [];
            if (iterable.toArray) {
                return iterable.toArray();
            } else {
                var results = [];
                for (var i = 0, length = iterable.length; i < length; i++)
                    results.push(iterable[i]);
                return results;
            }
        },

        frameDoc : function(frame) {
            return frame.contentWindow ? frame.contentWindow.document:frame.contentDocument;
        },
 	
        frameWin : function(frame){
            return frame.contentWindow;
        },
		    
        getViewWidth : function(full) {
            return full ? this.getDocumentWidth() : this.getViewportWidth();
        },

        getViewHeight : function(full) {
            return full ? this.getDocumentHeight() : this.getViewportHeight();
        },

        getDocumentHeight: function() {
            var scrollHeight = (document.compatMode != "CSS1Compat") ? document.body.scrollHeight : document.documentElement.scrollHeight;
            return Math.max(scrollHeight, this.getViewportHeight());
        },

        getDocumentWidth: function() {
            var scrollWidth = (document.compatMode != "CSS1Compat") ? document.body.scrollWidth : document.documentElement.scrollWidth;
            return Math.max(scrollWidth, this.getViewportWidth());
        },

        getViewportHeight: function(){
            if(isIE){
                return isStrict ? document.documentElement.clientHeight :
                         document.body.clientHeight;
            }else{
                return self.innerHeight;
            }
        },

        getViewportWidth: function() {
            if(isIE){
                return isStrict ? document.documentElement.clientWidth : document.body.clientWidth;
            }else{
                return self.innerWidth;
            }
        },
  			
  			getViewport : function(){
  				return {width:this.getViewportWidth(), height:this.getViewportHeight()};
  			},
  			
        ie : isIE,
        ie7 : isIE7,
        ie6 : isIE6,
        strict : isStrict,
        safari : isSafari,
        safari3 : isSafari3,
        gecko : isGecko,
        gecko3 : isGecko3,
        borderBox : isBorderBox,
        opera : isOpera
    });

if(!window.console)
    	window.console = {};

bg.extendIf(window.console, {debug : fGo,info : fGo,trace : fGo,log : fGo,warn : fGo,error : fGo,assert:fGo,dir:fGo,count : fGo,group:fGo,groupEnd:fGo,time:fGo,timeEnd:fGo});
bg.extendIf(String.prototype,  (function(){
    var allScriptText = new RegExp('<script[^>]*>([\\S\\s]*?)<\/script>', 'img');
    var onceScriptText = new RegExp('<script[^>]*>([\\S\\s]*?)<\/script>', 'im');
    var allStyleText = new RegExp('<style[^>]*>([\\S\\s]*?)<\/style>', 'img');
    var onceStyleText = new RegExp('<style[^>]*>([\\S\\s]*?)<\/style>', 'im');
  
    return ({
        //删除两头空格.
        trim: function() {
            return this.replace(new RegExp("(^[\\s]*)|([\\s]*$)", "g"), "");
        },
  
        escape: function() {
            return escape(this);
        }
        ,
	
        unescape: function() {
            return unescape(this);
        }
        ,
        
        checkSpecialChar : function(flag,oObj){
            var reg=/[%\'\"\/\\]/;
            if( this.search( reg )!=-1){
                if(flag){
                //CC.showSysMsg('error',"Be careful of characters such as ＂ % \' \" \\ \/ etc.",oObj,3000);
                }
                return false;
            }
            return true;
        },

        truncate: function(length, truncation) {
            length = length || 30;
            truncation = truncation === undefined ? '...' : truncation; return this.length > length ? this.slice(0, length - truncation.length) + truncation: this;
        }
        ,

        stripScript: function(fncb) {
            if (!fncb) {
                return this.replace(allScriptText, '');
            }
            return this.replace(allScriptText, function(sMatch) {
                fncb(sMatch); return '';
            }
            );
        }
        ,

        stripStyle: function(fncb) {
            if (!fncb) {
                return this.replace(allStyleText, '');
            }
            return this.replace(allStyleText, function(sMatch) {
                fncb(sMatch); return '';
            }
            );
        }
        ,
        innerScript: function() {
            this.match(onceScriptText); return RegExp.$1;
        }
        ,

        innerStyle: function() {
            this.match(onceStyleText); return RegExp.$1;
        }
        ,

        execScript: function() {
            return this.replace(allScriptText, function(ss) {
                //IE 不直接支持RegExp.$1??.
                ss.match(onceScriptText);
                if (window.execScript) {
                    execScript(RegExp.$1);
                } else {
                    window.eval(RegExp.$1);
                }
                return '';
            }
            );
        }
        ,

        execStyle: function() {
            return this.replace(allStyleText, function(ss) {
                //IE 不直接支持RegExp.$1??.
                ss.match(onceStyleText); CC.loadStyle(RegExp. $1); return '';
            }
            );
        },
  
        camelize: function() {
            var parts = this.split('-'), len = parts.length;
            if (len == 1) return parts[0];

            var camelized = this.charAt(0) == '-'
            ? parts[0].charAt(0).toUpperCase() + parts[0].substring(1)
            : parts[0];

            for (var i = 1; i < len; i++)
                camelized += parts[i].charAt(0).toUpperCase() + parts[i].substring(1);

            return camelized;
        }
    });
})());


bg.extendIf(Array.prototype,  {
	
    //p:the index or the obj in arr,return the length
    remove: function(p) {
        if (CC.isNumber(p)) {
            if (p < 0 || p >= this.length) {
                throw "Index Of Bounds:" + this.length + "," + p;
            }
            this.splice(p, 1)[0]; return this.length;
        }
        if (this.length > 0 && this[this.length - 1] == p) {
            this.pop();
        } else {
            var pos = this.indexOf(p);
            if (pos !=  - 1) {
                this.splice(pos, 1)[0];
            }
        }
        return this.length;
    }
    ,

    indexOf: function(obj) {
        for (var i = 0, length = this.length; i < length; i++) {
            if (this[i] == obj)return i;
        }
        return  - 1;
    }
    ,

    insert: function(idx, obj) {
        return this.splice(idx, 0, obj);
    }
    ,

    include: function(obj) {
        return (this.indexOf(obj) !=  - 1);
    },
  
    clear : function(){
        this.splice(0,this.length);
    }
}
);

//set the CC value;
if(!window.CC)
  window.CC = bg;

////
window.Eventable = (function(opt){
    if (!this.events) {
		if (!opt) 
			this.events = {};
		else 
			this.events = opt.events ||
			{};
	}
    bg.extend(this,Eventable.prototype);
});


Eventable.prototype.fire = (function(eid/**,arg1,arg2,arg3,...,argN*/){
	
    var evtMap = this.evtMap;
    if(evtMap){
        if(evtMap[eid])
            eid = evtMap[eid];
    }
	
    var fnArgs = CC.$A(arguments);
    fnArgs.remove(0);
    //console.log('发送:%o,源:%o',arguments,this);
    var handlers = this.events[eid];
    if(handlers){
    var argLen = fnArgs.length, ret, i, len;
	
    for(i=0,len=handlers.length;i<len;i++){
        var oHand = handlers[i];
        // add the argument of callback of itself.
        if(oHand.args)
            fnArgs[argLen] = oHand.args;
        //has this object.
        ret = (oHand.ds)?oHand.cb.apply(oHand.ds,fnArgs):oHand.cb.apply(this,fnArgs);
        //cancel fire
        if(ret === false)
            break;
    }
    }
    if(this.subscribers){
    	var sr;
    	for(i=0,len=this.subscribers.length;i<len;i++){
    		sr = this.subscribers[i];
    		sr.fireSubscribe.apply(sr, arguments);
    	}
    }
    return ret;
});

Eventable.prototype.on = (function(eid,callback,ds,objArgs){
    if(!eid || !callback)
        console.error('eid or callbakc not not be null:%o',arguments);
    var hs = this.events[eid];
    if(!hs)
        hs = this.events[eid] = [];
    hs[hs.length] = {
        cb:callback,
        ds:ds,
        args:objArgs
    };
    return this;
});

Eventable.prototype.un = (function(eid,callback){
    var handlers = this.events[eid];
    if(handlers){
        for(var i=0;i<handlers.length;i++){
            var oHand = handlers[i];
            if(oHand.cb == callback){
                handlers.remove(i);
                break;
            }
        }
    }
    return this;
});

Eventable.prototype.trans = (function(old,ne){
    if(!this.evtMap){
        this.evtMap = {
            old:ne
        };
        return;
    }
    this.evtMap[old] = ne;
    return this;
});
/**
 * 订阅对象所有事件
 */
Eventable.prototype.to = (function(target){
	if(!this.subscribers)
		this.subscribers = [];
	if(this.subscribers.indexOf(target) > 0)
		return;
	this.subscribers.push(target);
	return this;
});
/**
 * 默认为fire,自定订阅方式可重写.
 */
Eventable.prototype.fireSubscribe = Eventable.prototype.fire;

if (!window.Event) {
    window.Event = new Object;

}

Eventable.call(window.Event);

bg.extend(Event,  {
    KEY_BACKSPACE: 8,
    KEY_TAB: 9,
    KEY_ENTER: 13,
    KEY_ESC: 27,
    KEY_LEFT: 37,
    KEY_UP: 38,
    KEY_RIGHT: 39,
    KEY_DOWN: 40,
    KEY_DELETE: 46,
		
		readyList : [],
		
		contentReady : false,
		
    noUp : function(ev) {
        Event.stop(ev||window.event);
    },
 
    noSelect: function() {
        return false;
    },

    //get event.srcElement
    element: function(ev) {
        return ev.srcElement || ev.target;
    }
    ,
	
    pageX : function(ev) {
        if ( ev.pageX == null && ev.clientX != null ) {
            var doc = document.documentElement, body = document.body;
            return ev.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc.clientLeft || 0);
        }
        return ev.pageX;
    },
	
    pageY : function(ev) {
        if ( ev.pageY == null && ev.clientY != null ) {
            var doc = document.documentElement, body = document.body;
            return ev.clientY + (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc.clientTop || 0);
        }
        return ev.pageY;
    },
	
    pageXY : function(ev) {
        if ( ev.pageX == null && ev.clientX != null ) {
            var doc = document.documentElement, body = document.body;
            return [ev.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc.clientLeft || 0),
            ev.clientY + (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc.clientTop || 0)];
        }
        return [ev.pageX, ev.pageY];
    },
	
    which : function(ev) {
        if ( !ev.which && ((ev.charCode || ev.charCode === 0) ? ev.charCode : ev.keyCode) )
            return ev.charCode || ev.keyCode;
    },
	
    isLeftClick: function(ev) {
        return (((ev.which)
            && (ev.which == 1)) || ((ev.button) && (ev.button == 1)));
    }
    ,
    isEnterKey: function(ev) {
        return (ev.keyCode == 13);
    },
  
    stop: function(ev) {
        if (ev.preventDefault)
            ev.preventDefault();
        
        if(ev.stopPropagation)
            ev.stopPropagation();
    	
        if(CC.ie){
            ev.returnValue = false;
            ev.cancelBubble = true;
        }
    }
    ,
    preventDefault : function(ev) {
        if(ev.preventDefault)
            ev.preventDefault();
        ev.returnValue = false;
    },
  
    stopPropagation : function(ev) {
        if (ev.stopPropagation)
            ev.stopPropagation();
        ev.cancelBubble = true;
    },
  
    toggle : function(src, des, cssExpand, cssFold, msgExp, msgFld, hasText) {
        src = CC.$(src);
        des = CC.$(des);
        var b = CC.display(des);
        var add = b ? cssFold : cssExpand;
        var del = b ? cssExpand : cssFold;
        var txt = b ? msgExp : msgFld;
			
        CC.delClass(src, del);
        CC.addClass(src, add);
        CC.display(des, !b);
        if(hasText) src.innerHTML = txt;
        src.title = txt;
    },
  
    observers: false,

    _observeAndCache: function(element, name, observer, useCapture) {
        if (!this.observers) {
            this.observers = [];
        }
        if (element.addEventListener) {
            this.observers.push([element, name, observer, useCapture]);
            element.addEventListener(name, observer, useCapture);
        } else if (element.attachEvent) {
            this.observers.push([element, name, observer, useCapture]);
            element.attachEvent('on' + name, observer);
        }
    }
    ,

    unloadCache: function() {
        if (!this.observers) {
            return ;
        }

        for (var i = 0; i < this.observers.length; i++) {
            this.removeListener.apply(this, this.observers[i]);
            this.observers[i][0] = null;
        }
        this.observers = false;
    }
    ,
    //Warning : In IE6 OR Lower 回调observer时this并不指向element.
    addListener: function(element, name, observer, useCapture) {
        useCapture = useCapture || false;

        if (name == 'keypress' && (navigator.appVersion.match( / Konqueror | Safari | KHTML / )
            || element.attachEvent)) {
            name = 'keydown';
        }
        this._observeAndCache(element, name, observer, useCapture);
    }
    ,

    removeListener: function(element, name, observer, useCapture) {
        var element = CC.$(element); useCapture = useCapture || false;

        if (name == 'keypress' && (navigator.appVersion.match( / Konqueror | Safari | KHTML / )
            || element.detachEvent)) {
            name = 'keydown';
        }

        if (element.removeEventListener) {
            element.removeEventListener(name, observer, useCapture);
        } else if (element.detachEvent) {
            element.detachEvent('on' + name, observer);
        }
    },
    /**
     * 在RIA中不建议用该方式实现元素拖放,而应实例化一个CBase对象,使之具有一个完整的控件生命周期.
     */
    setDragable: function(dragObj, moveObj, b, fnOnMov, fnOnDrag, fnOnDrog) {
        if (!b) {
            dragObj.onmousedown = dragObj.onmouseup = null;
            return ;
        }

        var fnMoving = function(event) {
            var ev = event || window.event;
            if (!Event.isLeftClick(ev)) {
                dragObj.onmouseup(); return ;
            }

            if (moveObj && fnOnDrag && !moveObj.__ondraged) {
                fnOnDrag(ev, moveObj); moveObj.__ondraged = true;
            }

            if (fnOnMov) {
                if (!fnOnMov(ev, moveObj)) {
                    return false;
                }
            }

            var x = ev.clientX;
            var y = ev.clientY;
            var x1 = x - moveObj._x;
            var y1 = y - moveObj._y;
            moveObj._x = x;
            moveObj._y = y;

            moveObj.style.left = moveObj.offsetLeft + x1;
            moveObj.style.top = moveObj.offsetTop + y1;
        };

        var msup = function(event) {
            if (moveObj && moveObj.__ondraged) {
                fnOnDrog(event || window.event, moveObj); moveObj.__ondraged = false;
            }
            window.document.ondragstart = function(event) {
                (event || window.event).returnValue = true;
            };
      
            Event.removeListener(document, "mousemove", fnMoving);
            Event.removeListener(document, 'mouseup', arguments.callee);
            Event.removeListener(document, "selectstart", Event.noSelect);
        };
        
        dragObj.onmousedown = function(event) {
        		if(moveObj.unmoveable)
        			return;
            var ev = event || window.event;
            var x = ev.clientX;
            var y = ev.clientY;
            moveObj._x = x;
            moveObj._y = y;
            window.document.ondragstart = function(event) {
                (event || window.event).returnValue = false;
            };
      
            Event.addListener(document, "mousemove", fnMoving);
            Event.addListener(document, "selectstart", Event.noSelect);
            Event.addListener(document, 'mouseup', msup);
        };
    },
    
    ready : function(callback) {
    	this.readyList.push(callback);
    },
    
    _onContentLoad : function(){
    	var et = Event;
    	if(et.contentReady)
    		return;
    	et.contentReady = true;
    	
    	if(et.defUIReady)
    		et.defUIReady();
    		
    	for(var i=0;i<et.readyList.length;i++){
    		et.readyList[i].call(window);
    	}
    }
}
);

//
//Thanks to jQuery, www.jquery.org
// Mozilla, Opera (see further below for it) and webkit nightlies currently support this event
	if ( document.addEventListener && !isOpera)
		// Use the handy event callback
		document.addEventListener( "DOMContentLoaded", Event._onContentLoad, false );
	
	// If IE is used and is not in a frame
	// Continually check to see if the document is ready
	if ( isIE && window == top ) (function(){
		if (Event.contentReady) return;
		try {
			// If IE is used, use the trick by Diego Perini
			// http://javascript.nwbox.com/IEContentLoaded/
			document.documentElement.doScroll("left");
		} catch( error ) {
			setTimeout( arguments.callee, 0 );
			return;
		}
		// and execute any waiting functions
		Event._onContentLoad();
	})();

	if ( isOpera )
		document.addEventListener( "DOMContentLoaded", function () {
			if (Event.contentReady) return;
			for (var i = 0; i < document.styleSheets.length; i++)
				if (document.styleSheets[i].disabled) {
					setTimeout( arguments.callee, 0 );
					return;
				}
			// and execute any waiting functions
			Event._onContentLoad();
		}, false);

//	if ( isSafari )

// A fallback to window.onload, that will always work
	Event.addListener(window, "load", Event._onContentLoad);

bg.extendIf(Function.prototype, {
	bind : function() {
    var _md = this, args = CC.$A(arguments), object = args.shift();
    return function() {
        return _md.apply(object, args);
    }
  },
  
	bindAsListener : function(self) {
	    var _md = this;
	    return function(event) {
	        return _md.call(self, event||window.event);
	    }
	},
	
	bindAsNoCaptureListener : function() {
	    var _md = this, args = CC.$A(arguments), object = args.shift();
	    return function(event) {
	        event = event || window.event;
	        Event.stop(event);
	        return _md.apply(object, [event].concat(args));
	    }
	},

	timeout : function(seconds, interval){
		if(interval)
			return setInterval(this, seconds || 0);
		return setTimeout(this, seconds || 0);
	}
});

window.Ajax = bg.create();

Ajax.connect = (function(option){
    var ajax = new Ajax(option);
    ajax.connect();
    return ajax;
});

Ajax.prototype =  {
	
    method :'GET',
	
    url : null,
	
    asynchronous: true,
  
    timeout: 10000,
  
    disabledComp: null,
    
    contentType: 'application/x-www-form-urlencoded',
      
    msg: "数据加载中,请稍候...",
      
    //是否忽略浏览器缓存,默认为true.
    noCache:true,
      
    //XMLHttpRequest对象.
    xmlReq: null,
      
    //用于调用onfailure,onsuccess函数的this对象.
    caller: null,
  
    //失败后的回调.
    onfailure: null,
  
    data : undefined,
  
    //设置成功后的回调,默认为运行服务器返回的数据内容.
    onsuccess: (function(ajax) {
        ajax.invokeHtml();
    }),
  
    onfinal : null,
      
    //如果数据已加载,数据显示的DOM面板.
    displayPanel: null,
  
    //是否显示加载图标或进度.
    ui: true,
  
    //指明当前Ajax是否处理请求处理状态,在open后直至close前该值为真
    busy : false,
  
    /**
   * 根据设置初始化.
   */
    initialize: function(options) {
        Eventable.call(this,options);
        CC.extend(this, options);
    }
    ,
  
    /**
   * 重设置.
   *@param {Object} opts
   */
    setOption: function(opts) {
        CC.extend(this, opts);
    }
    ,
	
    /**
	 * 重写以实现自定消息界面,用于进度的消息显示,默认为空调用.
	 */
    setMsg: fGo
    ,

    _onTimeout: function() {
        if (this.xmlReq.readyState >= 4) {
            return ;
        }
        this.abort();
        this.setMsg("time out.");
    }
    ,

    _close: function() {
        if(this.timeout)
            clearTimeout(this._tid);
        if(this.onfinal)
            if(this.caller)
                this.onfinal.call(this.caller,this);
            else
                this.onfinal.call(this,this);
        this.fire('final',this);
        
        if (this.disabledComp) {
            CC.disable(this.disabledComp, false)
        };
        if(!CC.isUndefined(this.json))
            delete this.json;
        if(!CC.isUndefined(this.xmlDoc))
            delete this.xmlDoc;
    
        if(!CC.isUndefined(this.text))
            delete this.text;
    	
        this.disabledComp = null;
        //CC.display(CC. $('ajaxProgressBar'), false);
        this.xmlReq = null;
        this.params = null;
        this.busy = 0;
    }
    ,
  
    /**终止请求*/
    abort: function() {
      if(this.xmlReq !== null){
        this.xmlReq.abort();
        this._close();
      }
    }
    ,
    _req : function(){
        if(!this.xmlReq)
            this.xmlReq = CC.ajaxRequest();
    },
  
    _setHeaders: function() {
        this._req();
        if (this.method.toLowerCase() == 'post') {
            this.xmlReq.setRequestHeader('Content-type', this.contentType + (this.encoding ? '; charset=' + this.encoding: ''));
        }
    }
    ,
    /**
   * 建立XMLHttpRequest连接,在调用该方法后调用send方法前可设置HEADER.
   */
    open: function() {
        this._req();
        this.busy = 1;
        this.fire('open',this);
        if (this.timeout) {
            this._tid = setTimeout(this._onTimeout.bind(this), this.timeout);
        }

        if (this.disabledComp) {
            CC.disable(this.disabledComp, true);
        }
    
        var ps = this.params, ch = this.noCache;
        if(ps || ch){
            var isQ = this.url.indexOf('?') > 0;
            if(ch){
                if (isQ)
                    theUrl = this.url + '&__uid=' + CC.uniqueID();
                else
                    theUrl = this.url + '?&__uid=' + CC.uniqueID();
            }
	  	
            if(ps){
                if(!isQ && !ch)
                    this.url = this.url+'?';
	  			
                this.url = this.url + CC.queryString(ps);
            }
        }
        this.xmlReq.open(this.method.toUpperCase(), theUrl, this.asynchronous);
    }
    ,

    send: function(data) {
        this.fire('send');
        this._setHeaders();
        this.xmlReq.onreadystatechange = this._onReadyStateChange.bind(this);
        this.setMsg(this.msg);
        this.xmlReq.send(data || this.data);
    }
    ,

    connect : function(data) {
        if(this.busy)
            try{
                this.abort();
            }catch(e){
                console.debug(e);
            }
			
        this.open();
        this.send(data);
    },
	
    setRequestHeader: function(key, value) {
        this._req();
        this.xmlReq.setRequestHeader(key, value);
    }
    ,

    getResponseHeader: function(key) {
        return this.xmlReq.getResponseHeader(key);
    }
    ,

    _onReadyStateChange: function() {
        var req = this.xmlReq;
        if (req.readyState == 4) {
        		if(this.fire('load', this) === false)
        			return;
            var onsuccess = this.onsuccess;
            var onfailure = this.onfailure;
            // req.status 为 本地文件请求
            try{
                if (req.status == 200 || req.status == 0) {
                		if(this.fire('success', this) === false)
                			return false;
                    if(onsuccess)
                        if(this.caller)
                            onsuccess.call(this.caller, this);
                        else onsuccess.call(this,this);
                } else {
										if(this.fire('failure', this) === false)
                			return false;
                    if(onfailure)
                        if(this.caller)
                            onfailure.call(this.caller, this);
                        else onfailure.call(this,this);
                }
            }catch(reqEx){
                console.error(reqEx);
                this._close();
                throw reqEx;
            }
            this._close();
        }
    }
    ,
	
    getText : function() {
        if(this.text)
            return this.text;
        var s = this.text = this.xmlReq.responseText;
        this.fire('text',s,this);
        return this.text;
    },

    getXmlDoc : function() {
        if(this.xmlDoc)
            return this.xmlDoc;
        var doc = this.xmlDoc = this.xmlReq.responseXML.documentElement;
        this.fire('xmlDoc',doc,this);
        return this.xmlDoc;
    },
	
    getJson : function(){
        if(this.json)
            return this.json;
        var o = undefined;
        try {
            this.json = o = eval("("+this.getText()+");");
        }catch(e) {
            //console.debug(e+"\n"+this.getText());
            CC.alert('Internal server error : a request responsed with wrong json format.');
            throw e;
        }
        //可对json进行预处理
        this.fire('json',o,this);
        return this.json;
    }
    ,

    invokeScript: function() {
        return eval(this.getText());
    }
    ,

    invokeHtml: function() {
        var cacheJS =[] ,cache = [];
        var ss = this.getText().stripScript(function(sMatch) {
            cacheJS[cacheJS.length] = sMatch;
        }
        );
        cache = [];
        //先应用CSS
        ss = ss.stripStyle(function(sMatch) {
            cache[cache.length] = sMatch.innerStyle();
        }
        );
        cache.join('').execStyle();
        //再应用HTML
        if (this.displayPanel) {
            CC.$(this.displayPanel).innerHTML = ss;
        }
        //最后应用JS
        cacheJS.join('').execScript();
        cache = null;
        cacheJS = null;
        ss = null;
    }
};


/**
 * 缓存类.
 */
window.Cache =  {

    /**某类设置的最大缓存数量.*/
    MAX_ITEM_SIZE: 5,

    /**获取缓存数据的回调函数.*/
    callbacks: [],

    register: function(k, callback) {
        this[k] = [null, callback];
    }
    ,

    get: function(k) {
        var a = this[k];
        if(a === undefined)
            return null;
    		var b = a[1];
        a = a[0];
        
        if(a === null){
        	return b();
        }
        	
        if(a.length > 0)
            return a.shift();
        if(b)
            return b();
        
        return null;
    }
    ,

    put: function(k, v) {
        var a = this[k];
        if(!a){
            this[k] = a = [[v]];
            return;
        }
        var c = this[k][0];
        if(!c)
        	this[k][0] = c = [];
        if (c.length >= this.MAX_ITEM_SIZE) {
            return ;
        }
        
        c.push(v);
    },
    
    remove : function(k){
    	var a = this[k];
    	if(a){
    		delete this[k];
    	}
    }
};

/**
 * 缓存DIV结点,该结点可方便复用其innerHTML功能.
 */
Cache.register('div', function() {
    return CC. $C('DIV');
}
);

window.CBase = (function(dom){
    if(dom !== undefined)
        this.view = CC.$(dom);
});

var CompCache = {};

Event.addListener(window, 'unload', function(ev){
	try{
		for(var i in CompCache){
			CompCache[i].destoryComponent();
		}
	}catch(e){console.debug(e);}
});

//thanks Ext JS here.
var view = document.defaultView;
// local style camelizing for speed
var propCache = {};
var camelRe = /(-[a-z])/gi;
var camelFn = function(m, a){ return a.charAt(1).toUpperCase(); };

var hidMode = {visibility:'hidden', display:'none'};
var dispMode = {visibility:'visible', display:'block'};

/**
 * 
 * 控件基类.
 *
 */
Event.fire('create class CBase', CBase.prototype, CBase);
bg.extend(CBase.prototype,{

    type: 'CBase',

    view: null,

    clickCS : false,
    
    hoverCS : false,
	  
    disabled : false,

    height:false,
	
    width : false,
	
    left:false,
    
    top:false,
	
    minW:0,
    
    minH:0,
    
    maxH:Math.MAX,
    
    maxW:Math.MAX,

    initialize: function(opts) {
        if (opts){
          CC.extend(this, opts);
        }
        if(this.eventable)
        		Eventable.apply(this);
        this.initComponent();
    
        if(this.autoRender)
            this.render();
    },

		createView : function(){
        if(this.template && !this.view){
            //default template.
            this.view = CTemplate.$(this.template);
            delete this.template;
        }else if(!this.view){
        	this.view = CTemplate.$(this.type);
        }else if(CC.isString(this.view)){
        	this.view = CC.$(this.view);
        }
	  		
        if (!this.view)
            this.view = CC.$C('DIV');			
		},
		
    initComponent : function() {
    		var cid = this.cacheId = 'c' + CC.uniqueID();
    		CompCache[cid] = this;
				
				this.createView();
    		
        if(this.strHtml){
            this.html(CTemplate[this.strHtml]);
            delete this.strHtml;
        }
    
        if (this.viewAttr) {
            CC.extend(this.view, this.viewAttr);
            delete this.viewAttr;
        }
    		
    		if(this.inherentCS)
    			this.addClass(this.inherentCS);
    		
        if(this.cs) {
            this.addClass(this.cs);
        }
    
        if(!this.id)
            this.id = 'comp'+CC.uniqueID();
    
        if(!this.view.id)
            this.view.id=this.id;

	      if(this.title){
	        	this.setTitle(this.title);
	      }
      
        if(this.icon) {
            this.setIcon(this.icon);
        }
    
        if(this.clickCS) {
            var cp = this._csIf('clickCS', 'click');
            this.bindClickStyle(cp);
        }
    
        if(this.hoverCS){
            var cp = this._csIf('hoverCS', 'on');
            this.bindHoverStyle(cp);
        }
    
        if(this.unselectable)
            this.noselect();

        if(this.draggable) {
            //el, ondrag, ondrop, ondragstart,onmousedown,onmouseup, caller
            this.enableDragBehavior(this.draggable);
        }
  	
        if(this.ondropable){
            this.enableDropBehavior(this.ondropable);
        }
    		
        if(this.disabled)
            this.disable(this.disabled);

        if(this.width !== false)
            this.setWidth(this.width);
		
        if(this.height !== false)
            this.setHeight(this.height);
		
        if(this.top !== false)
            this.setTop(this.top);
		
        if(this.left !== false)
            this.setLeft(this.left);
    		if(this.shadow){
    			if(this.shadow === true)
    				this.shadow = new CShadow();
    			this.follow(this.shadow);
    		}
    },
   
  	follow : function(a){
  		var ls = this.__toDestory;
  		if(!ls)
  			ls = this.__toDestory = [];
  		ls.push(a);
  		if(!a.parentContainer)
  			a.parentContainer = this;
  		if(this.rendered && !a.rendered)
  			a.render();
  		return this;
  	},
    
    destoryComponent : function(){
     	delete CompCache[this.cacheId];
    	this.del();
    	var obs = this.observes, i, len, c;
    	if(obs){
    		var el;
	      for(i=0,len=obs.length;i<len;i++){
	      	c = obs[i];
	      	el = c[3] || this.view;
	      	if (el.removeEventListener) {
	            el.removeEventListener(c[0], c[2], true);
		      } else if (el.detachEvent) {
		            el.detachEvent('on' + c[0], c[2]);
		      }
	      }
	      delete this.observes;
    	}
    	obs = this.__toDestory;
    	if(obs){
    		for(i=0,len=obs.length;i<len;++i){
    			obs[i].destoryComponent();
    		}
    		delete this.__toDestory;
    	}
    },
    //
    // 子类应该重写该方法而不应该直接重写render方法
    //
    onRender : function(parentContainer, pos){
				if(this.hidden)
					this.display(false);
				
        var pc = parentContainer;
        if(!pc && this.showTo)
            pc = CC.$(this.showTo);
			  
        if(pc){
            pc = (pc.view||pc);
			
            if(this.showTo){
                delete this.showTo;
            }
			
            if(pos === undefined) {
                pc.appendChild(this.view);
            }else if(CC.isNumber(pos)){
                var c = pc.childNodes[pos];
                if(c)
                    pc.insertBefore(this.view, c);
            }
        }

        if(this.tip){
            //设置鼠标提示.
            this.setTip(this.tip===true?this.title:this.tip);
        }
        
        if(this.qtip && CUtil.qtip){
        		CUtil.qtip(this);
        }
    		
    		if(this.shadow){
    			this.shadow.attachTarget(this);
    		}
    		
      var obs = this.__toDestory;
    	if(obs){
    		for(var i=0,len=obs.length;i<len;i++){
    			if(!obs[i].rendered)
    				obs[i].render();
    		}
    	}
    },
    
    render : function() {
        if(this.rendered || this.fire('render', this)===false)
            return false;
        this.rendered = true;
				this.onRender();
        this.fire('rendered', this);
        if(!this.hidden && this.shadow){
        	var s = this.shadow;
        	(function(){
        			s.reanchor().display(true);
        	}).timeout(0);
        }
    },
	
    fire : fGo,
		
		hide : function(){
			return this.display(false);
		},
		
		show : function(){
			return this.display(true);
		},
		
		fly : function(childId){
			var el = this.dom(childId);
			if(el){
				return CC.fly(el);
			}
			return null;
		},
		
		unfly : function(){
			if(this.__flied === true){
				this.view = null;
				this.displayMode = 'display';
	  		this.blockMode = 'block';
				this.width = this.top = this.left = this.height = false;
				Cache.put('flycomp', this);
			}
		},
	
    addClass: function(s) {
        var v = this.view;
        var ss = v.className.replace(s, '');
        ss += ' ' + s;
        v.className = ss;
        return this;
    }
    ,
    addClassIf: function(s) {
        if(this.hasClass(s))
			  return this;
		var v = this.view;
        var ss = v.className.replace(s, '');
        ss += ' ' + s;
        v.className = ss;
        return this;
    }
    ,
    delClass: function(s) {
        var v = this.view;
        v.className = v.className.replace(s, "");
        return this;
    }
    ,
	
    hasClass : function(s) {
        return s && (' ' + this.view.className + ' ').indexOf(' ' + s + ' ') != -1;
    },
	
    switchClass: function(oldSty, newSty) {
        this.delClass(oldSty);
        this.addClass(newSty);
        return this;
    }
    ,

    setClass: function(s) {
        this.view.className = s;
        return this;
    }
    ,

    $T: function(tagName) {
        return this.view.getElementsByTagName(tagName);
    }
    ,
  
    dom : function(childId) {
        return CC.$(childId, this.view);
    },
  
    noUp : function(eventName, childId) {
        return this.domEvent(eventName || 'click', Event.noUp, true, null, childId);
    },
  
    clear: isIE ? function() {
        var dv = Cache.get('div');
        var v = this.view;
        while (v.firstChild) {
            dv.appendChild(v.firstChild);
        }
        dv.innerHTML = '';
        Cache.put('div', dv);
    } : function(){
        var v = this.view;
        while (v.firstChild) {
            v.removeChild(v.firstChild);
        }
        return this;
    },
	
    del : function(){
        if(this.view.parentNode)
            this.view.parentNode.removeChild(this.view);
    },
    
	  displayMode : 'display',
	  
	  blockMode : 'block',
    
    /**
   * 显示或隐藏某结点,v可以是结点id或结点.
   * 如果是id,则结点必须在dom树中.
   */
   display: function(b) {
     if (b === undefined) {
     	return this.view.style[this.displayMode] != hidMode[this.displayMode];
     }

     this.hidden = !b;
		 this.view.style[this.displayMode] = b ? this.blockMode : hidMode[this.displayMode];
		 
		 if(this.shadow){
			 if(b){
			 	  var s = this.shadow;
			 	  (function(){
			 	  	s.reanchor()
			 	  	 .display(true);
			 	  }).timeout(0);
			 }else 
			 this.shadow.display(b);
		 }
		 return this;
   },
   
   setBlockMode : function(bl){
   		this.blockMode = bl;
   		return this;
   },
   
   setDisplayMode : function(dm){
   	this.displayMode = dm;
   	if(dm == 'visibility')
   		this.blockMode = dispMode[dm];
   	return this;
   },
   
    /**
   * 检查或设置DOM的disabled属性值.
   */
    disable: function(b) {
  	
        if(arguments.length==0){
            return this.disabled;
        }
  	
        var v = this.disableNode || this.view;
        this.dom(v).disabled = b;
        this.disabled = b;
    
        if(b)
            this.addClass(this.disabledCS || 'g-disabled');
        else
            this.delClass(this.disabledCS || 'g-disabled');
    	
        return this;
    },
	
    enableDragBehavior : function(b){
        b?this.bindDragDrop() : this.unDragDrop();
    },
	
    enableDropBehavior : function(b) {
        b?this.bindDDRListener() : this.unDDRListener();
    },
	
    append : function(oNode){
        this.view.appendChild(oNode.view || oNode);
        return this;
    },

    html : function(ss, invokeScript, callback) {
        if(invokeScript){
            var cacheJS =[] ,cache = [];
            ss = ss.stripScript(function(sMatch) {
                cacheJS[cacheJS.length] = sMatch;
            }
            );
            cache = [];
            //先应用CSS
            ss = ss.stripStyle(function(sMatch) {
                cache[cache.length] = sMatch.innerStyle();
            }
            );
            cache.join('').execStyle();
            //再应用HTML
            this.view.innerHTML = ss;
            //最后应用JS
            cacheJS.join('').execScript();
            if(callback)
                callback.call(this);
            cache = null;
            cacheJS = null;
            ss = null;
            return this;
        }
		
        (this.container||this.view).innerHTML = ss;
        return this;
    },
	
    appendTo : function(where) {
        where.type ? where.append(this.view) : CC.$(where).appendChild(this.view);
        return this;
    },
    /**
   * 在结点之后插入oNew
   */
    insertAfter: function(oNew) {
        var f = CC.fly(oNew);
        oNew = f.view;
        var v = this.view;
        var oNext = v.nextSibling;
        if (oNext == null) {
            v.parentNode.appendChild(oNew);
        } else {
            v.parentNode.insertBefore(oNew, oNext);
        }
        f.unfly();
        return this;
    },
  
    insertBefore : function(oNew) {
        oNew = CC.$$(oNew).view;
        this.view.parentNode.insertBefore(oNew, this.view);
        return this;
    },
  
    setZ : function(zIndex) {
        this.style("z-index", zIndex);
        if(this.shadow)
        	this.shadow.setZ(zIndex - 1);
        return this;
    },

    style : function(style,value) {
        //getter
        if(value === undefined) {
            return this.getStyle(style);
        }
        return this.setStyle(style,value);
    },

    getOpacity : function () {
        return this.getStyle('opacity');
    },
	
    //设置结点的透明度.
    setOpacity : function (value) {
        this.view.style.opacity = value == 1 ? '' : value < 0.00001 ? 0 : value;
        return this;
    },
	
    //设置结点风格.
    //如 CC.setStyle(oDiv,'position','relative');
    setStyle : function (key, value) {
        if (key == 'opacity') {
            this.setOpacity(value)
        } else {
            var st = this.view.style;
            st[
            key == 'float' || key == 'cssFloat' ? ( st.styleFloat === undefined ? ( 'cssFloat' ) : ( 'styleFloat' ) ) : (key.camelize())
            ] = value;
        }
        return this;
    },
    //Ext
    getStyle : function(){
        return view && view.getComputedStyle ?
            function(prop){
                var el = this.view, v, cs, camel;
                if(prop == 'float'){
                    prop = "cssFloat";
                }
                if(v = el.style[prop]){
                    return v;
                }
                if(cs = view.getComputedStyle(el, "")){
                    if(!(camel = propCache[prop])){
                        camel = propCache[prop] = prop.replace(camelRe, camelFn);
                    }
                    return cs[camel];
                }
                return null;
            } :
            function(prop){
                var el = this.view, v, cs, camel;
                if(prop == 'opacity'){
                    if(typeof el.style.filter == 'string'){
                        var m = el.style.filter.match(/alpha\(opacity=(.*)\)/i);
                        if(m){
                            var fv = parseFloat(m[1]);
                            if(!isNaN(fv)){
                                return fv ? fv / 100 : 0;
                            }
                        }
                    }
                    return 1;
                }else if(prop == 'float'){
                    prop = "styleFloat";
                }
                if(!(camel = propCache[prop])){
                    camel = propCache[prop] = prop.replace(camelRe, camelFn);
                }
                if(v = el.style[camel]){
                    return v;
                }
                if(cs = el.currentStyle){
                    return cs[camel];
                }
                return null;
            };
    }(),
    
		/**
		 * 先添加默认图标样式this.iconCS，再添加参数样式。
		 */
    setIcon: function(cssIco) {
        var o = this.fly(this.iconNode || '_ico');
        if(this.iconCS)
            if(!this.hasClass(this.iconCS))
                this.addClass(this.iconCS);
				
        if(o){
            if(CC.isString(cssIco))
                o.addClass(cssIco);
            else
                o.display(cssIco);
        	  o.unfly();
        }
        return this;
    }
    ,

    setTip:function(ss){
      if(this.view && ss && !this.qtip){
      		this.view.title = ss;
      }
      this.tip = ss;
      return this;
   },
	  
    setTitle: function(ss) {
        this.title = ss;
        if(!this.titleNode)
        	this.titleNode = this.dom('_tle');
        else if(!this.titleNode.tagName)
        	this.titleNode = this.dom(this.titleNode);
        if(this.titleNode)
        	this.titleNode.innerHTML = this.brush ? this.brush(ss):ss;
        if(this.tip !== false && this.view && !this.qtip)
        	this.view.title = ss;
        if(this.qtip === true)
        	this.qtip = ss;
        return this;
    }
    ,

    setWidth: function(width) {
        this.setSize(width, false);
        return this;
    }
    ,

    getWidth : function(usecache){
        if(usecache && this.width !== false)
            return this.width;
        return this.getSize().width;
    },
	
    setHeight: function(height) {
        this.setSize(false, height);
        return this;
    }
    ,

    getHeight:function(usecache){
        if(usecache &&  this.height !== false)
            return this.height;
        return this.getSize().height;
    },
    
    setSize : function(a, b) {
        if(a.width !== undefined){
            var c = a.width;
            if(c !== false){
                if(c<this.minW) c=this.minW;
                if(c>this.maxW) c=this.maxW;
                this.style('width', c + 'px');
                this.width = c;
            }
            c=a.height;
            if(c !== false){
                if(c<this.minH) c=this.minH;
                if(c>this.maxH) c=this.maxH;
                if(c<0) a.height=c=0;
                this.style('height', c + 'px');
                this.height = c;
            }
            return this;
        }
		
        if(a !== false){
            if(a<this.minW) a=this.minW;
            if(a>this.maxW) a=this.maxW;
            this.style('width', a + 'px');
            this.width = a;
        }
        if(b !== false){
            if(b<this.minH) b=this.minH;
            if(b>this.maxH) b=this.maxH;
            this.style('height', b + 'px');
            this.height=b;
        }
		
        return this;
    },
		
		setXY : function(a, b){
        if(CC.isArray(a)){
	         if(a[0]!== false || a[1]!== false){
	        	if(a[0]!== false){
	            this.style('left',a[0]+'px');
	            this.left = a[0];
	          }
	          if(a[1] !== false){
	            this.style('top',a[1]+'px');
	            this.top = a[1];
	          }
	          return this;
	         }
        }
        
        if(a !== false || b !== false){
           if(a !== false){
            this.style('left',a+'px');
            this.left = a;
          }
           if(b !== false){
           	this.style('top',b+'px');
           	this.top = b;
          }
        }
        
        return this;
		},
		
    setTop: function(top) {
        this.setXY(false, top);
        return this;
    }
    ,

    getTop : function(usecache){
        if(usecache && this.top !== false)
            return this.top;
        this.top = parseInt(this.style('top'), 10) || this.view.offsetTop;
        return this.top;
    },
	
    setLeft: function(left) {
        this.setXY(left, false);
        return this;
    }
    ,

    getLeft : function(usecache){
        if(usecache && this.left !== false)
            return this.left;
        this.left = parseInt(this.style('left'), 10) || this.view.offsetLeft;
        return this.left;
    },
	
    xy : function(usecache) {
				return [this.getLeft(usecache), this.getTop(usecache)];
    }
    ,

    //get absolute location of element
    location: function(offset) {
        var c = 0, v = this.view;
        while (v) {
            c += v[offset];
            v = v.offsetParent;
        }
        return c;
    }
    ,

    absoluteXY: function() {
     				var p, b, scroll, bd = (document.body || document.documentElement), el = this.view;

            if(el == bd || !this.display()){
                return [0, 0];
            }
            if (el.getBoundingClientRect) {
                b = el.getBoundingClientRect();
                p = CC.fly(document);
                scroll = p.getScroll();
                p.unfly();
                return [b.left + scroll.left, b.top + scroll.top];
            }
            var x = 0, y = 0;

            p = el;

            var hasAbsolute = this.getStyle("position") == "absolute", f = CC.fly(el);
            
            while (p) {

                x += p.offsetLeft;
                y += p.offsetTop;
                f.view = p;
                if (!hasAbsolute && f.getStyle("position") == "absolute") {
                    hasAbsolute = true;
                }

                if (CC.gecko) {
                    var bt = parseInt(f.getStyle("borderTopWidth"), 10) || 0;
                    var bl = parseInt(f.getStyle("borderLeftWidth"), 10) || 0;
                    x += bl;
                    y += bt;
                    if (p != el && f.getStyle('overflow') != 'visible') {
                        x += bl;
                        y += bt;
                    }
                }
                p = p.offsetParent;
            }

            if (CC.safari && hasAbsolute) {
                x -= bd.offsetLeft;
                y -= bd.offsetTop;
            }

            if (CC.gecko && !hasAbsolute) {
                f.view = bd;
                x += parseInt(f.getStyle("borderLeftWidth"), 10) || 0;
                y += parseInt(f.getStyle("borderTopWidth"), 10) || 0;
            }

            p = el.parentNode;
            while (p && p != bd) {
            		f.view = p;
                if (!CC.opera || (p.tagName != 'TR' && f.getStyle("display") != "inline")) {
                    x -= p.scrollLeft;
                    y -= p.scrollTop;
                }
                p = p.parentNode;
            }
            f.unfly();
            return [x, y];
    }
    ,
    
    absoluteX : function(){
        return this.absoluteXY()[0];
    },
	
    absoluteY : function() {
        return this.absoluteXY()[1];
    },
	
    //whether hide or not ,get the demensions,要获得正确size结点须在DOM中.
    getSize: function(usecache) {
        if(usecache && (this.width !== false && this.height !== false)) {
            return {
                width:this.width,
                height:this.height
            };
        }
    
        var v = this.view;
        var display = v.style.display;
        if (display != 'none' && display != null){ // Safari bug
            return {
                width:v.offsetWidth,
                height:v.offsetHeight
            };
        }

        // All *Width and *Height properties give 0 on vs with display none,
        // so enable the v temporarily
        var els = v.style;
        var oriVis = els.visibility;
        var oriPos = els.position;
        var oriDis = els.display;
        els.visibility = 'hidden';
        els.position = 'absolute';
        els.display = 'block';
        var oriW = v.clientWidth;
        var oriH = v.clientHeight;
        els.display = oriDis;
        els.position = oriPos;
        els.visibility = oriVis;
        return {
            width:oriW,
            height:oriH
        };
    },
		
  
    setBounds : function(x,y,w,h) {
        this.setXY(x,y);
        return this.setSize(w,h);
    },
  
    makePositioned: function(pos, zIndex, x, y) {
        var v = this.view;
        if (pos) {
            this._madePositioned = true;
            v.style.position = pos || 'relative';
        // Opera returns the offset relative to the positioning context, when an
        // v is position relative but top and left have not been defined
        }

        if(zIndex){
            this.setStyle("z-index", zIndex);
        }
        if(x !== undefined || y !== undefined){
            this.setXY(x, y);
        }
        return this;
    }
    ,

    unPositioned: function() {
        var v = this.view;
        if (this._madePositioned) {
            delete this._madePositioned;
            v.style.position = '';
            v.style.top = '';
            v.style.left = '';
            v.style.bottom = '';
            v.style.right = '';
        }
        return this;
    }
    ,

    clip: function() {
        var v = this.view;
        if (v._overflow)
            return this;
    	
        this._overflow = v.style.overflow || 'auto';
        if (this._overflow !== 'hidden')
            v.style.overflow = 'hidden';
        return this;
    },

    unclip: function() {
        var v = this.view;
        if (!this._overflow)
            return this;
        v.style.overflow = this._overflow == 'auto' ? '' : this._overflow;
        this._overflow = null;
        return this;
    },

    copyViewport : function(des){
        des = CC.$$(des);
        des.setXY(this.xy());
        des.setSize(this.getSize());
        return this;
    },
	
    _csIf : function(cs, def, proxy, from) {
        var a = this[cs];
        return CC.isString(a) ? a : def;
    }
    ,
  
    focus : function(timeout){
        		if(this.disabled)
        			return this;
            var el = this.focusNode?this.dom(this.focusNode):this.view;
						if(timeout)
            	(function(){ try{el.focus();}catch(ee){}}).timeout(timeout);
            else try{ el.focus();}catch(e){}
					return this;
    },

    cssText : function(styles) {
        if(styles){
            if(typeof styles == "string"){
                var re = /\s?([a-z\-]*)\:\s?([^;]*);?/gi;
                var matches;
                while ((matches = re.exec(styles)) != null){
                    this.setStyle(matches[1], matches[2]);
                }
            }else if (typeof styles == "object"){
                for (var style in styles){
                    this.setStyle(style, styles[style]);
                }
            }else if (typeof styles == "function"){
                this.cssText(styles.call());
            }
        }
    },
		
    noselect : function() {
        var v = this, t = typeof this.unselectable, mt = false;
        if(t != 'undefined' && t != 'boolean'){
        		mt = true;
            v = this.fly(this.unselectable);
        }
        v.view.unselectable = "on";
        v.noUp("selectstart");
        //v.cssText("-moz-user-select:none;-khtml-user-select:none;");
        v.addClass("noselect");
        if(mt)
        	v.unfly();
        return this;
    },
  
    autoHeight : function(animate, onComplete) {
        var oldHeight = this.getHeight();
        this.clip();
        this.view.style.height = 1; // force clipping
        setTimeout(function(){
            var height = parseInt(this.view.scrollHeight, 10); // parseInt for Safari
            if(!animate){
                this.setHeight(height);
                this.unclip();
                if(onComplete){
                    onComplete();
                }
            }else{
                this.setHeight(oldHeight);
            }
        }.bind(this), 0);
        return this;
    },
    
		getScroll : function(){
		    var d = this.view, doc = document;
        if(d == doc || d == doc.body){
            var l, t;
            if(CC.ie && CC.strict){
                l = doc.documentElement.scrollLeft || (doc.body.scrollLeft || 0);
                t = doc.documentElement.scrollTop || (doc.body.scrollTop || 0);
            }else{
                l = window.pageXOffset || (doc.body.scrollLeft || 0);
                t = window.pageYOffset || (doc.body.scrollTop || 0);
            }
            return {left: l, top: t};
        }else{
            return {left: d.scrollLeft, top: d.scrollTop};
        }
		},
		
		ancestorOf :function(a, depth){
			a = a.view || a;
			var v = this.view;
			if (v.contains && !CC.safari) {
         return v.contains(a);
      }else if (v.compareDocumentPosition) {
         return !!(v.compareDocumentPosition(a) & 16);
      } 
            
			if(depth === undefined)
				depth = 65535;
			var p = a.parentNode, bd = document.body;
			while(p!= bd && depth>0 && p !== null){
				if(p == v)
					return true;
				p = p.parentNode;
				depth--;
			}
			return false;
		},
		
    domEvent : function(evName, handler, cancel, caller, childId, useCapture) {
    		if (evName == 'keypress' && (navigator.appVersion.match( / Konqueror | Safari | KHTML / )
            || this.view.attachEvent)) {
            evName = 'keydown';
        }
        
    		if(!this.observes){
    			this.observes = [];
    		}
    		
        var self = caller || this;
        var cb = (function(ev){
        	  var ev = ev || window.event;
        	  if(self.disabled){
        	  	Event.stop(ev);
        	  	return false;
            }
            if(cancel)
                Event.stop(ev);
            return handler.call(self, ev);
        });
        
    		
    		if(childId){
    			childId = this.dom(childId);
    			if(!childId)
    				return this;
 
    			this.observes.push([evName, handler, cb, childId, useCapture]);
    		}
    		else{
    			childId = this.view;
    			this.observes.push([evName, handler, cb]);
    		}
        
        if (childId.addEventListener) {
            childId.addEventListener(evName, cb, useCapture);
        } else if (childId.attachEvent) {
            childId.attachEvent('on' + evName, cb);
        }
        return this;
    },
  
    unDomEvent : function(evName, handler, childId){
    	if (evName == 'keypress' && (navigator.appVersion.match( / Konqueror | Safari | KHTML / )
            || this.view.attachEvent)) {
            evName = 'keydown';
      }
    	var obs = this.observes;
    	if(!obs)
    	  return;
			childId = childId !== undefined?childId.tagName? childId : this.dom(childId) : this.view;
      for(var i=0,len=obs.length;i<len;i++){
      	var c = obs[i];
      	if(c[0]==evName && c[1] == handler && (c[3]== childId || c[3] === undefined)){
      		if (childId.removeEventListener) {
            childId.removeEventListener(evName, c[2], c[4]);
	        } else if (childId.detachEvent) {
	            childId.detachEvent('on' + evName, c[2]);
	        }
	        obs.remove(i);
	        return this;
      	}
      }
    },
  	
    bindEnter : function(callback,cancel, caller, childId){
        return this.domEvent('keydown',(function(ev){
            if(Event.isEnterKey(ev)){
                //#fixbug : change cancel false in domEvent param , instead of when is enter. 09-03-21
                if(cancel)
                	Event.stop(ev);
                callback.call(this, ev);
            }
        }),false, caller, childId);
    },
  
    bindAlternateStyle: function(evtHover, evtOff, css, cancel, onBack, offBack, caller, childId, targetId) {
        var a = evtHover+'Node',b=evtHover+'Target';
        var obj = childId || this[a],tar= targetId || this[b];
        if(obj){
            obj = this.dom(obj);
            delete this[a];
         }else obj = this.view;
        
        if(tar){
        	tar = this.dom(tar);
        	delete this[b];
        }else tar = this.view;
        
        var self = this;
        
        if(tar == this.view){
          onBack = onBack || self[evtHover+'Callback'];
          offBack = offBack || self[evtOff+'Callback'];
        }
        
        this.domEvent(evtHover, (function(evt){
        	var ret = false;
        	if(onBack)
        		ret = onBack.call(this, evt);
        	if(ret !== true)
        		CC.addClass(tar,css);
        }), cancel, caller, obj);
        
        this.domEvent(evtOff, (function(evt){
        	var ret = false;
        	if(offBack)
        		ret = offBack.call(this, evt);
        	if(ret !== true)
        		CC.delClass(tar,css);
        }), cancel, caller, obj);        
        return this;
    },

    bindHoverStyle: function( css, cancel, onBack, offBack, oThis, childId, targetId) {
        return this.bindAlternateStyle('mouseover', 'mouseout', css || this.hoverCS, cancel, onBack || this.onMouseHover, offBack || this.onMouseOff, oThis || this, childId, targetId);
    }
    ,

    bindFocusStyle : function( css, cancel, onBack, offBack, oThis, childId, targetId) {
        return this.bindAlternateStyle('focus', 'blur', css, cancel, onBack || this.onFocusHover, offBack || this.onFocusOff, oThis || this, childId, targetId);
    },
  
    bindClickStyle: function(css, cancel, downBack, upBack, oThis, childId, targetId) {
        this.bindAlternateStyle('mousedown', 'mouseup', css, cancel, downBack, upBack, oThis, childId, targetId);
        //防止鼠标按下并移开时样式未恢复情况.
        this.domEvent('mouseout', function(){
        	if(!this.docked)
        		this.delClass(css);
        });
        return this;
    }
    ,

    bindContext : function(callback,cancel, caller, childId, cssTarget, cssName) {
        if(this.contexted)
        	return this;
        
        var tar = childId ? this.dom(childId) : this.view;
        if(!caller)
        	caller = this;
        var self = this;
        var releaseCall = (function(evt) {
        	  var f = tar == self.view ? self : CC.fly(tar);
        	  if(evt){
	        		var src  = Event.element(evt);
	        		if(src == tar || f.ancestorOf(src)){
	        			f.unfly();
	        			return;
	        		}
            }
            if(callback)
                if(callback.call(caller, evt, tar)===false)
                    return;
            Event.removeListener(document, 'mousedown', arguments.callee);
            self.contexted = false;
            delete self.__contextedCallback;
            if(cssTarget){
        			CC.fly(cssTarget).delClass(cssName).unfly();
        		}
            f.display(0).unfly();
        }
        );
        
        Event.addListener(document, 'mousedown', releaseCall);
        this.contexted = true;
        this.__contextedCallback = releaseCall;
        if(cssTarget){
        	CC.fly(cssTarget).addClass(cssName).unfly();
        }
        return this;
    },
    
    releaseContext : function(){
    	this.__contextedCallback();
    },
    
    /**
	 * 绑定使得一个元素具有拖动和放下过程中具有ondrag, ondrop, ondragstart事件.
	 * ondragstart.call(element,event)
	 */
    bindDragDrop : function(dragNode, calcelBubble) {
        var proxy = this.view, G = CGhost.instance;
        if(dragNode || this.dragNode)
        	proxy = this.dom(dragNode || this.dragNode);
				this.draggable = true;
				//firefox
				if(CC.gecko)
					proxy.draggable = true;
        proxy._ddrTrigger = (function(event){
            if(!this.draggable)
            	return;
            //mark the initial xy.
            var ev = event||window.event, el = this;
            //save mouse xy,and element position info.
            //MX:开始按下时鼠标X坐标,MY:开始按下时鼠标Y坐标,EX:开始始下时元素X,..EY,EW,EH其它类推
            G.IPXY = G.PXY = Event.pageXY(ev);
            G.EW=el.view.offsetWidth;
            G.EH=el.view.offsetHeight;
						if(el.beforeDragStart(el)===false)
							return false;
						
            window.document.ondragstart = G._noddrAction;

            Event.addListener(document, "mouseup", G._ddrMouseUp);
            Event.addListener(document, "mousemove", G._ddrMouseMove);
            Event.addListener(document, "selectstart", Event.noSelect);
            G.ddrEl = el;
            //Event.stop(ev);
        });
        
        this.domEvent('mousedown', proxy._ddrTrigger, calcelBubble, null, proxy);
    },
	
    unDragDrop : function(dragNode){
    		this.draggable = false;
        var proxy = this.view;
        if(dragNode || this.dragNode)
        	proxy = this.dom(dragNode || this.dragNode);
        this.unDomEvent('mousedown', proxy._ddrTrigger);
    },
	
    /**
	 * 绑定使得一个元素具有监听拖放事件功能.
	 * ondragover 返回true表示可接受Drop.
	 */
    bindDDRListener : function(dragNode) {
        var proxy = this.view, G = CGhost.instance;
        if(dragNode || this.dragNode )
        	proxy = this.dom(dragNode || this.dragNode);
        this.ondropable = true;
        proxy._ddrMouseover = (function(event){
            if(!G.draging || G.ddrEl == this || !this.ondropable)
                return;
            var ev = event || window.event;
            //Event.stop(ev);
            //注册DDR OVER 结点
            G.onEl = this;
            var data = G.ddrEl.dragOverSB(this, ev);
            if(data === false)
                return;
				
            data = this.dragSBOver(G.ddrEl, data, ev);
				
            //mark current returned state.
            G.setAcceptable(data);
        });
		
        proxy._ddrMouseout = (function(event){
            if(!G.onEl || !this.ondropable)
                return;
            
            var ev = event || window.event, el = this;
            if(G.onEl.dragOutSB(el, ev) === false){
                G.onEl = null;
                return;
            }
			
            el.dragSBOut(G.onEl, ev);
            G.onEl = null;
            G.setAcceptable(0);
        });
				
				this.domEvent('mouseover', proxy._ddrMouseover, false, null, proxy);
				this.domEvent('mouseout', proxy._ddrMouseout, false, null, proxy);
    },
	
    unDDRListener : function(dragNode) {
        var proxy = this.view;
        this.ondropable = false;
        if(dragNode || this.dragNode)
        	proxy = this.dom(dragNode || this.dragNode);
        this.unDomEvent('mouseover', proxy._ddrMouseover);
        this.unDomEvent('mouseout', proxy._ddrMouseout);
    },
    
    $$ : function(id) {
        var c = CC.$$(id, this.view);
        if(c){
         this.follow(c);
        }
        return c;
    },
  
    inspectDomAttr: function(childId, childAttrList, attrValue) {
        var obj = this.dom(childId);
        //??Shoud do this??
        if (!obj)
            return ;
    
        obj = CC.$attr(obj, childAttrList, attrValue);
        return obj;
    },

    setCloseable: function(b) {
        this.closeable = b;
        var obj = this.fly(this.closeNode || '_cls');
        if(obj)
            obj.display(b).unfly();
        return this;
    },
		
		offsetsTo : function(tar){
			  var o = this.absoluteXY();
			  tar = CC.fly(tar);
        var e = tar.absoluteXY();
        tar.unfly();
        return [o[0]-e[0],o[1]-e[1]];
		},
		
    scrollIntoView : function(container, hscroll){
        var c;
        if(container)
        	c = container.view || container;
        else c = CC.$body.view;
		var off = this.getHiddenAreaOffsetVeti(c);
		if(off !== false)
		c.scrollTop = off;
        //c.scrollTop = c.scrollTop;
        
        if(hscroll){
        	off = this.getHiddenAreaOffsetHori(container);
		 	if(off !== false)
			  c.scrollLeft = off;
        }
        
        return this;
    },

    scrollChildIntoView : function(child, hscroll){
        this.fly(child).scrollIntoView(this.view, hscroll).unfly();
        return this;
    },
    
	/**
	 * 检测元素是否在某个容器的可见区域内,如果在可见区域内，返回false,
	 * 否则返回元素偏离容器的scrollTop,利用该scrollTop可将容器可视范围滚动到元素处。 
	 */
	getHiddenAreaOffsetVeti : function(container){
        var c = container.view || container;
        var el = this.view;

        var o = this.offsetsTo(c),
		        ct = parseInt(c.scrollTop, 10),
		        //相对container的'offsetTop'
		        t = o[1] + ct,
		        eh = el.offsetHeight,
		        //相对container的'offsetHeight'
		        b = t+eh,
		        
		        ch = c.clientHeight,
            //scrollTop至容器可见底高度
            cb = ct + ch;
        if(eh > ch || t < ct){
        	return t;
        }else if(b > cb){
        	  b -= ch;
        	  if(ct != b){
			  	return b;
          	}
        }
		
		return false;
	},
	
	getHiddenAreaOffsetHori : function(container){
		var c = container.view || container;
		var el = this.view;
        var cl = parseInt(c.scrollLeft, 10),
		    o = this.offsetsTo(c),
            l = o[0] + cl,
            ew = el.offsetWidth,
            cw = c.clientWidth,
            r = l+ew, 
            cr = cl + cw;
		if(ew > cw || l < cl){
		    return l;
		}else if(r > cr){
		   	r -= cw;
		   	if(r != cl){
		   		return r;
		     }
		}
		return false;
	},
	
    toString : function(){
        return this.title || this.id;
    },
  
    beforeDragStart : fGo,
    dragStart : fGo,
    drag : fGo,
    dragOverSB : fGo,
    dragSBOver : fGo,
    dragSBOut : fGo,
    dragOutSB : fGo,
    dropSB : fGo,
    SBDrop : fGo,
    afterDrop:fGo
});

CBase.create = function(opt){
	  var comp;
	  if(CC.isString(opt)){
	  	comp = new CBase[arguments[0]](arguments[1]);
	  }else {
      comp = new CBase();
      comp.initialize(opt);
    }
    return comp;
};

bg.$$ = (function(dom, p) {
    if(!dom || dom.view)
        return dom;
	
    var c;
    if(!p){
        c = CC.$(dom);
        return c?new CBase(c) : null;
    }
	
    c = (p && p.view) ? CC.$(dom, p.view) : CC.$(dom, p);
    return c ? new CBase(c) : null;
});
//see unfly, fly
Cache.register('flycomp', function(){
	var c = new CBase();
	c.__flied = true;
	return c;
});

bg.fly = function(dom){
	if(dom){
		// string as an id
		if(typeof dom == 'string'){
			dom = CC.$(dom);
		}else if(dom.view){ // a component
			return dom;
		}
	}
	//actually, can not be null!
	if(!dom){
		console.trace();
		throw 'Node not found.';
	}
  // a DOMElement
	var c = Cache.get('flycomp');
	c.view = dom;
	return c;
};

if (isIE){
     
    CBase.prototype.getOpacity = function() {
        var element = this.view;
        if(element.filters[0])
            return parseFloat(element.filters[0].Opacity/100.0);
        value = ( this.getStyle(element, 'filter') || '').match(/alpha\(opacity=(.*)\)/); 
        if (value) { 
            if (value[1]) {
                return parseFloat(value[1]) / 100;
            }
        }
        return 1.0;  
    };
     
    CBase.prototype.setOpacity = function (opacity) {
       var st = this.view.style;
       st.zoom = 1;
       st.filter = (st.filter || '').replace(/alpha\([^\)]*\)/gi,"") + 
          (opacity == 1 ? "" : " alpha(opacity=" + opacity * 100 + ")");
       return this;
    };
}

Event.fire('created class CBase', CBase.prototype, CBase);

return bg;

})();


CC.create('CGhost', CBase, {
	
    okCS : 'g-ghost-ok',
	
    tip : false,
	
    ddrEl : null,

    onEl : null,
		
		height : 23,
    
    
    draging : false,
	
    resizeMask : null,
	
    enableTip : true,
	
    resizeCS : 'g-resize-ghost',
		
		resizeMaskCS : 'g-resize-mask',
		
    setAcceptable : function(b){
    	this.acceptable = !!b;
    	if(b){
    		this.addClass(this.okCS);
    		if(CC.ie)
    			this.setOpacity(1);
    	}
    	else{
    		this.delClass(this.okCS);
    		if(CC.ie)
    			this.setOpacity(0.5);
    	}
    },
	
    _ddrAction : function(event) {
        (event||window.event).returnValue = true;
    },
    
    _noddrAction:function(event){
        (event||window.event).returnValue = false;
    },
	
    _ddrMouseUp : function(event) {
        var G = CGhost.instance;
        window.document.ondragstart = G._ddrAction;
        //清空全局监听器
        Event.removeListener(document, "mouseup", G._ddrMouseUp);
        Event.removeListener(document, "mousemove", G._ddrMouseMove);
        Event.removeListener(document, "selectstart", Event.noSelect);

        var ev = event||window.event, ddrEl = G.ddrEl, onEl = G.onEl;
        G.PXY = Event.pageXY(ev);
        G.MDX = G.PXY[0] - G.IPXY[0];
        G.MDY = G.PXY[1] - G.IPXY[1];
        if(G.draging){
            //如果在拖动过程中松开鼠标
            if(ddrEl.dropSB(onEl, ev)===false)
                return;
            if(onEl  && G.acceptable)
                onEl.SBDrop(ddrEl, ev);
        }
        if(ddrEl)
        	ddrEl.afterDrop(ev);
        G.endDDR(ev);
    },
	
    _ddrMouseMove : function(event){
        var ev = event||window.event, G = CGhost.instance;
        G.PXY = Event.pageXY(ev);
        G.MDX = G.PXY[0] - G.IPXY[0];
        G.MDY = G.PXY[1] - G.IPXY[1];
        if(!G.draging) {
            G.draging = true;
            G.ddrEl.dragStart(ev);
		        G.display(G.enableTip);
        }
    
        if(G.enableTip) {
            G.setXY(G.PXY[0]+25, G.PXY[1]+20);
        }
    
        G.ddrEl.drag(ev);
    },
	
    endDDR : function(ev){
        if(this.enableTip) {
            this.display(0);
        }
		  
        this.onEl = null;
        this.ddrEl = null;
        this.draging = false;
        this.setAcceptable(false);
    },

    endResize : function(){
    	  this.coverDragMask(false);
        this.enableTip = this._tmpEnabled;
        this.resizeLayer.display(0);
        this.resizeMask.display(0);
        this.resizing = false;
    },
    
    startResize : function(opt){
        this._tmpEnabled = this.enableTip;
        this.enableTip = false;
        var r = this.resizeMask, ly = this.resizeLayer;
        //如果半透明层未创建
        if(!ly){
        	ly = this.resizeLayer = CBase.create({view:CC.$C('DIV'), showTo:document.body, autoRender:true,cs:this.resizeCS, hidden:true});
        }
        this.coverDragMask(true);
        ly.display(1);
        this.resizing = true;
    },
    
    coverDragMask : function(b){
    	var r = this.resizeMask;
      //如果客户区域掩层未创建
      if(!r)
       	r = this.resizeMask = CBase.create({view:CC.$C('DIV'), showTo:document.body, autoRender:true, cs:this.resizeMaskCS, hidden:true, unselectable:true});

      if(b && CC.ie)
        r.setSize(CC.getViewport());
      
      r.display(b);
    }
});


if(!window.CTemplate){
	CTemplate = {};
}

CTemplate['CGhost'] = '<div class="g-ghost"><div id="_ico" class="g-ghost-icon"></div><div class="g-ghost-txt" id="_tle">请问有什么提示?</div></div>';


/**
 * 不宜在注册Cache缓存时调用模板方法CTemplate.$, CTemplate.$$,CTemplate.remove,这将引起循环的递归调用,因为模板生成的结点缓存在Cache里的.
 */
CC.extend(CTemplate,{
    $ : (function(keyName,compName, prehandler){
        var node = Cache.get(keyName);
        if(!node){
            if(!compName)
                compName = keyName;
						var tp = this[compName];
						if(typeof tp == 'undefined')
							return null;
							
            var dv = Cache.get('div');
            dv.innerHTML = prehandler? prehandler(tp) : tp;
            node = dv.removeChild(dv.firstChild);
            Cache.put('div',dv);
            Cache.put(keyName,node);
        }
        
        return node.cloneNode(true);
    }),
	
    $$ : function(key) {
        return CC.$$(this.$(key));
    },
    
    remove : function(key) {
    	Cache.remove(key);
    	delete this[key];
    },
    
    forNode : function(strHtml, dataObj, st) {
    	if(dataObj)
    		strHtml = CC.templ(dataObj, strHtml, st);
      var dv = Cache.get('div'), node;
      dv.innerHTML = strHtml;
      node = dv.removeChild(dv.firstChild);
      Cache.put('div',dv);
      return node;
    }
});

//
// 执行库自身初始化,在一切的Event.ready注册函数之前调用.
//
Event.defUIReady = (function(){
	CC.$body = CC.$$(document.body);
	if(!document.body.lang)
		document.body.lang = "zh";
	CGhost.instance =new CGhost({showTo:document.body, hidden:true, autoRender:true});
});


//shadow.js
CTemplate['CShadow'] = '<div class="g-shadow" style="display:none;"><div class="g-shadow-t" id="_t"></div><div class="g-shadow-lt" id="_lt"></div><div class="g-shadow-rt" id="_rt"></div><div class="g-shadow-l" id="_l"></div><div class="g-shadow-lb" id="_lb"></div><div class="g-shadow-r" id="_r"></div><div class="g-shadow-rb" id="_rb"></div><div class="g-shadow-b" id="_b"></div></div>';
CC.create('CShadow', CBase, {
	shadowWidth : 6,
	inpactW : 6,
	inpactH : 0,
	inpactX : 3,
	inpactY : 3,
	hidden : true,
	initComponent : function(){
		//IE6无阴影效果
		if(!CC.ie6){
			this.showTo = document.body;
	  }

		CBase.prototype.initComponent.call(this);
		
		if(this.target)
		  	this.attachTarget(this.target);
		  	
		this.shadowR = this.dom('_r');
		this.shadowB = this.dom('_b');
		this.shadowL = this.dom('_l');
		this.shadowT = this.dom('_t');
	},
	
	attachTarget : function(target){
		this.target = target;
		if(CC.ie6) return this;
			
	  if(this.target.eventable){
				this.target.on('resized', this.onTargetResize, this);
				this.target.on('reposed', this.onTargetRepos, this);
		}
		this.setZ((this.target.getStyle('z-index') || 1)-1);
		return this;
	},
	
	detachTarget : function(){
		if(this.target.eventable){
				this.target.un('resized', this.onTargetResize, this);
				this.target.un('reposed', this.onTargetRepos, this);
		}
		this.target = null;
		this.display(false);
		return this;
	},
	
	onTargetResize : function(ba, bb, a, b){
    if(a === false && b === false)
    	return;
    this.setRightSize(ba, bb, a, b);
	},
	
	onTargetRepos : function(a, b){
		if(a === false && b === false)
			return;
		var pos = this.target.absoluteXY();
		this.setRightPos(pos);
	},
	
	setRightSize : function(ba, bb, a, b){
		if(a !== false){
			a = a+this.inpactW;
			if(a!=this.width)
				this.setWidth(a);
		}
		if(b !== false){
			b+=this.inpactH;
			if(b!=this.height){
				this.setHeight(b);
		  }
	  }
		//修正IE不能同时设置top, bottom的问题,设置具体高度
		if(CC.ie){
			var f = CC.fly(this.shadowR), d = this.shadowWidth*2;
			if(b !== false){
				h = b - d;
				f.setHeight(h);
				f.view = this.shadowL;
				f.setHeight(h);
			}
			if(a !== false){
				w = a - d;
				f.view = this.shadowB;
				f.setWidth(w);
				f.view = this.shadowT;
				f.setWidth(w);
		  }
			f.unfly();
	  }
	},
	
	setRightPos : function(pos){
		this.setXY(pos[0]-this.inpactX, pos[1]+this.inpactY - 1);
	},
	
	reanchor : function(){
		var s = this.target.getSize();
		
		this.onTargetResize(false, false, s.width, s.height);
		this.onTargetRepos();
		return this;
	},
	//
	//只有target显示时才显示阴影,否则忽略.
	//
	display : function(b){
		if(b===undefined)
			return CBase.prototype.display.call(this);
		return CBase.prototype.display.call(this, b && this.target && !this.target.hidden);
	}
}
);
//loading.js
CTemplate['CLoading'] = '<div class="g-loading"><div class="g-loading-indicator"><span id="_tle">加载中,请稍候...</span></div></div>';

CC.create('CLoading', CBase, {
	loadMaskCS:'g-loading-mask',
	//targetLoadCS:false,
	initComponent : function(){
		CBase.prototype.initComponent.call(this);
		if(this.target)
			this.attach(this.target);
	},
	
	attach : function(target){
		this.target = target;
		this.target.
		  on('open',this.whenOpen,this).
		  on('send',this.whenSend,this).
		  on('success',this.whenSuccess,this).
		  on('final',this.whenFinal,this);
	},
	
	whenSend : fGo,
	whenSuccess : function(){this.target.loaded = true;},
	whenOpen : function(){
		this.target.busy = true;
		this.markIndicator();
	},
	
	whenFinal : function(){
  	this.target.busy = false;
  	this.loaded = true;
  	this.stopIndicator();
  	if(this.target.shadow){
  		this.target.shadow.reanchor();
  	}
  },
  
	markIndicator : function(){
		if(this.disabled)
			return;
		if(this.targetLoadCS)
			CC.fly(this.target).addClass(this.targetLoadCS).unfly();
		//应用掩层
		if((!this.mask || !this.mask.tagName) && !this.maskDisabled){
			this.mask = CC.$C({tagName:'DIV', className:this.loadMaskCS});
		}
		if(!this.loadMsgDisabled){
			var f = CC.fly(this.target.scrollor || this.target).append(this.mask);
			//显示标题
			f.append(this).unfly();
		}
	},
	
	stopIndicator : function(){
		if(this.targetLoadCS) 
			CC.fly(this.target).delClass(this.targetLoadCS).unfly();
		if(!this.maskDisabled)
				this.mask.parentNode.removeChild(this.mask);
		if(!this.loadMsgDisabled)
			this.del();
	}
});
//container.js
CC.create('CItem', CBase, {});

/**
 *
 */
CC.create('CLayout', null, (function(){
    return {
        /**
         * 布局管理器对应的容器类
         * @cfg {CBase} container
         */
        container: null,
        /**
         * CContainerBase.container结点
         * @cfg {DOMElement} ctNode
         */
        ctNode: false,
        /**
         * 即存放子项DOM元素的容器DOM结点，即CContainerBase.wrapper封装对象，这里主要是方便布局引用
         * @cfg {CBase} wrapper
         */
        wrapper: false,
        /**
         * 一般情况下出于性能考虑子项移除时不重新布局容器的，如果需要重新布局，设置该值为true即可
         * @cfg {Boolean}
         */
        layoutOnChange: false,
        
        /**
         * 延迟多少毫秒后再布局,有利于提高用户体验
         */
        defferLayout : false,
        
        /**
         * 初始化布局
         * @param {Object} opt
         */
        initialize: function(opt){
            if (opt) 
                CC.extend(this, opt);
            var ct = CC.delAttr(this, 'container');
            if(ct)
            	this.attach(ct);
        },
        
        /**
         * 执行布局，要重写布局应重写onLayout方法。
         */
        doLayout: function(){
            if (this.invalidate || !this.container.rendered || this.hidden) 
                return;
            
            if(this.defferLayout !== false){
            	this.onLayout.bind(this).timeout(this.defferLayout);
            }
            else this.onLayout.apply(this, arguments);
        },
        
        /**
         * 容器在添加子项前被调用。
         * @param {CBase} comp 子项
         * @param {Object} cfg 子项用布局的配置信息
         */
        beforeAdd: fGo,
        
        /**
         * 当子项添加后被调用，此时容器不一定已渲染。
         * 方法将调用layoutChild方法执行对该子项的布局。
         * 如果容器已渲染，立即渲染子项。
         * @param {Object} comp
         * @param {Object} cfg
         */
        addComponent: function(comp, cfg){
            var cc = comp.layoutCfg;
            if (!cc) 
                comp.layoutCfg = cc = {};
            
            if (!cfg) 
                cfg = {};
            
            cc[this.type] = cfg;
            
            this.beforeAdd(comp, cfg);
            
            if(this.itemCS)
            	comp.addClass(this.itemCS);
            	
            if (this.invalidate || !this.container.rendered) 
                return;
            
            //子项布局后再渲染
            this.layoutChild(comp);
            
            if (!comp.rendered) 
                comp.render();
        },
        
        /**
         * 插入子项时执行，默认行为与removeComponent一致。
         * 子项可以相互插入，但如果新插入的子项之前并不在容器中时，建议先添加(add)后再插入。
         * @param {CBase}
         */
        insertComponent: function(comp){
            if (this.layoutOnChange) 
                 this.doLayout.bind(this).timeout(0);
        },
        
        /**
         * 如没有针对单个控件布局的可直接忽略.
         * @protected
         * @param {CBase} comp
         * @param {Object} cfg
         */
        layoutChild: fGo,
        /**
         * 除移子项时调用并重新布局。
         * 如果layoutOnChange设置为false时不调用。
         */
        removeComponent: function(comp){
        	  if(this.itemCS)
            	comp.delClass(this.itemCS);
            
            if (this.layoutOnChange) 
                this.doLayout.bind(this).timeout(0);
        },
        
        /**
         * 将布局管理器应用到一个容器控件中。
         * @param {Object} container
         */
        attach: function(container){
            this.container = container;
            this.ctNode = this.container.container;
            this.wrapper = this.container.wrapper;
            this.defferLayout = container.defferLayout || this.defferLayout;
            if (this.ctCS) 
                container.addClass(this.ctCS);
            if(this.wrCS)
            	container.wrapper.addClass(this.wrCS);
            return this;
        },
        
        /**
         * 移除容器的布局管理器。
         */
        detach: function(){
            var ct = this.container;
            if (this.ctCS) 
                ct.delClass(this.ctCS);
            if(this.wrCS)
            	ct.wrapper.delClass(this.wrCS);
            
            this.container = null;
            this.ctNode = null;
            this.wrapper = null;
            return this;
        },
        
        /**
         * 子项被容器布局后再渲染
         */
        onLayout: function(){
            var i = 0, ch, chs = this.container.children, len = chs.length;
            for (; i < len; i++) {
                ch = chs[i];
                this.layoutChild(ch);
                if (!ch.rendered) 
                    ch.render();
            }
        },
		
		displayItem : function(item, b){
		   if (this.layoutOnChange) 
               this.doLayout.bind(this).timeout(0);
		}
    }
})());

CLayout['default'] = CLayout;

CTemplate['CPanel'] = '<div class="g-panel"></div>';
CTemplate['CWrapPanel'] = '<div class="g-panel"><div class="g-panel-wrap" id="_wrap"></div></div>';

/**
 * 容器类控件.
 *@config keyEvent
 */
CC.create('CContainerBase', CBase, {

    children: null,
    
    eventable: true,
    
    container: null,
    
    minH: 0,
    
    minW: 0,
    
    maxH: 65535,
    
    maxW: 65535,
    
    ItemClass: CItem,
    
    autoRender: false,
    
    initComponent: function(){
        //调用父类初始化.
        CContainerBase.superclass.initComponent.call(this);
        if (this.layout) {
            if (CC.isString(this.layout)) {
            	  var cfg = this.layoutCfg || {};
            	  cfg.container = this;
                this.layout = new (CLayout[this.layout])(cfg);
                if(this.layoutCfg)
                	delete this.layoutCfg;
            }
            else 
                this.layout.attach(this);
        }
        else 
            this.layout = new CLayout({
                container: this
            });
        
        if (this.navKeyEvent) {
            this._bindNavKeyEvent();
        }
        
        if (this.useContainerMonitor && this.itemClickEvent) {
            this.itemAction(this.itemClickEvent === true ? 'mousedown' : this.itemClickEvent, this._containerClickTrigger, this.cancelItemClickBubble);
        }
        this.children = [];
    },
    
    createView: function(){
        CBase.prototype.createView.call(this);
        if (!this.container) 
            this.container = this.view;
        //apply container
        else 
            if (CC.isString(this.container)) {
                this.container = this.dom(this.container);
            }
        //再一次检测
        if (!this.container) 
            this.container = this.view;
        this.wrapper = this.container == this.view ? this : this.$$(this.container);
    },
    
    destoryComponent: function(){
        this.del();
        //clear the binded action of this container component.
        var cs = this.bndActs, n;
        if (cs) {
            while (cs.length > 0) {
                n = cs[0];
                this.unDomEvent(n[0], n[2], n[3]);
                cs.remove(0);
            }
        }
        this.destoryChildren();
        CContainerBase.superclass.destoryComponent.call(this);
        this.layout.detach();
    },
    
    onRender: function(){
        //不能在初始化函数里调用fromArray,因为控件未初始化完成时不能加入子控件.
        if (this.array) {
            this.fromArray(this.array);
            delete this.array;
        }
        
        CContainerBase.superclass.onRender.call(this);
        this.layout.doLayout();
    },
    
    /**
     *添加时默认子控件view将为container结点最后一个子结点,子类可重写该方法以自定子结点添加到容器结点的位置.
     */
    _addNode: function(dom, idx){
        if (idx === undefined) 
            this.container.appendChild(dom);
        else {
            this.container.insertBefore(this.container.childNodes[idx], dom);
        }
    },
    
    _removeNode: function(dom){
        this.container.removeChild(dom);
    },
    
    //向容器中添加一个控件.
    //控件即是本包中已实现的控件,具有基本的view属性.
    //对于只是一般的添加操作容器,可覆盖该方法,更得添加时变得更加快速,例如在一个Grid中,对子项控制要求较少,可直接重写个更有效的方法.
    add: function(a){
        if (!this.contains(a)) {
            if (a.parentContainer != null) 
                a.parentContainer.remove(a);
            this.children.push(a);
            
            //默认子项结点将调用_addNode方法将加到容器中.
            this._addNode(a.view);
            
            //建立子项到容器引用.
            a.parentContainer = this;
            //在useContainerMonitor为false时,是否允许子项点击事件,并且是否由子项自身触发.
            if (!this.useContainerMonitor && this.itemClickEvent && !a._clickTrigger) {
                var bnd = a._clickTrigger = this._itemClickTrigger;
                var clickProxy = this.itemClickEventNode ? a.dom(this.itemClickEventNode) : a.view;
                a.domEvent(this.itemClickEvent === true ? 'mousedown' : this.itemClickEvent, bnd, this.cancelItemClickBubble, null, clickProxy);
            }
            
            this.layout.addComponent.apply(this.layout, arguments);
        }
        return this;
    },
    
    _containerClickTrigger: function(item, evt){
        this.fire('itemclick', item, evt);
    },
    
    //子项点击事件回调,发送itemclick事件.
    _itemClickTrigger: function(event){
        var p = this.parentContainer;
        p.fire('itemclick', this, event);
    },
    
    //参数a可为控件实例或控件ID.
    remove: function(a){
        a = this.$(a);
        a.parentContainer = null;
        this.children.remove(a);
        this._removeNode(a.view);
        this.layout.removeComponent.apply(this.layout, arguments);
        return this;
    },
    
    removeAll: function(){
        var it, chs = this.children;
        this.invalidate();
        while (chs.length > 0) {
            it = chs[0];
            this.remove(it);
        }
        this.validate();
    },
    
    //移除容器所有子项.
    destoryChildren: function(){
        var it, chs = this.children;
        this.invalidate();
        while (chs.length > 0) {
            it = chs[0];
            this.remove(it);
            it.destoryComponent();
        }
        //this.validate();
    },
    
    //根据控件ID或控件自身或控件所在数组下标安全返回容器中该控件对象.
    $: function(id){
        if (id === null || id === undefined || id === false) {
            return null;
        }
        
        //dom node
        if (id.tagName) {
            var chs = this.children, v, bdy = this.view, d;
            for (var i = 0, len = chs.length; i < len; i++) {
                d = id;
                v = chs[i].view;
                if (v == d) 
                    return chs[i];
                d = d.parentNode;
                while (d !== bdy && d !== null) {
                    if (d === v) 
                        return chs[i];
                    d = d.parentNode;
                }
            }
            return null;
        }
        
        //number
        if (CC.isNumber(id)) {
            return this.children[id];
        }
        
        //component
        if (id.type) {
            if (this.children.indexOf(id) == -1) {
                return null;
            }
            return id;
        }
        
        var chs = this.children;
        
        for (var i = 0, len = chs.length; i < len; i++) {
            if (chs[i].id == id) {
                return chs[i];
            }
        }
        return null;
    },
    
    //设置容器中指定控件的显示属性.
    //b为true或false.
    //参数a可为控件实例或控件ID.
    displayItem: function(a, b){
        a = this.$(a);
        a.display(b);
		this.layout.displayItem(a, b);
        return a;
    },
    
    display : function(b){
    	if(b === undefined)
    		return CBase.prototype.display.call(this);
    	var h = this.hidden;
    	CBase.prototype.display.call(this, b);
    	if(b && h){
    		this.layout.doLayout();
    	}
    	return this;
    },
    
    //返回窗口中控件的索引.
    //参数a可为控件实例或控件ID.
    indexOf: function(a){
        a = this.$(a);
        return !a ? -1 : this.children.indexOf(a);
    },
    
    size: function(){
        return this.children.length;
    },
    //容器是否包含给出控件.
    //参数a可为控件实例或控件ID.
    contains: function(a){
        if (!a.type) {
            a = this.$(a);
        }
        return this.children.indexOf(a) != -1;
    },
    
    //b之前插入a.
    insertBefore: function(a, b){
        var idx = this.indexOf(b);
        this.insert(idx, a);
    },
    
    /**
     * 方法与_addNode保持一致,定义DOM结点在容器结点中的位置.
     */
    _insertBefore: function(n, old){
        this.container.insertBefore(n, old);
    },
    
    //插入前item 可在容器内.
    //在idx下标处插入item
    //即item放在原idx处项之前
    insert: function(idx, item){
        var nxt = this.children[idx];
        if (item.parentContainer) {
            item.parentContainer.remove(item);
        }
        item.parentContainer = this;
        //在useContainerMonitor为false时,是否允许子项点击事件,并且是否由子项自身触发.
        if (!this.useContainerMonitor && this.itemClickEvent && !item._clickTrigger) {
            var bnd = item._clickTrigger = this._itemClickTrigger;
            var clickProxy = this.itemClickEventNode ? item.dom(this.itemClickEventNode) : item.view;
            item.domEvent(this.itemClickEvent === true ? 'mousedown' : this.itemClickEvent, bnd, this.cancelItemClickBubble, null, clickProxy);
        }
        //如果项在容器中,被删除后重新计算idx
        idx = this.indexOf(nxt);
        if (idx == -1) 
            idx = 0;
        this.children.insert(idx, item);
        
        if (nxt) 
            this._insertBefore(item.view, nxt.view);
        else 
            this._addNode(item.view);
        
        this.layout.insertComponent.apply(this.layout, arguments);
        return this;
    },
    
    clear: function(){
        var ch = this.children;
        for (var i = 0, len = ch.length; i < len; i++) {
            this.remove(ch[0]);
        }
        return this;
    },
    
    swap: function(a1, a2){
        var ch = this.children;
        var idx1 = this.indexOf(a1);
        var idx2 = this.indexOf(a2);
        a1 = this.children[idx1];
        a2 = this.children[idx2];
        ch[idx1] = a2;
        ch[idx2] = a1;
        
        var n1 = a1.view;
        var n2 = a2.view;
        
        if (n1.swapNode) {
            n1.swapNode(n2);
        }
        else {
            var p = n2.parentNode;
            var s = n2.nextSibling;
            
            if (s == n1) {
                p.insertBefore(n1, n2);
            }
            else 
                if (n2 == n1.nextSibling) {
                    p.insertBefore(n2, n1);
                }
                else {
                    n1.parentNode.replaceChild(n2, n1);
                    p.insertBefore(n1, s);
                }
        }
        return this;
    },
    /**
     *对容器控件进行排序,采用Array中sort方法,排序后控件的DOM结点位置也随之改变.
     */
    sort: function(comparator){
        var chs = this.children;
        if (comparator === undefined) 
            chs.sort();
        else 
            chs.sort(comparator);
        
        var oFrag = document.createDocumentFragment();
        for (var i = 0, len = chs.length; i < len; i++) {
            oFrag.appendChild(chs[i].view);
        }
        
        this.container.appendChild(oFrag);
        this.sorted = true;
        return this;
    },
    
    reverse: function(){
        var chs = this.children;
        chs.reverse();
        
        var oFrag = document.createDocumentFragment();
        for (var i = 0, len = chs.length; i < len; i++) {
            oFrag.appendChild(chs[i].view);
        }
        
        this.container.appendChild(oFrag);
        return this;
    },
    
    filter: function(matcher, caller){
        var caller = caller || window;
        CC.each(this.children, (function(){
            if (!matcher.call(caller, this)) {
                this.display(0);
                return;
            }
            this.display(1);
        }));
        return this;
    },
    
    filterBy: function(callback, attrName, attrV, strictEq){
        var chs = this.children, len = this.children.length, i = 0, it, useEq = strictEq || false, rt, v;
        for (; i < len; i++) {
            it = chs[i];
            if (useEq) {
                if (it[attrName] === attrV) 
                    rt = callback.call(it);
            }
            else {
                v = it[attrName] || false;
                if (v == attrV) 
                    rt = callback.call(it);
            }
            if (rt === false) 
                break;
        }
        return this;
    },
    
    each: function(cb, caller){
        for (var i = 0, len = this.children.length; i < len; i++) {
            var it = this.children[i];
            var rt = cb.call(caller || it, it, i);
            if (rt === false) 
                break;
        }
    },
    
    /**
     * 是否为控件的父容器
     */
    parentOf: function(child){
        if (!child) 
            return false;
        if (child.parentContainer == this) 
            return true;
        var self = this;
        var r = CC.eachH(child, 'parentContainer', function(){
            if (this == self) 
                return 1;
        });
        return r == true;
    },
    
    fromArray: function(array, itemclass){
        itemclass = itemclass || this.ItemClass;
        if (CC.isString(itemclass)) {
            itemclass = window[itemclass];
        }
        var item, itemOpts = this.itemOptions || false;
        
        for (var i = 0, len = array.length; i < len; i++) {
            item = array[i];
         if(!item.cacheId){
            if (itemOpts) 
                CC.extendIf(item, itemOpts);
            item = new (itemclass)(item);
            //层层生成子项
            if (item.array && item.children) {
                item.fromArray(item.array);
                delete item.array;
            }
          }
            this.add(item);
        }
        return this;
    },
    
    connect: function(url, cfg){
        url = url || this.url;
        if (!cfg) 
            cfg = {};
        cfg.url = url;
        cfg.caller = this;
        if (!cfg.onsuccess) 
            cfg.onsuccess = this.defLoadSuccess;
        if (!this.indicatorDisabled && !this.loadIndicator) {
            this.getLoadIndicator();
        }
        
        var a = new Ajax(cfg);
        a.to(this);
        a.connect();
        return this;
    },
    
    getLoadIndicator: function(opt){
        if (!this.indicatorDisabled && !this.loadIndicator) {
            var cfg = {
                target: this,
                targetLoadCS: this.loadCS
            };
            if (opt) 
                opt = CC.extend(cfg, opt);
            this.loadIndicator = new (this.LoadingClass || window['CLoading'])(cfg);
            this.follow(this.loadIndicator);
        }
        return this.loadIndicator;
    },
    
    defLoadSuccess: function(ajax){
        var json = ajax.getJson();
        this.fromArray(json);
    },
    
    itemAction: function(eventName, callback, cancelBubble, caller, childId, srcName){
        var act = (function(event){
            var el = event.target || event.srcElement;
            if (srcName !== undefined) {
                if (el.tagName != srcName) 
                    return;
            }
            
            if (el === this.view) 
                return;
            var item = this.$(el);
            if (item) {
                if (item.disabled) 
                    return false;
                callback.call(this, item, event);
            }
        });
        if (!this.bndActs) {
            this.bndActs = [];
        }
        this.bndActs.push([eventName, callback, act]);
        this.domEvent(eventName, act, cancelBubble, caller, childId);
        return this;
    },
    
    unItemAction: function(eventName, callback, childId){
        var bnds = this.bndActs;
        childId = childId !== undefined ? childId.tagName ? childId : this.dom(childId) : this.view;
        for (var i = 0, len = bnds.length; i < len; i++) {
            var n = bnds[i];
            if (n[0] == eventName && n[1] == callback(n[3] == childId || n[3] === undefined)) {
                this.unDomEvent(eventName, n[2], n[3]);
                bnds.remove(i);
                return this;
            }
        }
        
        return this;
    },
    
    _bindNavKeyEvent: function(){
        var kev = this.navKeyEvent === true ? 'keydown' : this.navKeyEvent;
        var node = this.keyEventNode = this.keyEventNode ? this.dom(this.keyEventNode) : this.container;
        if (node.tabIndex == -1) {
            //ie won't works.
            node.tabIndex = 0;
            node.hideFocus = 'on';
        }
        this.domEvent(kev, this._onKeyPress, this.cancelKeyBubble, null, node);
    },
    
    _onKeyPress: function(evt){
        if (this.disabled || this.fire('keydown', evt) === false) 
            return;
        this.onKeyPressing(evt);
    },
    
    onKeyPressing: fGo,
    
    //立即布局当前容器.
    validate: function(){
        this.layout.invalidate = false;
        this.layout.doLayout();
        return this;
    },
    
    invalidate: function(){
        this.layout.invalidate = true;
    },
    
    //布局当前容器,如果当前容器正处于布局变更中,并不执行布局.
    doLayout: function(){
        if (!this.layout.invalidate && this.rendered) 
            this.layout.doLayout.apply(this.layout, arguments);
        return this;
    },
    
    acceptDrop: function(comp){
        return comp.parentContainer && comp.parentContainer.type == this.type;
    },
    
    ondrop: function(comp){
        this.add(comp);
    }
});

CC.create('CSelectedContainer', CContainerBase, function(superclass){

    return {
    
        itemClickEvent: true,
        
        //Object
        selected: null,
        
        selectedIndex: -1,
        
        previousSelected: null,
        
        selectedCS: 'selected',
        
        initComponent: function(){
        
            if (this.navKeyEvent) {
                this.KEY_UP = this.KEY_UP || Event.KEY_UP;
                this.KEY_DOWN = this.KEY_DOWN || Event.KEY_DOWN;
            }
            
            superclass.initComponent.call(this);
            
            if (this.itemCallback) {
                this.on('selected', this._itemCallback);
                delete this.itemCallback;
            }
            
            this.on('itemclick', this._onItemClick);
        },
        
        _onItemClick: function(item, evt){
            this.select(item, this.forceSelect);
        },
        
        _itemCallback: function(item){
            if (item.callback) {
                return item.callback.call(item, item);
            }
        },
        
        onKeyPressing: function(ev){
            var kc = ev.keyCode;
            if (kc == this.KEY_UP) {
                this.selectPre();
                Event.stop(ev);
            }
            else 
                if (kc == this.KEY_DOWN) {
                    this.selectNext();
                    Event.stop(ev);
                }
                else 
                    return this._defKeyNav(ev);
        },
        
        _defKeyNav: fGo,
        
        selectNext: function(){
            var idx = this.selectedIndex + 1, cs = this.children, len = this.children.length;
            while (idx <= len - 1 && (cs[idx].disabled || cs[idx].hidden)) {
                idx++;
            }
            if (idx >= 0 && idx <= len - 1) {
                this.select(cs[idx]);
                return cs[idx];
            }
            return null;
        },
        
        selectPre: function(){
            var idx = this.selectedIndex - 1, cs = this.children, len = this.children.length;
            while (idx >= 0 && (cs[idx].disabled || cs[idx].hidden)) {
                idx--;
            }
            if (idx >= 0 && idx <= len - 1) {
                this.select(cs[idx]);
                return cs[idx];
            }
            return null;
        },
        
        remove: function(a){
            if (this.selected == a) 
                this.select(null);
            superclass.remove.call(this, a);
        },
        
        //选择某个控件,
        //参数a可为控件实例也可为id或数组下标.
        //选择空时a为null
        select: function(a, forceSelect){
            a = this.$(a);
            if ((a && a.disabled) || (a == this.selected && !forceSelect)) 
                return this;
            if (this.fire('select', a) === false) 
                return this;
            this.onSelect(a);
            if (a) {
                this.fire('selected', a);
                if (this.buddleFire && this.parentContainer) 
                    this.parentContainer.fire('selected', a);
            }
            return this;
        },
        
        
        onSelect: function(a){
            var cs = this.selectedCS;
            this.previousSelected = this.selected;
            if (this.previousSelected && cs) {
                if (this.selectedCSTarget) 
                    this.previousSelected.fly(this.selectedCSTarget).delClass(cs).unfly();
                else 
                    this.previousSelected.delClass(cs);
            }
            this.selected = a;
            this.selectedIndex = this.indexOf(a);
            if (!a) 
                return this;
            
            if (cs) {
                if (this.selectedCSTarget) 
                    a.fly(this.selectedCSTarget).addClass(cs).unfly();
                else 
                    a.addClass(cs);
            }
            if (!this.cancelScrollIntoView) {
                if (this.scrollor) 
                    a.scrollIntoView((this.scrollor.wrapper || this.scrollor).view || this.scrollor, this.hscroll);
                else 
                    a.scrollIntoView(this.container, this.hscroll);
            }
        },
        
        focus: function(timeout){
            if (this.disabled) 
                return this;
            var ct = this.keyEventNode || this.container;
            if (timeout) 
                (function(){
                    try {
                        ct.focus();
                    } 
                    catch (ee) {
                    }
                }).timeout(0);
            else 
                try {
                    ct.focus();
                } 
                catch (e) {
                }
            return this;
        }
    };
});

/**
 *
 */
CC.create('CPanel', CContainerBase, (function(superclass){
    
    return {
        container: '_wrap',
        defferLayout : true,
        initComponent: function(){
            var w = false, h = false;
            if (this.width !== false) {
                w = this.width;
                this.width = false;
            }
            
            if (this.height !== false) {
                h = this.height;
                this.height = false;
            }
            
            if(this.insets){
            	var m = this.insets;
            	m[4] = m[0]+m[2];
            	m[5] = m[1]+m[3];
            }            
            superclass.initComponent.call(this);
            
            if(this.insets){
            	var m = this.insets;
            	this.wrapper.setXY(m[3], m[0]);
            }
            
            if (w !== false || h !== false) 
                this.setSize(w, h);
        },
        //
        // 得到容器距离边框矩形宽高.
        // 该值应与控件CSS中设置保持一致,
        // 用于在控件setSize中计算客户区宽高,并不设置容器的坐标(Left, Top).
        //
        getWrapperInsets: function(){
            return this.insets || [0, 0, 0, 0, 0, 0];
        },
        
        /**
         *@override 计算容器和Wrapper合适的宽高.
         */
        setSize: function(a, b){
            if (a === this.width) {
                a = false;
            }
            if (b === this.height) {
                b = false;
            }
            
            if (a === false && b === false) 
                return this;
            
            var ba = false, bb = false, rs = false, wr = this.wrapper, ic = this.getWrapperInsets(), dx = 0, dy = 0, calWr = !!ic;
            if (a !== false) {
                if (a.width !== undefined) {
                    var c = a;
                    a = c.width;
                    b = c.height;
                }
                if (a < this.minW) 
                    a = this.minW;
                if (a > this.maxW) 
                    a = this.maxW;
                if (calWr) 
                    ba = a - ic[5];
                if (ba < 0) 
                    ba = 0;
                if (wr.width != ba) 
                    rs = true;
                
                dx = a - (this.width || this.getWidth(true));
            }
            
            if (b !== false) {
                if (b < this.minH) 
                    b = this.minH;
                if (b > this.maxH) 
                    b = this.maxH;
                if (calWr) 
                    bb = b - ic[4];
                if (wr.height != bb) 
                    rs = true;
                dy = b - (this.height || this.getHeight(true));
            }
            
            superclass.setSize.call(this, a, b);
            
            if (calWr && wr.view != this.view && rs) {
                wr.setSize(ba, bb);
            }
            
            this.fire('resized', ba, bb, a, b, dx, dy);
            this.doLayout(ba, bb, a, b, dx, dy);
            
            return this;
        },
        
        setXY: function(a, b){
            if (CC.isArray(a)) {
                b = a[1];
                a = a[0];
            }
            var dl = 0, dt = 0;
            if ((a !== this.left && a !== false) || (b !== this.top && b !== false)) {
                if (a !== this.left && a !== false) {
                    this.style('left', a + 'px');
                    dl = a - this.left;
                    this.left = a;
                }
                else 
                    a = false;
                
                if (b !== this.top && b !== false) {
                    this.style('top', b + 'px');
                    dt = b - this.top;
                    this.top = b;
                }
                else 
                    b = false;
                if (a !== false || b !== false) {
                    this.fire('reposed', a, b, dl, dt);
                }
            }
            
            return this;
        }
    };
}));
  
CPanel.getBorderPanel = (function(cp){
  var borderOpts = {
  	insets : [1, 1, 1, 1],
  	template : 'CWrapPanel',
  	container : '_wrap',
  	inherentCS :'g-borderpanel',
  	wrapperCS :'g-borderpanel-wrap'
  };
  
  return function(opt, cls){
  	if(!opt)
  		opt = {};
  	CC.extendIf(opt, borderOpts);
  	var c = new (cls||cp)(opt);
  	if(!c.wrapper.hasClass(c.wrapperCS))
  		c.wrapper.addClass(c.wrapperCS);
  	return c;
  };
})(CPanel);
  
CC.create('CSelectedPanel', CSelectedContainer, CPanel.constructors);



//viewport.js
CC.create('CViewport', CPanel, {
	
	template:'DIV',
	
	bodyCS : 'g-viewport-body',
	
	cs : 'g-viewoport',
	
	initComponent : function(){
		
		this.showTo = document.body;
		
		if(!this.view)
			this.view = CC.$C('DIV');
		Event.addListener(window, 'resize', this.onWindowResize.bind(this));
		CPanel.prototype.initComponent.call(this);
		CC.$body.addClass(this.bodyCS);
		this.onWindowResize();
	},
	
	onWindowResize : function(){
			var vp = CC.getViewport();
			this.setSize(vp);
	}
}
);

//spliter.js
CC.create('CSpliter', CBase, function(superclass){
	return {
		maxLR : Math.MAX_VALUE,
		minLR : Math.MIN_VALUE,
		maxTB : Math.MAX_VALUE,
		minTB : Math.MIN_VALUE,
		autoRestrict : true,
		draggable : true,
		container : null,
		inherentCS : 'g-layout-split',
		ghost : true,
		onSplitStart : fGo,
		onSplit : fGo,
		onSplitEnd : fGo,
		enableResizeMasker : false,
		unselectable : true,
		
		initComponent : function(){
			superclass.initComponent.call(this);
			this.appendTo(this.container);
		},
		
		beforeDragStart : function(){
				this.initX = this.left;
				this.initY = this.top;
				if(this.ghost) {
					var sg = this.splitGhost;
					if(!sg){
						sg = this.splitGhost = CC.$$(CC.$C({tagName:'DIV', className:this.ghostCS||'g-layout-sp-ghost'}));
						sg.appendTo(this.container);
					}
					this.copyViewport(sg);
					sg.display(1);
			  }
				this.initSPX = this.left;
				this.initSPY = this.top;
				var G = CGhost.instance;
				G.enableTip = false;
				if(!this.disableAutoStrict)
					this.calculateRestrict();
				this.onSplitStart();
				
				if(this.enableResizeMasker){
					G.coverDragMask(true);
					G.resizeMask.style('cursor', this.style('cursor'));
				}
		},
		
		calculateRestrict : function(){
				var c = CC.fly(this.container.view || this.container);
				if(!this.disableLR){
					var i = this.getLeft();
					this.minLR = -1*i;
					this.maxLR = c.getWidth() - (i+this.getWidth());
				}
				
				if(!this.disableTB){
					var i = this.getTop();
					this.minTB = -1*i;
					this.maxTB = c.getHeight() - (i+this.getHeight());
				}
				c.unfly();
		},
		
		applyDeltaXY : function(dx, dy){
			var d;
			if(!this.disableTB){
					if(dy < this.minTB)
						dy = this.minTB;
					else if(dy > this.maxTB)
						dy = this.maxTB
					d = this.initSPY+dy;
					if(this.ghost)
						this.splitGhost.setTop(d);
					else if(this.syncView)
					this.setTop(d);
					this.splitDY = dy;
			}
				
			if(!this.disableLR){
					if(dx < this.minLR)
						dx = this.minLR;
					else if(dx > this.maxLR)
						dx = this.maxLR;
					
					d = this.initSPX+dx;
					if(this.ghost)
					 this.splitGhost.setLeft(d);
					else if(this.syncView)
						this.setLeft(d);
					this.splitDX = dx;
			}
		},
		
		drag : function(ev){
			  var G = CGhost.instance;
				this.applyDeltaXY(G.MDX, G.MDY);
				this.onSplit();
		},
		
		afterDrop : function(){
			  var G = CGhost.instance;
				if(this.ghost)
					this.splitGhost.display(0);
					var t1 = this.ghost, t2 = this.syncView;
					this.ghost = false;
					this.syncView = true;
					this.applyDeltaXY(G.MDX, G.MDY);
					this.ghost = t1;
					this.syncView = t2;
					this.onSplitEnd();
					if(this.splitGhost){
						this.splitGhost.destoryComponent();
						delete this.splitGhost;
					}
				
				if(this.enableResizeMasker){
					var G = CGhost.instance;
					G.coverDragMask(false);
					G.resizeMask.style('cursor','');
				}
	  }
	};
});


//borderlayout.js
/**
 * 与Java swing中的BorderLayout具有相同效果.
 * 将容器内控件作为沿边框布局.
 */
/**
 * 类似Java Swing BorderLayout
 */
CTemplate['CBorderLayoutSpliter'] = '<div class="g-layout-split"></div>';
CC.create('CBorderLayout', CLayout, function(superclass) {
  var CBorderLayoutSpliter = CC.create(CSpliter, function(spr) {

    return {

      type: 'CBorderLayoutSpliter',
      enableResizeMasker : true,
      initComponent: function() {
        this.container = this.layout.wrapper;
        if (this.dir == 'north' || this.dir == 'south') this.disableLR = true;
        else this.disableTB = true;
        spr.initComponent.call(this);
        this.domEvent('dblclick', this.onDBClick);
      },

      onDBClick: function() {
      },

      calculateRestrict: function() {
        var ly = this.layout,
        wr = this.container;
        var max, min, dir = this.dir,
        comp = ly[dir],
        op,
        cfg = comp.layoutCfg[ly.type],
        lyv = ly.vgap,
        lyh = ly.hgap,
        vg = cfg.gap == undefined ? lyv: cfg.gap,
        hg = cfg.gap == undefined ? lyh: cfg.gap,
        cfg2,cbg = ly.cgap,cg,
        ch = wr.height,
        cw = wr.width;
        switch (dir) {
        case 'north':
          min = -1 * comp.height;
          max = ch + min - vg;
          op = ly.south;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	max -= cg;
            }
            if(!op.hidden && !op.contexted)
            	max -= op.height + (cfg2.gap == undefined ? lyv: cfg2.gap);
          }

          if(max>comp.maxH-comp.height)
          	max = comp.maxH - comp.height;
          if(Math.abs(min)>comp.height - comp.minH)
          	min = -1*(comp.height - comp.minH);
          break;
        case 'south':
          max = comp.height;
          min = -1 * ch + max + vg;
          op = ly.north;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	min += cg;
            }
            
            if(!op.hidden && !op.contexted)
            	min += op.height + (cfg2.gap == undefined ? lyv: cfg2.gap);
          }
          
          if(max>comp.height - comp.minH)
          	max = comp.height - comp.minH;
          if(Math.abs(min)>comp.maxH-comp.height)
          	min = -1*(comp.maxH-comp.height);
          break;
        case 'west':
          min = -1 * comp.width;
          max = cw + min - hg;
          op = ly.east;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	max -= cg;
            }
            if(!op.hidden && !op.contexted)
            	max -= op.width + (cfg2.gap == undefined ? lyh: cfg2.gap);
          }
          
          if(max > comp.maxW - comp.width)
          	max = comp.maxW - comp.width;
          if(Math.abs(min)>comp.width - comp.minW)
          	min = -1*(comp.width - comp.minW);
          break;
        case 'east':
          max = comp.width;
          min = -1 * cw + max + hg;
					op = ly.west;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	min += cg;
            }
            
            if(!op.hidden && !op.contexted)
            	min += op.width + (cfg2.gap == undefined ? lyh: cfg2.gap);
          }
          if(max > comp.width - comp.minW)
          	max = comp.width - comp.minW;
          if(Math.abs(min)>comp.maxW - comp.width)
          	min = -1*(comp.maxW - comp.width);
        }

        if (dir == 'west' || dir == 'east') {
          this.minLR = min;
          this.maxLR = max;
        } else {
          this.minTB = min;
          this.maxTB = max;
        }
      },

      applyDist: function(dt) {
        var c = this.layout[this.dir];
        //this.presize = this.enableH ? c.height:c.width;
        var wr = this.container;
        if (this.disableLR) {
          c.setHeight(this.dir == 'north' ? c.height + dt: c.height - dt);
        } else {
          c.setWidth(this.dir == 'west' ? c.width + dt: c.width - dt);
        }
        this.layout.doLayout();
      },

      onSplitEnd: function() {
        var c = this.layout[this.dir];
        //this.presize = this.enableH ? c.height:c.width;
        var wr = this.container;
        if (this.disableLR) {
          c.setHeight(this.dir == 'north' ? c.height + this.splitDY: c.height - this.splitDY);
        } else {
          c.setWidth(this.dir == 'west' ? c.width + this.splitDX: c.width - this.splitDX);
        }
        this.layout.doLayout();
      }
    };
  });
  
  CTemplate['CCollapseBarH'] = '<table cellspacing="0" cellpadding="0" border="0" class="g-layout-split"><tr><td class="cb-l"></td><td class="cb-c"><div class="expander" id="_expander"><a class="nav" id="_navblock" href="javascript:fGo()"></a></div></td><td class="cb-r"></td></tr></table>';
  CTemplate['CCollapseBarV'] = '<table cellspacing="0" cellpadding="0" border="0" class="g-layout-split"><tr><td class="cb-l"></td></tr><tr><td class="cb-c"><div class="expander" id="_expander"><a class="nav" id="_navblock" href="javascript:fGo()"></a></div></td></tr><tr><td class="cb-r"></td></tr></table>';
  var CBorderLayoutCollapseBar = CC.create(CContainerBase, {
		type : 'CBorderLayoutCollapseBar',
		
		hidden : true,
		
		inherentCS:'g-layout-cbar',
		
		container : '_expander',
		
		compContextedCS : 'g-layout-contexted',
		
		sliperCS : 'g-layout-sliper g-f1',
		
		navBlockCS : {
			       east:'g-nav-block-l',west:'g-nav-block-r',
			       south:'g-nav-block-u',north:'g-nav-block-d'
	  },
		
		initComponent : function(){
			this.template = (this.dir == 'south' || this.dir == 'north')?'CCollapseBarH' : 'CCollapseBarV';
			CContainerBase.prototype.initComponent.call(this);
		  if(this.dir == 'west' || this.dir == 'east'){
				this.addClass(this.inherentCS+'-v');
		  }else{
				this.itemOptions = {
					hoverCS:'g-smallbar-item-over',
					clickCS:'g-smallbar-item-click',
					inherentCS:'g-smallbar-item',
					focusCS : false,
					template : 'CBarItem'
				};
				this.ItemClass = CButton;
		  }
		  
			this.ItemClass = CBase['vbutton'];
			
			this.centerExpander = this.dom('_expander');
			this.navBlock = this.dom('_navblock');
			CC.fly(this.navBlock).addClass(this.navBlockCS[this.dir]).unfly();
			this.domEvent('mousedown', this.onBarClick, true);
			this.domEvent('mousedown', this.onNavBlockClick, true, null, this.navBlock);
			
			this.sliperEl = CC.$C({tagName:'A', className:this.sliperCS,href:'javascript:fGo()'});
			this.comp.wrapper.append(this.sliperEl);
			this.comp.domEvent('mousedown', this.sliperAction, false, null, this.sliperEl);
		},
		
		sliperAction : function(){
			this.parentContainer.layout.collapse(this, true);
		},
		
		/**
		 * 收缩按钮点击
		 */
		onNavBlockClick : function(){
			var c = this.comp;
			if(c.contexted)
				c.releaseContext();
			this.itsLayout.collapse(c, false);
		},
		
		/**
		 * 使得面板浮动
		 */
		makeFloat : function(){
			var c = this.comp;
			c.addClass(this.compContextedCS);
			c.display(true);
			this.setCompContextedBounds();
			var xy = c.absoluteXY();
			c.appendTo(document.body).setXY(xy);
			
			var cfg = c.layoutCfg[this.itsLayout.type];
			var sd = cfg.shadow;
			if(!sd){
				sd = cfg.shadow = new CShadow({inpactH:5,inpactY:-1});
				c.follow(sd);
			}
			
			sd.attachTarget(c)
			  .reanchor()
			  .display(true);
			if(!cfg.cancelAutoHide){
				this.resetAutoHideTimer();
				cfg.autoHideTimer = this.onTimeout.bind(this).timeout(cfg.autoHideTimeout||5000);
			}
		},
		
		onTimeout : function(){
			var c = this.comp;
			if(c.contexted)
				c.releaseContext();
			else this.unFloat();
			this.resetAutoHideTimer();
		},
		
		resetAutoHideTimer : function(){
			var cfg = this.comp.layoutCfg[this.itsLayout.type];
			if(cfg.autoHideTimer){
				clearTimeout(cfg.autoHideTimer);
				delete cfg.autoHideTimer;
			}
		},
		
		/**
		 * 面板复原
		 */
		unFloat : function(){
			var c = this.comp;
			var cfg = c.layoutCfg[this.itsLayout.type];
				
			if(cfg.autoHideTimer)
				this.resetAutoHideTimer();
				
			c.parentContainer._addNode(this.comp.view);
			c.delClass(this.compContextedCS);
			cfg.shadow.detachTarget();
		},
		
		/**
		 * 点击区域范围外时回调
		 */
		onCompReleaseContext : function(){
			var cfg = this.layoutCfg['CBorderLayout'];
			cfg.cbar.unFloat();
		},
		
		/**
		 * 侧边栏点击
		 */
		onBarClick : function(){
			var c = this.comp;
			if(c.contexted)
				c.releaseContext();
			//callback,cancel, caller, childId, cssTarget, cssName
			else {
				c.bindContext(this.onCompReleaseContext, true, null, null, this.navBlock, this.navBlockCS[this.dir]+'-on');
        this.makeFloat();
			}
		},
		
		/**
		 * 设置浮动面板浮动开始前位置与宽高
		 */
		setCompContextedBounds : function(){
			var c = this.comp, dir = this.dir;
			if(dir == 'west')
				c.setBounds(this.left+this.width+1, this.top, false, this.height);
			else if(dir == 'east')
				c.setBounds(this.left - c.width - 1, this.top, false, this.height);
			else if(dir == 'north')
				c.setBounds(this.left, this.top+this.height+1, this.width, false);
			else c.setBounds(this.left, this.top-c.height - 1, this.width, false);
		},
		
		setSize : function(){
			CContainerBase.prototype.setSize.apply(this, arguments);
			var v;
			if(this.dir == 'north' || this.dir == 'south'){
				v = Math.max(0, this.width - 6)+'px';
				this.centerExpander.style.width = v;
				if(CC.ie)
					this.centerExpander.parentNode.style.width = v;
			}
			else{
				v =  Math.max(0, this.height - 6)+'px';
				this.centerExpander.style.height = v;
				if(CC.ie)
					this.centerExpander.parentNode.style.height = v;				
			}
		}
		
  });
  
  return {
    /**
     * 水平方向分隔条高度,利用面板布置设置可覆盖该值.
     */
    hgap: 5,
    /**
     * 垂直方向分隔条高度,利用面板布置设置可覆盖该值.
     */
    vgap: 5,
    /**
     * 侧边栏宽度.
     */
		cgap : 32,
		/**
		 *
		 */
		cpgap : 5,
    
    wrCS : 'g-borderlayout-ct',
    itemCS :'g-borderlayout-item',
    
    addComponent: function(comp, dir) {
      superclass.addComponent.call(this, comp, dir);
      var d, s;
      if (dir === null || dir === undefined) d = 'center';
      if (typeof dir == 'object') {
        d = dir.dir;
        s = dir.split;
      }

      else d = dir;

      this[d] = comp;
      
      if (s && d != 'center') {
        var sp = dir.separator = new CBorderLayoutSpliter({
          dir: d,
          layout: this
        });
        if (d == 'west' || d == 'east') sp.addClass(this.separatorVCS || 'g-ly-split-v');
        else sp.addClass(this.separatorHCS || 'g-ly-split-h');
        sp.display(1).appendTo(this.ctNode);
        //
        comp.follow(sp);
      }
      
      comp.addClass(this.itemCS + '-' + (d||'center'));
      
      if(dir.collapsed)
      	this.collapse(comp, true);
      else this.doLayout();
    },
    
    getCollapseBar : function(c){
    	var cfg, cg, cbar;
      cfg = c.layoutCfg[this.type];
      cbar = cfg.cbar;
      if(!cbar && !cfg.noSidebar){
	      cbar = cfg.cbar = new CBorderLayoutCollapseBar({dir:cfg.dir, comp:c, itsLayout:this});
	      cbar.addClass(cbar.inherentCS+'-'+cfg.dir);
	      cbar.appendTo(this.ctNode);
	      this.container.follow(cbar);
      }
      return cbar;
    },
    
    collapse : function(comp, b){
    	var cbar = this.getCollapseBar(comp);
    	
    	var cfg = comp.layoutCfg[this.type];
    	cfg.collapsed = b;
    	if(cfg.separator)
    		cfg.separator.display(!b);
    	if(comp.fold)
    		comp.fold(b, true);
    	if(cbar)
    		cbar.display(b);
    	comp.display(!b);
    	this.doLayout();
    },
    
    onLayout: function() {
      var wr = this.wrapper;
      var w = wr.getWidth(true),
      h = wr.getHeight(true),
      l = 0,
      t = 0,
      c = this.north;

      var dd, n, sp, vg = this.vgap, cbg = this.cgap,cpg = this.cpgap,dcpg = cpg+cpg,
      hg = this.hgap,
      cfg, cg, cb;
      if (c) {
        cfg = c.layoutCfg[this.type];
        cb = cfg.cbar;
        
        if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	cb.setBounds(l+cpg,t+cpg,w-dcpg, cg - dcpg);
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	t += cg;
        }
        
        if(!c.hidden && !c.contexted){
        	dd = c.getHeight(true);
          c.setBounds(l, t, w, c.height);
          t += dd;
	        cg = cfg.gap === undefined ? vg: cfg.gap;
	        sp = cfg.separator;
	        if (sp) {
	          sp.setBounds(l, t, w, cg);
	        }
	        t += cg;
        }
        if(c.contexted)
        	c.releaseContext();
      }

      c = this.south;
      if (c) {
        cfg = c.layoutCfg[this.type];
        cb = cfg.cbar;
        if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	h -= cg;
          cb.setBounds(l+cpg,h+cpg,w-dcpg, cg - dcpg);
        }
        
        if(!c.hidden && !c.contexted){
        	dd = c.getHeight(true);
        	h -= dd;
        	c.setBounds(l, h, w, c.height);
        	cg = cfg.gap === undefined ? vg: cfg.gap;
        	sp = cfg.separator;
        	h -= cg;
        	if (sp) sp.setBounds(l, h, w, cg);
        }
        
        if(c.contexted)
        	c.releaseContext();
      }
      h -= t;

      c = this.east;
      if (c) {
        cfg = c.layoutCfg[this.type];
        cb = cfg.cbar;
        
        if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	w -= cg;
        	cb.setBounds(w+cpg, t, cg - dcpg, h);
        }else{
      		w -= cpg;
      	}
        
        if(!c.hidden && !c.contexted){
	        dd = c.getWidth(true);
	        w -= dd;
	        c.setBounds(w, t, c.width, h);
	        sp = cfg.separator;
	        cg = cfg.gap === undefined ? hg: cfg.gap;
	        w -= cg;
	        if (sp) sp.setBounds(w, t, cg, h);
        }
        if(c.contexted)
        	c.releaseContext();
      }

      c = this.west;
      if (c) {
      	cfg = c.layoutCfg[this.type];
      	cb = cfg.cbar;
      	if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
          cb.setBounds(l+cpg, t, cg - dcpg, h);
        	
        	l += cg;
        	w -= cg;
      	}else{
      		l += cpg;
      		w -= cpg;
      	}
      	
      	if(!c.hidden && !c.contexted){
	        dd = c.getWidth(true);
	        c.setBounds(l, t, c.width, h);
	        l += dd;
	        cg = cfg.gap === undefined ? hg: cfg.gap;
	        sp = cfg.separator;
	        w -= dd + cg;
	        if (sp) sp.setBounds(l, t, cg, h);
	        l += cg;
        }
        if(c.contexted)
        	c.releaseContext();
      }

      c = this.center;
      if (c) {
        c.setBounds(l, t, w, h);
      }
      
      CLayout.prototype.onLayout.call(this);
    },

    removeComponent: function(c) {
      var cfg = c.layoutCfg[this.type];
      this[cfg.dir] = null;
      var sp = cfg.separator;
      if (sp) {
      	sp.destoryComponent();
        cfg.separator = null;
      }
        
      var cb = cfg.cbar;
      if(cb){
        	cb.destoryComponent();
        	cfg.cbar = null;
      }
      return superclass.removeComponent.apply(this, arguments);
    },
    
    detach : function(){
    	var self = this;
    	this.invalidated = true;
    	CC.each(['east', 'sourth', 'west', 'north' , 'center'], function(){
    		if(self[this])
    			self.removeComponent(self[this]);
    	});
    	superclass.detach.call(this);
    }
  };
});

CLayout['border'] = CBorderLayout;


//rowlayout.js
CC.create('CCardLayout', CLayout, {
	layoutChild : function(item){
		var sz = this.container.wrapper.getSize(true);
		item.setSize(sz);
	}
});

CLayout['card'] = CCardLayout;

CC.create('CQQLayout', CLayout, function(superclass){
	return {
		addComponent : function(comp, cfg){
			comp.makePositioned('absolute').setLeft(0);
			if(cfg && cfg.collapsed === false){
				comp.fold(false, true);
				this.frontOne = comp;
			}else {
				comp.fold(true, true);
			}
			superclass.addComponent.apply(this, arguments);
		},
		
		onLayout : function(){
			superclass.onLayout.apply(this, arguments);
			var c = this.frontOne,
			    ct = this.container, 
			    ch = ct.wrapper.height, 
			    cw = ct.wrapper.width,
			    i, it, t,j,
			    its = ct.children, 
			    len = ct.size();
			//由上而下
			for(i=0, t = 0;i<len;i++){
				it = its[i];
				
				if(it.hidden)
					continue;
				
				if(it == c)
					break;
					
				it.setBounds(false, t, cw, it.minH);
				ch -= it.height;
				t += it.height;
			}
			
			if(c)
				c.setTop(t);
			//由下而上
			for(j=len-1, t = ct.wrapper.height;j>i;j--){
				it = its[j];
				t -= it.minH;
				it.setBounds(false, t, cw, it.minH);
				ch -= it.height;
			}
			
			if(c)
				c.setSize(cw, ch);
		},
		
		collapse : function(comp, b){
			var cfg = comp.layoutCfg[this.type];
			if(cfg.collapsed == b)
				return;
			
			if(this.frontOne && this.frontOne !== comp){
				if(this.frontOne.fold)
					this.frontOne.fold(true, true);
				this.frontOne.layoutCfg[this.type].collapsed = true;
			}
			if(comp.fold)
				comp.fold(b, true);
			cfg.collapsed = b;
			this.frontOne = b?null:comp;
      this.doLayout();
		}
	};
});

CLayout['qq'] = CQQLayout;

/**
 * 行布局,该布局将对子控件宽度/高度进行布局,不干预控件坐标.
 * 控件配置方面:
 * <li>auto : 自动宽高,不进行干预</li>
 * <li>具体宽/高 : 如50px</li>
 * <li>leading : 平分宽高</li>
 */
CC.create('CRowLayout', CLayout, function(superclass) {

  return {
    onLayout: function() {
      var wr = this.container.wrapper;
      var w = wr.getWidth(true),
      h = wr.getHeight(true),
      i,len, it, its = this.items, cfg, ty = this.type, iv;
      //y direction
      var leH = [], leW = [];
      for(i=0,len=its.length;i<len;i++){
      	it = its[i];
      	if(it.hidden)
      		continue;
      	
      	cfg = it.layoutCfg[ty];
      	switch(cfg.h){
      		case 'auto' :
      		case undefined : 
      			h-=it.getHeight(true);
      			break;
      		case 'lead' :
      			leH[leH.length] = it;
      			break;
      		default :
      		  iv = cfg.h;
      		  if(CC.isNumber(iv)){
      		  	if(iv>=1){
      		  		it.setHeight(iv);
      		  		//may be maxH reached.
      		  		h-=it.height
      		  	}else if(iv>=0){
      		  		iv = Math.floor(iv*h);
      		  		it.setHeight(iv);
      		  		//may be maxH reached.
      		  		h-=it.height;
      		  	}
      		  }
      	}
      	it.setWidth(w);
       }
       
       for(i=0,len=leH.length;i<len;i++){
      		it = leH[i];
      		cfg = it.layoutCfg[ty];
      		iv = cfg.len;
      		if(CC.isNumber(iv)){
      		  	iv = Math.floor(iv*h);
      		  	it.setHeight(iv);
      		  	h-=it.height
      		}else {
      			iv = Math.floor(h/(len-i));
      			it.setHeight(iv);
      			h-=it.height;
      		}
       }
       
      for(i=0,len=its.length;i<len;i++){
      	it = its[i];
      	if (!it.rendered) it.render();
      }
    },
    
    addComponent : function(c, cfg){
      this.items[this.items.length] = c;
      superclass.addComponent.call(this, c, cfg);
    },
    
    attach: function(c) {
      superclass.attach.call(this, c);
      this.items = [];
    }
  };
});

CRowLayout.prototype.layoutChild = CRowLayout.prototype.onLayout;

CLayout['row'] = CRowLayout;

CLayout['row2'] = CQQLayout;

//autoscrolllayout.js
/**
 * 该布局管理器可以在不影响原有面板的情况下使得子项被遮掩后出现导航条，当且当前选择项终始处于可视范围内。
 * 利用该布局管理器布局的控件有<code>CToolbar</code>,<code>CTab</code>.
 * 一个容器应该具备以下特性才能获得正确的布局：
 * html模板结构：参见CAutoScrollLayout模板
 * @since v2.0.4
 * @author Rock
 */

CTemplate['CAutoScrollLayout'] = '<div class="g-panel"><div class="auto-margin" id="_margin"><a href="javascript:fGo()" id="_rigmov" class="auto-rigmov" style="right:0px;"></a><a href="javascript:fGo()" style="left:0px;" id="_lefmov" class="auto-lefmov"></a><div class="auto-scrollor" id="_scrollor" tabindex="1" hidefocus="on"><div class="auto-offset" id="_wrap"></div></div></div></div>';

CC.create('CAutoScrollLayout', CLayout, function(superclass){
    /**
     * 导航按钮点击事件,当键按下时小于300ms就被看作一次点击处理，
     * 将触发移至下一项可见，否则当按下处理，不断移动可视范围直至松开键。
     */
    function onNavMousedown(){
        var ly = this.parentContainer.layout;
        var mov = this;
        ly.mousedownTimer = (function(){
        
            var hids;
            if (ly.lefMov == mov) {
                hids = ly.getHorizonOutOfViewItems('l');
                if (hids.length) 
                    ly.scrollTo(hids[0][1]);
            }
            else {
                hids = ly.getHorizonOutOfViewItems('r');
                if (hids.length) 
                    ly.scrollTo(hids[0][1]);
            }
            
            if (ly.mousedownTimer != null) {
                clearTimeout(ly.mousedownTimer);
                ly.mousedownTimer = null;
            }
        }).timeout(300);
    }
    
    /**
     * @see onNavMousedown
     */
    function onNavMouseup(){
        var ct = this.parentContainer, ly = ct.layout;
        if (ly.mousedownTimer != null) {
            clearTimeout(ly.mousedownTimer);
            ly.mousedownTimer = null;
            var first;
            if (ly.scrollTimer == null) {
                first = this.view.id == '_lefmov' ? ly.getHorizonOutOfViewItems('l') : ly.getHorizonOutOfViewItems('r');
                if (first.length == 0) 
                    return;
                first[first.length - 1][0].scrollIntoView(ct.scrollor, true);
            }
        }
        else {
            ly.resetScrollTimer();
        }
    }
    
    /**
     * 将子项滑动到容器可视范围内。
     * 该方法重写子项类位于<code>CBase</code>类中的scrollIntoView方法，
     * 使得以动画形式滑动至容器可视处.
     * 注意:子项类原有方法scrollIntoView将被覆盖！
     * @override
     * @param {Mixed} scrollor 子项将滚动到该元素的可视范围内
     */
    function itemScrollIntoView(scrollor){
        var ly = this.parentContainer.layout;
        var to = this.getHiddenAreaOffsetHori(scrollor);
        if (to === false) 
            return;
        ly.scrollTo(to);
    }
    
    return {
    	  /**
    	   * 延迟布局.
    	   */
    	   
    	  defferLayout : 0,
        /**
         * @cfg {Boolean} CLayout类设置，通知容器当子项remove, insert, display时重新布局.
         */
        layoutOnChange: true,
        
        /**
         * @cfg {Number} 子项移动的累加速度
         */
        acceleration: 0.5,
        
        /**
         * 该值须与 CSS 中的.auto-margin值保持同步,因为这里margin并不是由JS控制.
         * 出于性能考虑,现在把它固定下来。
         * @cfg horizonMargin {Number} 水平方向空位大小
         */
        horizonMargin: 5,
        
        /**
         * 该值须与左边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navLeftWidth: 24,
        
        /**
         * 该值须与右边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navRightWidth: 24,
        
        ctCS : 'g-autoscroll-ly',

        disabledLeftMoverCS: 'auto-lefmov-disabled',

    		disabledRightMoverCS: 'auto-rigmov-disabled',
    
        /**
         * 当子项添加到容器时改写子项的scrollIntoView方法并重新布局容器。
         * @override
         * @param {CBase} comp
         */
        addComponent: function(comp){
            superclass.addComponent.apply(this, arguments);
            //override & replace
            comp.scrollIntoView = itemScrollIntoView;
            this.doLayout();
        },
        
        /**
         * 布局容器方法的主体实现
         * @override
         * @param {Object} a 当前容器宽度或false 或 undefined
         * @param {Object} b 当前容器高度或false 或 undefined
         * @param {Object} c 当前容器的wrapper宽度或false 或 undefined
         * @param {Object} d 当前容器的wrapper高度或false 或 undefined
         * @param {Object} dx 当前容器resize后在x轴的引起的增量
         * @param {Object} dy 当前容器resize后在y轴的引起的增量
         */
        onLayout: function(a, b, c, d, dx, dy){
            superclass.onLayout.apply(this, arguments);
            var ct = this.container, scrollor = ct.scrollor, selected = ct.selected;
            //
            // IE怪胎下固定宽度
            //
            if (CC.ie) {
                var w = a || ct.getWidth() - (this.marginLeft||this.horizonMargin) - (this.marginRight||this.horizonMargin); //margin of wrap.
                ct.fly('_margin').setWidth(w).unfly();
                w -= this.navLeftWidth + this.navRightWidth; //margin of nav bar.
                CC.fly(scrollor).setWidth(w).unfly();
            }
            
            // 是否由resized引起的布局
            if (a === undefined) {
                if (selected) {
                    this.checkMover(false);
                    selected.scrollIntoView(scrollor);
                }
                else 
                    this.checkMover();
                return;
            }
            
            var it, offR = false;
            if (dx) {
                //如果向右扩充
                if (dx > 0) {
                    //如果右边有隐藏，尽量显示,否则显示左边
                    it = this.getNextHiddenChild()[1];
                    
                    if (it === false) 
                        scrollor.scrollLeft = scrollor.scrollLeft - dx;
                }
                //向左缩小,不改变scrollLeft
                if (selected) {
                    this.checkMover(false);
                    selected.scrollIntoView(scrollor, true);
                }
                else 
                    this.checkMover();
            }
        },
        
        /**
         * 绑定布局管理器到容器控件。
         * @param {CBase} ct 布局管理器对应的容器控件
         */
        attach: function(ct){
            superclass.attach.call(this, ct);
            ct.getWrapperInsets = fGo;
			// 重置margin结点值，忽略CSS设置的值，使得当CSS值不同的不引起布局的混乱。
			var mgst = ct.dom('_margin').style;
			mgst.marginLeft = (this.marginLeft||this.horizonMargin) + 'px';
			mgst.marginRight = (this.marginRight||this.horizonMargin) + 'px';
            
			if (!ct.scrollor) 
                ct.scrollor = ct.dom('_scrollor');
            var lm = this.lefMov = ct.$$('_lefmov');
            var rm = this.rigMov = ct.$$('_rigmov');
            lm.disabledCS = this.disabledLeftMoverCS;
            rm.disabledCS = this.disabledRightMoverCS;
            lm.domEvent('mousedown', onNavMousedown).domEvent('mouseup', onNavMouseup);
            rm.domEvent('mousedown', onNavMousedown).domEvent('mouseup', onNavMouseup);
            ct.hscroll = true;
        },
        
        /**
         * 移除移动子项到可视范围的定时器.
         */
        resetScrollTimer: function(){
            if (this.scrollTimer) {
                clearTimeout(this.scrollTimer);
                this.scrollTimer = null;
            }
            this.checkMover();
        },
        
        /**
         * 将滚动条滑动至指定处。
         * @param {Number} to scrollor结点的scrollLeft值.
         */
        scrollTo: function(to){
            if (this.scrollTimer != null) 
                this.resetScrollTimer();
            var sc = this.container.scrollor;
            var current = sc.scrollLeft;
            var step = to - current;
            var seed = step / Math.abs(step) * this.acceleration;
            if (seed == 0) 
                return;
            var self = this;
            step = seed;
            this.scrollTimer = (function(){
                current = Math.floor(current + step);
                if (seed > 0) {
                    if (current > to) 
                        current = to;
                }
                else 
                    if (current < to) {
                        current = to;
                    }
                
                if (current == to) {
                    self.resetScrollTimer();
                }
                sc.scrollLeft = current;
                step += seed;
            }).timeout(this.scrollTimerInterval || 33, true);
        },
        
        /**
         * 检查导航按钮状态，是否应显示或禁用。
         */
        checkMover: function(timeout){
            var self = this;
            var func = (function(){
                var ct = self.container, has = self.getNextHiddenChild();
                self.lefMov.disable(!has[0]);
                self.rigMov.disable(!has[1]);
                
                if (!has[0] && !has[1]) {
                    ct.delClass(ct.movPanelCS);
                }
                
                else 
                    ct.addClassIf(ct.movPanelCS);
            });
            if (timeout !== false) 
                func.timeout(100);
            else 
                func();
        },
		
        /**
         * 返回左右两边下一个被遮掩的子项。
         * 注:不包括隐藏的
         */
        getNextHiddenChild: function(){
            var its = this.container.children, it, l = false, r = false, i = 0, j, len = its.length, sc = this.container.scrollor;
            for (; i < len; i++) {
                it = its[i];
                if (it.hidden) 
                    continue;
                if (it.getHiddenAreaOffsetHori(sc) !== false) {
                    l = it;
                }
                i++;
                break;
            }
            
            for (j = len - 1; j >= i; j--) {
                it = its[j];
                if (it.hidden) 
                    continue;
                if (it.getHiddenAreaOffsetHori(sc) !== false) {
                    r = it;
                }
                break;
            }
            return [l, r];
        },
        
        /**
         * 获得水平方向被遮掩的项列表。
         * 注:不包括隐藏的。
         * @param {Object} dir 左边或右边或两边都返回。'l'或'r'或者undefined.
         */
        getHorizonOutOfViewItems: function(dir){
            var ct = this.container, scrollor = ct.scrollor;
            var ls = [], rs = [], its = ct.children, len = its.length, it, i = 0, j, off;
            //left out of view items
            if (!dir || dir == 'l') {
                for (; i < len; i++) {
                    it = its[i];
                    if (it.hidden) 
                        continue;
                    off = it.getHiddenAreaOffsetHori(scrollor);
                    if (off === false) {
                        i++;
                        break;
                    }
                    ls[ls.length] = [it, off];
                }
            }
            
            //right out of view items
            if (!dir || dir == 'r') {
                for (j = len - 1; j >= i; j--) {
                    it = its[j];
                    if (it.hidden) 
                        continue;
                    off = it.getHiddenAreaOffsetHori(scrollor);
                    if (off === false) 
                        break;
                    rs[rs.length] = [it, off];
                }
            }
            
            if (!dir) 
                return [ls, rs];
            
            return dir == 'l' ? ls : rs;
        }
        
    };
});

CLayout['autoscroll'] = CAutoScrollLayout;




//itemddrtag.js
/**
 * 拖放CTabItem,CColumn项时显示的下标图标.
 * 该控件位于缓存中,一般可放下时显示,拖放结束后消失.
 */
CTemplate['CItemDDRBarUp'] = '<div class="g-tabMoveSp" style="display:none;"></div>';

if(!Cache['CItemDDRBarUp']) {
		Cache.register('CItemDDRBarUp', (function(){
			var n = CC.$$(CTemplate.forNode(CTemplate['CItemDDRBarUp']));
			n.appendTo(document.body);
			return n;
		}));
}

//group.js
CTemplate['CFolderItem'] = '<li class="g-unsel"><b id="_ico" class="icos"></b><a id="_tle" class="g-tle"></a></li>';
CTemplate['CFolder'] = '<div class="g-folder g-grp-bdy"><div class="g-grp-bdy" id="_scrollor"><ul id="_bdy" tabindex="1" hidefocus="on"></ul></div></div>';

CUtil.createFolder = function(opt, type){
	opt = CC.extendIf(opt, {
        itemOptions : {template : 'CFolderItem', hoverCS:'on'},
        navKeyEvent : true,
        container : '_bdy',
				useContainerMonitor : true,
				template:'CFolder'
  });
	return new CSelectedContainer(opt);
};


//form.js
//
CC.create('CFormElement', CBase, function(superclass) {
  return {
    errorCS: 'g-error',

    elementNode: '_el',

    elementCS: 'g-form-el',

    initComponent: function() {
      //generate template first and searching form element node..
      var v = this.view;
      if (!v) {
        var t = this.template || this.type;
        this.view = v = CTemplate.$(t);
      }
      var el = this.element;

      if (!el) el = this.element = this.dom(this.elementNode);

      el.id = this.id || 'comp' + CC.uniqueID();
      this.focusNode = el.id;

      if (v != el && !v.id) v.id = 'comp' + CC.uniqueID();
      //
      this.addClass(this.elementCS);

      superclass.initComponent.call(this);

      if (this.name) this.setName(this.name);

      if (this.value) this.setValue(this.value);

      if (this.focusCS) this.bindFocusStyle(this.focusCS);
    },

    setValue: function(v) {
      this.element.value = v;
      this.value = v;
      return this;
    },
    
    getValue : function(){
    	return this.element.value;
    },

    setName: function(n) {
      this.element.name = n;
      this.name = n;
      return this;
    },

    focusCallback: function(evt) {
      if (this.onFocus) this.onFocus(evt, this.element);
    },

    mouseupCallback: function(evt) {
      if (this.onClick) this.onClick(evt, this.element);
    },

    blurCallback: function(evt) {
      if (this.onBlur) this.onBlur(evt, this.element);
    }
  };
});

CTemplate['CText'] = '<input type="text" id="_el" class="g-ipt-text" />';
CC.create('CText', CFormElement, function(superclass) {
  return {
    focusCS: 'g-ipt-text-hover',
    focusCallback: function(evt) {
      superclass.focusCallback.call(this, evt);
      //fix chrome browser.
      var self = this;
      //IE6下 this.view.select.bind(this.view).timeout(20);
      // 也会出错,它的select没能bind..晕
      (function() {
        self.view.select();
      }).timeout(20);
    }
  };
});
CFormElement['text'] = CText;

CTemplate['CTextarea'] = '<textarea id="_el" class="g-textarea" />';
CC.create('CTextarea', CFormElement, CText.constructors, {
  focusCallback: CFormElement.prototype.focusCallback
});
CFormElement['textarea'] = CTextarea;

CTemplate['CCheckbox'] = '<span tabindex="1" class="g-checkbox"><input type="hidden" id="_el" /><img src="' + CTemplate.BLANK_IMG + '" class="chkbk" /><label id="_tle"></label></span>';
CC.create('CCheckbox', CFormElement, function(superclass) {
  return {
    hoverCS: 'g-check-over',
    clickCS: 'g-check-click',
    checkedCS: 'g-check-checked',
    initComponent: function() {
      superclass.initComponent.call(this);
      if (this.checked) this.setChecked(true);
    },

    mouseupCallback: function(evt) {
      this.setChecked(!this.checked);
      superclass.mouseupCallback.call(this, evt);
    },

    setChecked: function(b) {
      this.checked = b;
      this.element.checked = b;
      if (b) this.addClass(this.checkedCS);
      else this.delClass(this.checkedCS);
      if (this.onChecked) this.onChecked(b);
    }
  };
});
CFormElement['checkbox'] = CCheckbox;

CC.create('CRadio', CFormElement, CCheckbox.constructors, {
  inherentCS: 'g-radio',
  template: 'CCheckbox',
  hoverCS: 'g-radio-over',
  clickCS: 'g-radio-click',
  checkedCS: 'g-radio-checked'
});
CFormElement['radio'] = CRadio;

CTemplate['CFieldLine'] = '<li><label class="desc" id="_tle" ><span class="req">*</span></label><div id="_elCtx"></div></li>';
CC.create('CFieldLine', CContainerBase, function(superclass) {
  return {
    labelNode: '_tle',
    labelFor: 0,
    template: 'CFieldLine',
    container: '_elCtx',
    title: false,
    initComponent: function() {
      superclass.initComponent.call(this);
      if (this.title === false) {
        this.fly(this.labelNode).display(0).unfly();
      }
    },

    add: function(field, cfg) {
      if (field.ctype) field = new CFormElement[field.ctype](field);
      superclass.add.call(this, field, cfg);
      if (this.$(this.labelFor) == field) this.dom(this.labelNode).htmlFor = field.element.id;

    },

    fromArray: function(array) {
      for (var i = 0, len = array.length; i < len; i++) {
        this.add(array[i]);
      }
    }
  };
});

CFormElement['fieldline'] = CFieldLine;

CTemplate['CFormLayer'] = '<ul class="g-formfields"></ul>';
function CFormLayer(opt) {
  opt = opt || {};
  opt.ItemClass = CFieldLine;
  opt.template = opt.type = 'CFormLayer';
  return new CContainerBase(opt);
}

//progressbar.js
CTemplate['CProgressbar'] = '<table class="g-progressbar" cellspacing="0" cellpadding="0" border="0"><tr><td class="g-progress-l"><i>&nbsp;</i><input type="hidden" id="_el" /></td><td class="g-progress-c"><img id="_img" src="http://www.bgscript.com/s.gif" alt=""/></td><td class="g-progress-r"><i>&nbsp;</i></td></tr></table>';
CC.create('CProgressbar', CFormElement, function(father){
	if(!CProgressbar.img)
		CProgressbar.img = 'http://www.bgscript.com/images/progressbar.gif';
	return {
		range : 100,
		value : 0,
		template :'CProgressbar',
		initComponent : function(){
			this.createView();
			if(CProgressbar.img){
				this.img = this.dom('_img');
				this.img.src = CProgressbar.img;
		  }
			//else 
			father.initComponent.call(this);
		},
		
		setValue : function(v){
			if(v>=100){
				CC.fly(this.img).setStyle('width','100%').unfly();
				this.onStop();
				this.fire('progressstop', this);
				return father.setValue.call(this, 100);
			}
			
			CC.fly(this.img).setStyle('width',v+'%').unfly();
			return father.setValue.call(this, v);
		},

		onStop : fGo
	};
});
CFormElement['progressbar'] = CProgressbar;
//button.js
CTemplate['CButton'] = '<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="g-btn-l"><i>&nbsp;</i></td><td class="g-btn-c"><em unselectable="on"><button type="button" class="g-btn-text" id="_tle"></button></em></td><td class="g-btn-r"><i>&nbsp;</i></td></tr></tbody></table>';
CTemplate['CVerticalButton'] = '<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="g-btn-l"><i>&nbsp;</i></td></tr><tr><td class="g-btn-c"><em unselectable="on"><button type="button" class="g-btn-text" id="_tle"></button></em></td></tr><tr><td class="g-btn-r"><i>&nbsp;</i></td></tr></tbody></table>';
/**
 *@class CButton
 *@extend CBase
 */
CC.create('CButton', CBase, function(superclass){
    return {
        iconNode: '_tle',
        focusNode: '_tle',
        hoverCS: 'g-btn-over',
        clickCS: 'g-btn-click',
        iconCS: 'g-btn-icon',
        template: 'CButton',
        focusCS: 'g-btn-focus',
        tip : false,
        disableNode: '_tle',
        inherentCS: 'g-btn',
        blockMode: '',
        _onClick: function(){
            if (this.onClick) 
                this.onClick.call(this);
        },
        
        initComponent: function(){
            superclass.initComponent.call(this);
            if (!this.title || this.title == '') 
                this.addClass(this.noTxtCS || 'g-btn-notxt');
            this.element = this.dom('_tle');
            this.domEvent('mousedown', this._gotFocus);
            this.domEvent('click', this._onClick);
            if (this.focusCS) 
                this.bindFocusStyle(this.focusCS);
            if (this.dockable && this.docked) {
                this.setDocked(true);
            }
        },
        
        setDocked: function(b){
            this.docked = b;
            b ? this.addClass(this.clickCS) : this.delClass(this.clickCS);
            return this;
        },
        
        _gotFocus: function(ev){
            try {
                this.element.focus();
            } 
            catch (e) {
            }
        },
        
        mouseupCallback: function(){
            if (this.dockable) {
                this.docked = !this.docked;
                return this.docked;
            }
        }
    };
});

CC.create('CVerticalButton', CBase, CButton.constructors, {
  inherentCS: 'g-vbtn',
  hoverCS: 'g-vbtn-over',
  clickCS: 'g-vbtn-click',
  noTxtCS : 'g-vbtn-notxt',
  iconCS: 'g-vbtn-icon',
  template: 'CVerticalButton',
  focusCS: 'g-vbtn-focus',
  qtip : true,
  tip : true,
  brush : function(v){
  	if(!v || CC.ie)
  		return v;
  	v = v.toString().truncate(3,'..');
  	var ss = [];
  	for(var i=0,len=v.length-1;i<len;i++){
  		ss.push(v.charAt(i)+'<br>');
  	}
  	return ss.join('');
  }
});

CFormElement['button'] = CButton;
CFormElement['vbutton'] = CVerticalButton;
CBase['vbutton'] = CVerticalButton;

//toolbar.js
CTemplate['CBarItem'] = '<table class="g-baritem" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="g-btn-l"><i>&nbsp;</i></td><td class="g-btn-c"><em unselectable="on"><button type="button" class="g-btn-text" id="_tle"></button></em></td><td class="g-btn-r"><i>&nbsp;</i></td></tr></tbody></table>';
CPanel.createBigBar = (function(opt){
	return new CSelectedPanel(CC.extend(
	{
	 itemCallback:true,
	 forceSelect:true,
	 navKeyEvent:false,
	 itemOptions : {
	 	template : 'CBarItem', 
	 	maxH:31,
	 	hoverCS:'g-baritem-over',
	 	inherentCS : 'g-baritem',
		clickCS:'g-baritem-click',
		focusCS:false
	 },
	 maxH : 38,
	 inherentCS : 'g-bigbar',
	 movPanelCS: 'g-mov-toolbar',
	 ItemClass : CButton,
	 template : 'CAutoScrollLayout',
	  /**
	   * 主要用于autoscrolllayout布局
	   */
	  layoutCfg : {
	      horizonMargin: 5,
        
        /**
         * 该值须与左边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navLeftWidth: 20,
        
        /**
         * 该值须与右边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navRightWidth: 20
	  }
	}, 
	opt));
});

CPanel.createSmallBar = (function(opt){
	return new CSelectedPanel(CC.extend(
	{
	 itemCallback:true,
	 forceSelect:true,
	 navKeyEvent:false,
	 itemOptions : {
	 	template : 'CBarItem', 
	 	hoverCS:'g-smallbar-item-over',
		clickCS:'g-smallbar-item-click',
		inherentCS:'g-smallbar-item',
		focusCS:false
	 },
	 maxH : 26,
	 inherentCS:'g-smallbar',
	 movPanelCS: 'g-mov-toolbar',
	 ItemClass : CButton,
	 template : 'CAutoScrollLayout',
	 
	  /**
	   * 主要用于autoscrolllayout布局
	   */
	  layoutCfg : {
	      horizonMargin: 5,
        
        /**
         * 该值须与左边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navLeftWidth: 20,
        
        /**
         * 该值须与右边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navRightWidth: 20
	  }
	}, 
	opt));
});
//titlepanel.js
CTemplate['CTitlePanel'] = '<div class="g-panel g-titlepanel"><h3 class="g-titlepanel-hd" id="_tleBar"><a id="_btnFN" class="g-icoFld" href="javascript:fGo()"></a><a id="_tle" class="g-tle" href="javascript:fGo()"></a></h3><div id="_scrollor" class="g-panel-wrap g-titlepanel-wrap"></div></div>';

CC.create('CTitlePanel', CPanel, function(superclass){
    return {
  
        unselectable : '_tleBar',
        
        template : 'CTitlePanel',
        
        container:'_scrollor',
        
        minH : 29,
        
        initComponent: function() {
            superclass.initComponent.call(this);
            //evName, handler, cancel, caller, childId
            this.domEvent(this.toggleEvent || 'mousedown', this._btnFNOnclick, true, null, this.foldNode || '_btnFN');
            //_tleBar
            this.header = this.$$('_tleBar');
            
            if(this.folded)
            	this.fold(this.folded);
        },
				
				getWrapperInsets : function(){
				 	return [29 , 0, 0, 0, 29, 0];
				},
				
        //点击收缩图标时触发,可重写自定.
        _btnFNOnclick: function() {
	          var v = !this.wrapper.hidden;
	          this.fold(v);
        }
        ,
        //b:true or false.
        fold: function(b, notNotifyLayout) {
        	  if(this.parentContainer && this.parentContainer.layout.collapse && !notNotifyLayout){
            	this.parentContainer.layout.collapse(this, b);
            	return this;
            }
            this.inspectDomAttr('_btnFN', 'className', b ? this.openCS || 'g-icoOpn' : this.clsCS || 'g-icoFld');
            this.wrapper.display(!b);
            this.folded = b;
            this.fire('fold',b);
            return this;
        }
    }
});
//foldable.js
CTemplate['CFoldable'] = '<div class="g-foldable"><div class="g-foldablewrap"><b title="隐藏" id="_trigger" class="icos icoCls"></b><div id="_tle"></div></div></div>';
CC.create('CFoldable', CBase, {
    template: 'CFoldable',
    autoRender: false,
    clsGroupCS: 'g-gridview-clsview',
    unselectable: true,
	/**
	 * @cfg nodeBlockMode 指定收缩结点的displayMode:''或block
	 */
	//nodeBlockMode:'block',
    initComponent: function(){
        this.createView();
        CBase.prototype.initComponent.call(this);
        this.domEvent('click', this.foldView, true, null, '_trigger').domEvent('dblclick', this.foldView, true);
        if (this.array) {
            this.target.fromArray(this.array);
            delete this.array;
        }
    },
    
    foldView: function(b){
        var f = CC.fly(this.foldNode ? this.target.dom(this.foldNode) : this.target.container || this.target);
        //
        // b如果用在domEvent的回调中,就是Event对象!
        //
        if (b !== true && b !== false) 
            b = !f.display();
        if (this.fire('expand', this, b) === false) {
            f.unfly();
            return;
        }
		//
		if(this.nodeBlockMode !== undefined)
			f.setBlockMode(this.nodeBlockMode);
        f.display(b).unfly();
        if (this.target.shadow) 
            this.target.shadow.reanchor();
        this.dom('_trigger').title = b ? '隐藏' : '展开';
        b ? this.delClass(this.clsGroupCS) : this.addClass(this.clsGroupCS);
        this.expanded = b;
        this.fire('expanded', this, b);
        return this;
    },
    
    brush: function(v){
        if (this.target.children) 
            return '<strong>' + v + '</strong><span id="_view_span">(<strong><a id="_view_cnt" href="javascript:fGo();">' + this.target.size() + '</a></strong>)</span>';
        return v;
    }
});


//framepanel.js
CTemplate['CIFramePanel'] = '<iframe class="g-framepanel" frameBorder="no" scrolling="auto" hideFocus=""></iframe>';
CC.create('CIFramePanel', CPanel, {
	
	template : 'CIFramePanel',
	
	container : undefined,
	
	traceResize : false,
	
	traceLoad : true,
	
	onRender : function(){
		CPanel.prototype.onRender.call(this);
		var c = this.parentContainer;
		
		if(this.traceResize){
			c.on('resized', this.onContainerResize, this);
			this.onContainerResize(false, false, c.wrapper.getWidth(true), c.wrapper.getHeight(true));
	  }
	  
		if(this.traceLoad){
			this.domEvent(CC.isIE?'readystatechange':'load', this.traceFrameLoad,null, null, this.wrapper.view);
		}
		
		//加载页面
		if(this.autoConnect && (this.src || this.url)){
			this.connect();
		}
	},
	//
	// 实例化时可重写该方法,以自定义IFRAME宽高.
	//
	onContainerResize : function(a,b,c,d){
		this.setSize(a, b);
	},
	
  //
  //@override IFRAME与AJAX加载方式不同
  //
  connect: function(url, cfg) {
    if(!url)
      url = this.url || this.src;
    else this.url = url;
    	
    this.loaderConfig = cfg;
    
    if (!this.indicatorDisabled && !this.loadIndicator) {
      this.getLoadIndicator();
    }

		try{
			this.fire('open');
			var v = this.wrapper.view;
			(function(){v.src = url;}).timeout(0);
		}catch(e){
			console.warn(e);
		}
		
    return this;
  },
  
  onFrameLoad : function(evt){
  	try{
  		this.fire('success', evt);
  		if(this.loaderConfig && this.loaderConfig.onsuccess){
  			this.loaderConfig.onsuccess.call(this, evt);
  		}
    }catch(e){console.warn(e);}
  	this.fire('final');
  	if(this.loaderConfig && this.loaderConfig.onfinal){
  		this.loaderConfig.onfinal.call(this, evt);
  	}
  },
  
	traceFrameLoad : function(evt){
		var status = Event.element(evt).readyState || evt.type;
	  switch(status){
	  	case 'loading':  //IE  has several readystate transitions
	    	if(!this.busy)
	    		this.fire('open', evt);
		  break;
		  //
		  //当用户手动刷新FRAME时该事件也会发送
	    //case 'interactive': //IE
	    case 'load': //Gecko, Opera
	    case 'complete': //IE
			  //May be ie would do a clean action before a new page loaded.
			  if((CC.ie && (this.src||this.url) != this.view.src))
			  	return;
			  this.onFrameLoad(evt);
	    break;
	  }
	},
	
	getLoadIndicator : function(opt){
		opt = CC.extendIf(opt, {markIndicator:fGo, stopIndicator:fGo});
		CPanel.prototype.getLoadIndicator.call(this , opt);
	},
	
	/**
	 * 根据结点id返回IFrame页面内元素dom结点.
	 * 注:必须在IFrame加载完成后才可正常访问.
	 * @function
	 * @return {DOMElement}
	 */
	$ : function(id){
		return CC.frameDoc(this.view).getElementById(id);
	}
}
);

//resizer.js
//定义控件模板
CTemplate['CResizer'] = '<div class="g-panel g-resizer"><div class="g-win-e" id="_xe"></div><div class="g-win-s" id="_xs"></div><div class="g-win-w" id="_xw"></div><div class="g-win-n" id="_xn"></div><div class="g-win-sw" id="_xsw"></div><div class="g-win-es" id="_xes"></div><div class="g-win-wn" id="_xwn"></div><div class="g-win-ne" id="_xne"></div><div class="g-panel-wrap g-resizer-wrap" id="_wrap"></div></div>';
/**
 * Resize开始时位置长宽信息保存在控件的initPS属性.
 */
CC.create('CResizer', CPanel ,(function(superclass){
    return {
        resizeable : true,
        enableH:true,
        enableW:true,
        template : 'CResizer',
        unresizeCS : 'g-win-unresize',
        width:500,
        height:250,
        minW:12,
        minH:6,
        initComponent : function() {
            superclass.initComponent.call(this);
            if(this.resizeable){
                var v = this.view;
                var self = this;
                var G = CGhost.instance;
                //onmousedown and start
                var ini = (function(){
                		if(!self.resizeable)
                			return false;
                    var a = self.absoluteXY();
                    var b = self.getSize();
                    if(!CC.borderBox){
                    	b.width -= 1;
                    	b.height -= 1;
                    }
                    self.initPS = {
                        pos:a,
                        size:b
                    };
                    //current 'this' is the element which gets the event.
                    //notice the ghost proxy.
                    G.startResize();
                    G.resizeLayer.setXY(a).setSize(b);
                    G.resizeMask.style('cursor', this.style('cursor'));
                    self.fire('resizestart');
                });
					
                var end = (function(){
                	  var dx = G.MDX,dy = G.MDY;
                    
                    if(dx == 0 && dy == 0){
                    	G.endResize();
                    	G.resizeMask.style('cursor','');
                    	return;
                    }
                    
                    if(self.fire('resize', self)=== false)
                        return false;
                    var sz = G.resizeLayer.getSize(true);
                    //hack:
                    if(!CC.borderBox){
                    	if(sz.width != 0)
                    		sz.width += 1;
                    	if(sz.height != 0)
                    		sz.height += 1;
                    }
                    self.setSize(sz);
                    
                    var dlt = G.resizeLayer.xy(),
                        initlt = self.initPS.pos,
                        initxy = self.initPS.size,
                        dxy = [sz.width - initxy.width, sz.height - initxy.height];
                    dlt[0] -= initlt[0];
                    dlt[1] -= initlt[1];
                    self.setXY(self.getLeft(true)+dlt[0], self.getTop(true)+dlt[1]);
                    self.fire('resizeend', dlt, dxy);
                    G.endResize();
                    G.resizeMask.style('cursor', '');
                    delete self.initPS;
                });
					
                var a = this._createFn(0x8);
                var b = this._createFn(0x4);
                var c = this._createFn(0x2);
                var d = this._createFn(0x1);
                var f = this._createFn('',c,b);
                var e = this._createFn('',b,d);
                var g = this._createFn('',a,c);
                var h = this._createFn('',a,d);
                var G = CGhost.instance;
                this._bindTriggerAction('_xn',a,ini,end);
                this._bindTriggerAction('_xs',b,ini,end);
                this._bindTriggerAction('_xw',c,ini,end);
                this._bindTriggerAction('_xe',d,ini,end);
                this._bindTriggerAction('_xes',e,ini,end);
                this._bindTriggerAction('_xsw',f,ini,end);
                this._bindTriggerAction('_xwn',g,ini,end);
                this._bindTriggerAction('_xne',h,ini,end);
            }else {
                this.setResizable(false);
            }
        },
				//
				// 在窗口创建后调用
				//
				setResizable : function(resizeable) {
					if(!resizeable)
						this.addClass(this.unresizeCS);
					else 
						this.delClass(this.unresizeCS);
					this.resizeable = resizeable;
				},
				
				getWrapperInsets : function(){
					return [6,1,1,1,7,2];
				},
				
        _bindTriggerAction : function(id, drag, ini, end) {
            var vid = this.$$(id);
            vid.beforeDragStart = ini;
            vid.drag = drag;
            vid.afterDrop = end;
            vid.bindDragDrop(null, true);
            vid.parentContainer = this;
        },
		
        _createFn : function(axis,a,b) {
            var self = this;
            var G = CGhost.instance;
            if(axis == 0x4 || axis == 0x8){
                return function(ev) {
                    if(!self.enableH) {
                        return;
                    }
                    var pace = G.PXY[1] - G.IPXY[1];
                    self._zoom(axis, pace);
                }
            }
            else if(axis == 0x1 || axis == 0x2) {
                return function(ev) {
                    if(!self.enableW) {
                        return;
                    }
                    var pace = G.PXY[0] - G.IPXY[0];
                    self._zoom(axis, pace);
                }
            }else {
                return function(ev) {
                    a.call(this,ev);
                    b.call(this,ev);
                };
            }
        },
		
        _zoom : function(axis, pace) {
            var G = CGhost.instance, off;
            var ly = G.resizeLayer;
            if((axis & 0x1) != 0x0) {
                off =  this.initPS.size.width+ pace;
                if(off>=this.minW)
                    ly.setWidth(off);
            }
			
            else if((axis & 0x2) != 0x0) {
                off = this.initPS.size.width - pace;
                if(off<this.minW)
                    return;
                ly.setWidth(off);
                off = this.initPS.pos[0] + pace;
                ly.setLeft(off);
            }
			
            if((axis & 0x4) != 0x0) {
                off = this.initPS.size.height + pace;
                if(off>=this.minH)
                    ly.setHeight(off);
            }
			
            else if((axis & 0x8) != 0x0) {
                off = this.initPS.size.height - pace;
                if(off<this.minH)
                    return;
                ly.setHeight(off);
                off = this.initPS.pos[1] + pace;
                ly.setTop(off);
            }
        }
    };
}));
//xresizer.js
//定义控件模板
CTemplate['CXResizer'] = '<div class="g-panel g-xresizer"><div class="g-res-e" id="_xme"></div><div class="g-res-s" id="_xms"></div><div class="g-res-w" id="_xmw"></div><div class="g-res-n" id="_xmn"></div><div class="g-res-sw" id="_xsw"></div><div class="g-res-es" id="_xes"></div><div class="g-res-wn" id="_xwn"></div><div class="g-res-ne" id="_xne"></div><div class="g-res-wc" id="_xw"></div><div class="g-res-ec" id="_xe"></div><div class="g-res-nc" id="_xn"></div><div class="g-res-sc" id="_xs"></div></div>';
/**
 *
 */
CC.create('CXResizer', CResizer ,(function(superclass){
    return {
    	
    	template :'CXResizer',
    	
    	//当宽/高超过该数值时,隐藏中间滑片
    	minHideSliperWidth:40,
    	
    	initComponent:function(){
    		superclass.initComponent.call(this);
    		this.on('resized',this.onResized);
    		this._bindMoveAction();
    	},
    	
    	//容器位置不受父类影响
    	getWrapperInsets:CPanel.prototype.getWrapperInsets,
    	
    	//这里绑定四条边框,使得可移动
    	_bindMoveAction : function(){
    		//id, drag, ini, end
    		this._bindTriggerAction(this.view, this.movSpliterDrag, this.movSpliterDragStart, this.movSpliterDropSB);
    		//this._bindTriggerAction('_xme', this.movSpliterDrag, this.movSpliterDragStart, this.movSpliterDropSB);
    		//this._bindTriggerAction('_xms', this.movSpliterDrag, this.movSpliterDragStart, this.movSpliterDropSB);
    		//this._bindTriggerAction('_xmn', this.movSpliterDrag, this.movSpliterDragStart, this.movSpliterDropSB);
    		//this._bindTriggerAction('_xmw', this.movSpliterDrag, this.movSpliterDragStart, this.movSpliterDropSB);
    	},
    	
    	onResized : function(a, b){
    		//如果宽度超过一定,隐藏中间滑片
    		if(a !== false){
    			if(a<this.minHideSliperWidth){
    				this.fly('_xn').display(false).unfly();
    				this.fly('_xs').display(false).unfly();
    			}else{
    				this.fly('_xn').display(true).unfly();
    				this.fly('_xs').display(true).unfly();
    			}
    		}
    		if(b !== false){
    			if(b<this.minHideSliperWidth){
    				this.fly('_xe').display(false).unfly();
    				this.fly('_xw').display(false).unfly();
    			}else{
    				this.fly('_xe').display(true).unfly();
    				this.fly('_xw').display(true).unfly();
    			}
    		}
    	},
    	
		  movSpliterDragStart: function() {
		        var c = this.parentContainer;
		        if(c.unmoveable)
		        	return false;
		        CGhost.instance.enableTip = false;
		        if (c.fire('movestart') === false) return false;
		        if (c.shadow) c.shadow.hide();
		        c.setOpacity(0.6);
		        c.initPos = c.xy();
		    },
		   
		  movSpliterDrag: function() {
		        var G = CGhost.instance,
		        c = this.parentContainer;
		        CBase.prototype.setXY.call(c, c.initPos[0] + G.MDX, c.initPos[1] + G.MDY);
		  },
		  
		  movSpliterDropSB: function() {
		        var c = this.parentContainer,
		            G = CGhost.instance, 
		            dx = G.MDX, 
		            dy = G.MDY;
                    
            if(dx == 0 && dy == 0)
	            return;
		        
		        if (c.fire('moveend') === false) {
		            c.setXY(c.initPos);
		            return false;
		        }
		        //update x,y
		        c.fire('reposed', c.left, c.top, G.MDX, G.MDY);
		        
		        c.setOpacity(1);
		        if (c.shadow) c.shadow.show();
		        delete c.initPos;
		  }
    };
}));
//window.js
/**
 * window控件.
 */

CC.create('CWin', CResizer, (function(){
	
    CTemplate['CWinTitlebar'] = '<div id="_g-win-hd" class="g-win-hd ellipsis"><div class="fLe"></div><b class="icoSw" id="_ico"></b><span id="_tle" class="g-tle">提示</span><div class="fRi"></div><div class="g-win-hd-ct" style="position:absolute;right:5px;top:7px;" id="_ctx"></div></div>';
	  CTemplate['CWinBarItem'] = '<a class="g-hd-btn" href="javascript:fGo();"></a>';
    var globalZ = 900;
    
		var CWinTitlebar = CC.create(CSelectedContainer, {
		    type: 'CWinTitlebar',
		    template: 'CWinTitlebar',
		    autoRender: true,
		    forceSelect: true,
		    unselectable:true,
		    selectedCS: false,
		    itemClickEvent:'click',
		    itemOptions: {
		        template: 'CWinBarItem'
		    },
		    itemCallback: true,
		    cancelSelectBubble: true,
		    container: '_ctx',
		    draggable: true,
		    dragStart: function() {
		        var c = this.parentContainer;
		        if(c.unmoveable)
		        	return false;
		        CGhost.instance.enableTip = false;
		        
		        if (c.fire('movestart') === false) return false;
		        if (c.shadow) c.shadow.hide();
		        CGhost.instance.coverDragMask(true);
		        c.setOpacity(0.6);
		        c.initPos = c.xy();
		    },
		    drag: function() {
		        var G = CGhost.instance,
		        c = this.parentContainer;
		        CBase.prototype.setXY.call(c, c.initPos[0] + G.MDX, c.initPos[1] + G.MDY);
		    },
		    dropSB: function() {
		        var c = this.parentContainer;
		        CGhost.instance.coverDragMask(false);
		        if (c.fire('moveend') === false) {
		            c.setXY(c.initPos);
		            return false;
		        }
		        //update x,y
		        var G = CGhost.instance;
		        c.left = c.top = false;
		        c.setXY(c.initPos[0] + G.MDX, c.initPos[1] + G.MDY);
		        c.setOpacity(1);
		        if (c.shadow) c.shadow.show();
		        delete c.initPos;
		    }
		});
		
		
    return {

        closeable : true,
        
        shadow : true,
  
        inherentCS : 'g-win g-tbar-win',
        
        minCS : 'g-win-min',
        
        maxCS : 'g-win-max',
        
        minH:30,
        
  			minW:80,
  			
        //blanks : [0,1,1,1,30,2],
  
        titlebar : true,
  
        initComponent: function() {
            this.titlebar = new CWinTitlebar({parentContainer:this, title:this.title});
						delete this.title;
						if(this.shadow === true)
							this.shadow = new CShadow({inpactH:5,inpactY:-1});
            CResizer.prototype.initComponent.call(this);    	
            var tb = this.titlebar;
            this.wrapper.insertBefore(tb);
            if(this.closeable === true){
                    this.clsBtn = new CItem({
                        cs:'g-win-clsbtn',
                        template:'CWinBarItem',
                        callback:this.close.bind(this),
                        tip:'关闭',
                        id:'_cls'
                    });
                    tb.add(this.clsBtn);
           }
           if(this.destoryOnClose){
           	this.on('closed', this.destoryComponent);
           }
           
           this.domEvent('mousedown', this.trackZIndex);
           this.domEvent('dblclick', this.switchState,true, null, this.titlebar.view);
        },
				
				setTitle : function(tle) {
					this.titlebar.setTitle(tle);
					return this;
				},
				
				trackZIndex : function(){
					if(this.zIndex != globalZ){
						globalZ+=2;
						this.setZ(globalZ);
					}
				},
				
				//override
		    setZ : function(zIndex) {
		        this.style("z-index", zIndex);
		        if(this.shadow)
		        	this.shadow.setZ(zIndex-1);
		        this.zIndex = zIndex;
		        return this;
		    },
    
				switchState : function(){
					if(this.win_s != 'max')
						this.maximize();
					else this.normalize();
				},
				
				getWrapperInsets : function(){
					return [29,1,1,1,30,2];
				},
					
        setTitle : function(tle){
            if(this.titlebar){
                this.titlebar.setTitle(tle);
                this.title = tle;
            }
            return this;
        },
        /**
         * 关闭当前窗口,发送close, closed事件.
         * @return this;
         */
        close : function(){
            if(this.fire('close')=== false)
                return false;
            this.onClose();
            this.fire('closed');
			      return this;
        },
		
        /**
         * 默认的关闭处理
         */
        onClose : function(){
            this.display(0);
        },
        
        destoryComponent : function(){
        	CResizer.prototype.destoryComponent.call(this);
        	if(this.titlebar)
        		this.titlebar.destoryComponent();
        },
        
        _markStated : function(unmark){
        	if(unmark){
	        	var n = CC.delAttr(this, '_normalBounds');
	        	if(n){
	        		this.setXY(n[0]);
							this.setSize(n[1]);
							this.enableH = CC.delAttr(this, '_enableH');
        			this.enableW = CC.delAttr(this, '_enableW');
        			this.setResizable(CC.delAttr(this, '_resizeable'));
							this.titlebar.draggable = CC.delAttr(this, '_draggable');
	        	}
        	}
        	else {
        		this._normalBounds = [this.xy(),this.getSize(true)];
        		this._enableH = this.enableH;
        		this._enableW = this.enableW;
        		this._resizeable = this.resizeable;
        		this._draggable = this.titlebar.draggable;
        	}
        },
        /**
         * 最小化窗口.
         * @return this
         */
        minimize : function(){
        	this.setState('min');
			return this;
        },
		
        /**
         * 恢复正常
         * @return this;
         */
        normalize : function(){
        	return this.setState('normal');
        },
        /**
         * 最大化
         * @return this
         */
        maximize : function(){
        	return this.setState('max');
        },
        /**
         * 切换窗口状态
         * @param {String} st 状态选项, 值为max,min或空,为空时正常状态. 
         */
        setState : function(st) {
        	var ws = this.win_s;
        	
        	if(this.win_s == st)
        		return this;
        	
        	this.fire('statechange', st, ws);
        	
        	switch(ws){
        		case 'min' : 
        			this.delClass(this.minCS);break;
        		case 'max' : this.delClass(this.maxCS);break;
        		default :
        			this._markStated();
        	}
        	
        	switch(st){
        		case 'min' : 
        		  if(this.shadow)
        		  	this.shadow.show();
		        	this.addClass(this.minCS);
		        	this.setHeight(this.minH);
		        	this.setResizable(false);
		        	break;
		        case 'max':
		        	if(this.shadow){
		        		this.shadow.hide();
		        	}
		        	this.titlebar.draggable = false;
		          this.addClass(this.maxCS);
		        	var sz, p = this.parentContainer?this.parentContainer.view : this.view.parentNode;
		        	if(p == document.body){
		        		sz = CC.getViewport();
		        	}
		        	else{
		        		p = CC.fly(p);
		        		sz = p.getSize();
		        		p.unfly();
		        	}
		        	this.setXY(0,0).setSize(sz);
		        	this.setResizable(false);
		        	break;
		        //as normal
		        default : 
		        	this._markStated(true);
		        	if(this.shadow)
		        		this.shadow.show();
        	}
        	this.win_s = st;
        	
        	this.fire('statechanged', st, ws);
        	return this;
        },
		/**
		 * 窗口相对父层居中,这里的居中是相对视角居中.
		 * @function
		 * @return this
		 */
		center : function(anchor){
		    var xy, sz, p = anchor?anchor.view?anchor.view:anchor 
			             : this.parentContainer?this.parentContainer.view : this.view.parentNode;
		    if(!p)
		    	p = document.body;
		    
		    if (p == document.body || p == document.documentElement) {
				sz = CC.getViewport();
				xy = [0,0];
			}
			else {
				p = CC.fly(p);
				sz = p.getSize();
				xy = p.absoluteXY();
				p.unfly();
			}
            var off = (sz.height - this.height) / 2 | 0;
			
			this.setXY( xy[0] + (((sz.width - this.width) / 2) | 0),xy[1] + off - off/2|0);
		     return this;
		}
    };
})());


CTemplate['CDialog.Bottom'] = '<div class="g-win-bottom"><div class="bottom-wrap"></div></div>';
/**
 * 对话框是一个特殊的窗体，底部具有按钮栏，并且可指定是否模式，即是否有掩层。 
 * @super CWin
 * @class CDialog
 * @param {Object} superclass
 * @constructor
 */
CC.create('CDialog', CWin, function(superclass){
	
	return {
		/**
		 * @cfg 内部高度，与CSS一致
		 * @private
		 */
		bottomHeight: 51,
		/**
		 * 返回状态值, 可自定,如ok,cancel...,当对话框某个按钮点击并可返回时,返回值为该按钮ID
		 * @cfg
		 */
    returnCode : false,

		/**
		 * 是否监听键盘事件,如当ESC按下时为取消.
		 * @cfg {Boolean}=true navKeyEvent
		 */
		
		/**
		 * 设置默认按钮,该按钮必须在当前按钮列表中.
		 * @cfg {String}
		 */
		defaultButton : false,
		
		initComponent: function(){
			this.createView();
			this.createBottom();
			this.keyEventNode = this.view;
			superclass.initComponent.call(this);
			if (this.buttons) {
				this.bottomer.fromArray(this.buttons);
				delete this.buttons;
			}
			
			if(this.navKeyEvent)
				this.on('keydown', this.onKeydownEvent, null, true);
		},
		
		/**
		 * 如果按钮的returnCode = false, 取消返回.
		 * @private
		 * @param {CBase} item
		 */
		onBottomItemSelected : function(item){
			if(item.returnCode !== false && item.id){
				this.parentContainer.returnCode = item.id;
				this.parentContainer.close();
			}
		},
		
		/**
		 * 监听对话框键盘事件
		 * 如果为回车,调用onOk,如果为ESC,调用onCancel
		 * @private
		 * @param {Event} evt
		 */
		onKeydownEvent : function(evt){
			var c = evt.keyCode;
		  if (Event.KEY_ESC == c) {
		  	this.onCancel();
		  }else if(Event.isEnterKey(evt)){
		  	this.onOk();
		  }
		},
		
		/**
		 * 触发选择默认按钮.
		 * @function
		 */
		onOk : function(){
		   if(this.defaultButton){
		   	this.bottomer.select(this.defaultButton, true);
		   }
		},
		
		/**
		 * 对话框以false状态返回.
		 */
		onCancel : function(){
			this.returnCode = false;
			this.close();
		},
    
		show: function(parent, modal, callback){
			this.modal = modal;
			this.modalParent = parent;
			this.modalCallback = callback;
			return superclass.show.call(this);
		},
		
		display: function(b){
			if (arguments.length == 0) 
				return superclass.display.call(this, b);
			
			if (b) {
				superclass.display.call(this, b);
				if (this.modal) {
					var m = this.masker;
					if (!m) 
						m = this.masker = new CBase['masker']();
					if (this.modalParent && !m.target) {
						m.attachTarget(this.modalParent);
					}
				}
				this.center(this.modalParent);
				this.trackZIndex.bind(this).timeout(0);
				this.focusDefButton();
			}
			else if (!b) {
					if (this.modal) {
						if(this.modalCallback){
							if(this.modalCallback() === false)
								return this;
						}
						if (this.modalParent) {
							this.masker.detachTarget();
						}
						delete this.modal;
						delete this.modalParent;
						delete this.modalCallback;
					}
					superclass.display.call(this, b);
		  }
			return this;
		},
		

		focusDefButton : function(){
			var def = this.bottomer.$(this.defaultButton);
			if(def)
				def.focus(22);
		},
		
		/**
		 * @private
		 */
		createBottom: function(){
			this.bottomer = new CSelectedContainer({
				ItemClass: CButton,
				template:'CDialog.Bottom',
				container : '_wrap',
				showTo:this.view,
				itemClickEvent : 'click',
				forceSelect : true
			});
			this.follow(this.bottomer);
			//监听按钮点击
			this.bottomer.on('selected', this.onBottomItemSelected);
		},
		
		getWrapperInsets: function(){
			var s = CWin.prototype.getWrapperInsets.call(this);
			s[2] += this.bottomHeight - 1;
			s[4] += this.bottomHeight - 1;
			return s;
		}
	};
});
//masker.js
/**
 * 容器控件遮掩层
 * @cfg target {CPanel}
 * @author Rock
 */
CC.create('CMask', CBase, {
    inherentCS: 'g-modal-mask',
	template : 'div',
	initComponent : function(){
		CBase.prototype.initComponent.call(this);
		if(this.target){
			this.bindTarget(this.target);
		}
		
		this.domEvent('mousedown', this.onMaskResponsed, true);
	},
	
	onMaskResponsed : function(){
	   this.fire('active', this);
	   if(this.onActive)
	   	this.onActive;
	},
	
	attachTarget : function(target){
	  this.target = target;
	  if(this.target.eventable){
	  	this.target.on('resized', this.onTargetResized, this);
	  }
	  this.appendTo(this.target);
	  var f = CC.fly(this.target);
	  this.setXY(0,0).setSize(f.getSize(true));
	  f.unfly();
	  return this;
	},
	
	detachTarget : function(){
	  if(this.target.eventable){
	  	this.target.un('resized', this.onTargetResized);
	  }
	  this.del();
	  this.target = null;
	  return this;
	},
	
	onTargetResized : function(a, b, c, d) {
		this.setSize(c, d);
	},
	
	destoryComponent : function(){
		if(this.target){
			this.detachTarget();
		}
		CBase.prototype.destoryComponent.call(this);
	}
});

CBase['masker'] = CMask;


//menu.js
CTemplate['CMenu'] = '<div class="g-panel g-menu"><div id="_wrap" class="g-panel-wrap"><ul class="g-menu-opt" id="_bdy"  tabindex="1" hidefocus="on"></ul></div></div>';
CTemplate['CMenuItem'] = '<li class="g-menu-item"><span id="_tle" class="item-title"></span></li>';

CC.create('CMenuItem', CItem, function(superclass){
return {
  //子菜单
  subMenu: null,
	
	autoRender : false,
	
	hoverCS : 'itemOn',
	
	template : 'CMenuItem',
	
	subCS : 'sub-x',
	
	initComponent : function(){
		superclass.initComponent.call(this);
		if(this.array){
	  	var sub = new CMenu({array:this.array, showTo:document.body});
	  	this.bindMenu(sub);
	  	delete this.array;
	  }
	},
	
	bindMenu : function(menu){
    menu.parentItem = this;
    this.subMenu = menu;
    this.addClass(this.subCS);
	},
	
	unbindMenu : function(){
		if(this.subMenu){
			var menu = this.subMenu;
			delete menu.parentItem;
			delete this.subMenu;
			this.delClass(this.subCS);
		}
	},
	
	mouseoverCallback : function(ev){
		    var pc = this.parentContainer;
		    if(!pc.autoPopup){
		      	pc._onItem = this;
		      	return;
		      }
		
					//OnMouseOver
		      //隐藏上一菜单项的子菜单
		      if(pc._onItem!=this)
		      	pc._hidePre(); 
		      if (this.subMenu) 
		        this.subMenu.show(1);
		      
		      pc._onItem = this;
	},
	
	mouseoutCallback : function(){
		//if currently the submenu is in view.
		if (this.subMenu && !this.subMenu.hidden)
			return true;
	},
	
	onRender : function() {
		superclass.onRender.call(this);
		if(this.subMenu){
			if(!this.subMenu.rendered)
				this.subMenu.render();
		}
	},
	
	destoryComponent : function(){
		if(this.subMenu){
			this.subMenu.destoryComponent();
			this.unbindMenu();
		}
		superclass.destoryComponent.call(this);
	}
	};
});

//--菜单控件
//默认添加在document.body中
CC.create('CMenu', CSelectedPanel, function(superclass) {
return {
  //父菜单项
  parentItem: null,
	
	//如果该项是一个MenuBar,设为true.
	noContext : false,
	
	autoPopup : true,
	
  //上一掠过菜单项
  _onItem: null,
	
  selectedCS : 'itemOn',
  
	ItemClass : CMenuItem,
	
	container : '_bdy',
	
	itemXCS : 'g-menu-item-x',
	
	separatorCS : 'g-menu-separator',
	
  initComponent: function() {
  	
  	if(!this.noContext){
  		this.shadow = true;
  		this.hidden = true;
    }
    superclass.initComponent.call(this);
    if(this.array){
    	this.fromArray(this.array);
    	delete this.array;
    }
    //撤消菜单内的onclick事件上传
    //默认为不显示
    this.noUp();
  }
	,
  //把子菜单menu添加到tar项上,tar可为一个index,或一个CMenuItem对象,还可为CMenuItem的id
  //附加子菜单时要按从最先至最后附加,这样事件才会被父菜单接收
  attach: function(menu, tar) {
    tar = this.$(tar); 
		tar.bindMenu(menu);
    if(this.align == 'x')
    	tar.delClass(tar.subCS);
  }
  ,
	
	add : function(item){
		if(item.isSeparator){
			this.addSeparator();
			return this;
		}
		
		superclass.add.call(this,item);

		if(this.align == 'x'){
			item.addClass(this.itemXCS);
			item.align=this.align;
		}
		
		if(item.subMenu && this.align == 'x')
			item.delClass(item.subCS);
		return this;
	},
	
  //撤消菜单项上的子菜单
  detach: function(tar) {
    tar = this.$(tar);
    tar.unbindMenu();
    if(this.align == 'x'){
			tar.delClass(this.itemXCS);
			tar.align=false;
    }
  }
  ,
	
	select : function(item){
		item = this.$(item);
    if(superclass.select.call(this,item, true)===false)
    	return false;
    	
    if (item.subMenu) {
      if(this.noContext)
	     	this.autoPopup = !this.autoPopup;
			item.subMenu.show(this.autoPopup);
			if(this.noContext && !this.contexted)
        	this._makeContexted();
      
    	return;
    }
    
    //无子菜单
		this.hideAll();
	},
	
  //显示/隐藏菜单,当点击菜单外时菜单并不用消失.
  show: function(b) {
    if (b)
      this._autoPositioned();

    if (!b) {
      CC.each(this.children, (function(i, e) {
        if (this.subMenu) {
          if (!this.subMenu.hidden) {
            this.subMenu.show(0);
          }
        }
      }
      ));
    }
    return this.display(b);
  }
  ,
	
	addSeparator : function(){
		this._addNode(CMenu.Separator.view.cloneNode(true));
	},
	
	_makeContexted : function(){
		if(this.contexted) {
			return;
		}
    var oThis = this;
    if(!this._onCtxClick) {
	    var onClick = (function() {
	      if (!oThis.hidden) {
	        oThis.hideAll();
	      }
	      oThis.contexted = 0;
	      Event.removeListener(document, 'click', onClick);
	    }
	    );
	    
	    this._onCtxClick = onClick;
  	}
    Event.addListener(document, 'click', this._onCtxClick);
    this.contexted = 1;
	},
	
  //显示界面菜单,与show不同,该方法在指定处显示菜单，并且当点击菜单范围外时自动消失.
  //showMenu(obj,'bottom')或showMenu(120,230)
  showMenu: function(a, b) {
  	
  		if(!this.rendered)
  			this.render();
  			
  		this._makeContexted();
	    
	    if (!CC.isNumber(a)) {
	    	CC.addClass(a, 'menuDwn');
	    	this._trigger = a;
	      var off = Position.cumulativeOffset(a); 
	      switch (b) {
	        case 'right':
	        off[0] += a.offsetWidth; break;
	        default:
	          off[1] += a.offsetHeight; break;
	      }
	      this.setXY(off[0], off[1]);
	    } else {
	      this.setXY(a, b);
	    }
    this.show(true);
  }
  ,

  //隐藏与该菜单相联的所有菜单(包括子菜单和父菜单).
  hideAll: function() {
  	if(this._trigger) {
  		CC.delClass(this._trigger, 'menuDwn');
  		this._trigger = null;
  	}
  	
  	if(!this.noContext){
    	this.display(false);
    }

    if(this.autoPopup && this.noContext){
    		this.autoPopup = false;
    }
    	
    if (this._onItem) {
      this._onItem.delClass(this._onItem.hoverCS);
    }

    CC.each(this.children, (function(i, e) {
      if (this.subMenu) {
        if (!this.subMenu.hidden) {
          this.subMenu.hideAll();
        }
      }
    }
    )); 
    if (this.parentItem) {
      if (!this.parentItem.parentContainer.hidden) {
        this.parentItem.parentContainer.hideAll();
      }
    }
  }
  ,

  //在适当位置显示菜单.
  _autoPositioned: function() {
    if (this.parentItem) {
      var off = this.parentItem.absoluteXY();
      if(this.parentItem.align=='x'){
      	this.setXY(off[0], off[1]+this.parentItem.view.offsetHeight);
      }
      else{
     		this.setXY(off[0] + this.parentItem.view.offsetWidth - 2, off[1]);
    	}
    }
  }
  ,

  _hidePre: function() {
    if (this._onItem) {
      var pre = this._onItem; 
      var cs = this.selectedCS;
      if(cs)
      	pre.delClass(cs);
      if (pre.subMenu) {
        pre.subMenu.show(false);
      }
    }
  }
};
});

CMenu.Separator = CC.$$(CC.$C({tagName:'LI', className:CMenu.prototype.separatorCS}));
CMenu.Separator.isSeparator = true;
//tab.js
CTemplate['CIconButton'] = '<table unselectable="on" class="g-unsel g-tab-item"><tbody><tr id="_ctx"><td class="tLe" id="_tLe"></td><td class="bdy"><nobr id="_tle" class="g-tle">选卡1</nobr></td><td class="btn" id="_btnC"><a href="javascript:fGo()" title="关闭" id="_trigger" class="g-ti-btn"></a></td><td class="tRi" id="_tRi"></td></tr></tbody></table>';

CC.create('CTabItem', CSelectedContainer, function(superclass) {

  function hideDDRBar() {
    Cache.put('CItemDDRBarUp', Cache.get('CItemDDRBarUp').display(false));
  }

  return {
    template: 'CIconButton',
    hoverCS: false,
    selectedCS: false,
    closeable: true,
    unselectable: true,
    container: '_ctx',
    ondropable: true,
    draggable: true,
    blockMode: '',

    initComponent: function() {
      superclass.initComponent.call(this);
      var c = this.cacheBtnNode = this.dom('_btnC');
      if (c) c.parentNode.removeChild(c);

      this._bindCloseEvent();
      this.setCloseable(this.closeable);

    },

    addButton: function(cfg) {
      var td = this.cacheBtnNode.cloneNode(true);
      cfg.view = td;
      td.id = cfg.id;
      cfg.iconNode = '_trigger';
      // apply the basic functionality to this button.
      var td = CBase.create(cfg);
      this.add(td);
      return td;
    },

    getContentPanel: function(autoCreate) {
      var p = this.panel;
      if (!p && autoCreate) {
        //iframe
        if (this.src) {
          p = this.panel = new CIFramePanel();
        }
        else {
          p = this.panel = new CPanel();
        }
      }
      return p;
    },

    _addNode: function(node) {
      if (this.buttonOrient != 'l') 
      	this.fly('_tRi').insertBefore(node).unfly();
      else this.fly('_tLe').insertAfter(node).unfly();
    },

    _closeTriggerFn: function() {
      this.parentContainer.close(this);
    },

    _bindCloseEvent: function() {
      var cls = this.$$(this.closeNode);
      if (!cls) {
        cls = this.addButton({
          id: '_clsBtn',
          blockMode: '',
          icon: 'g-ti-clsbtn'
        });
      }
      //close event.
      this.domEvent('click', this._closeTriggerFn, true, null, cls.view);
      this.domEvent('dblclick', this._closeTriggerFn, true);
      //不影响父容器mousedown事件.
      cls.view.onmousedown = Event.noUp;
    },

    setCloseable: function(b) {
      if (this.cacheBtnNode) {
        this.closeable = b;
        this.$('_clsBtn').display(b);
      }
      else superclass.setCloseable.call(this, b);

      return this;
    },

    dragStart: function() {
      var g = CGhost.instance;
      g.enableTip = true;
      g.setTitle('Drag \'' + this.title.truncate(10) + '\'');
    },

    dragSBOver: function(item) {
      var b = (item.parentContainer && item.parentContainer == this.parentContainer);
      if (b) {
        //显示方位条
        var pxy = this.absoluteXY(),
        bar = Cache.get('CItemDDRBarUp');
        pxy[0] -= 9;
        pxy[1] -= bar.getHeight(true) - 2;
        bar.setXY(pxy).display(true);
        Cache.put('CItemDDRBarUp', bar);
      }
      return b;
    },

    SBDrop: function(tar) {
      var ct = this.parentContainer;
      ct.insertBefore(tar, this);
      ct.select(tar);
    },

    dragSBOut: hideDDRBar,

    afterDrop: hideDDRBar
  };
});


CC.create('CTab', CSelectedPanel, function(superclass) {
  return {

    itemWidth: false,

    navKeyEvent: true,

    template: 'CAutoScrollLayout',

    movPanelCS: 'g-mov-tab',
    
    inherentCS :'g-tab',

    keyEventNode: '_scrollor',

    KEY_UP: Event.KEY_LEFT,

    KEY_DOWN: Event.KEY_RIGHT,
    maxH: 33,
    ItemClass: CTabItem,

    itemLoadCS: 'g-tabitem-loading',

    itemAutoConnect: false,
    
	  destoryItemOnclose : false,
	  /**
	   * 主要用于autoscrolllayout布局
	   */
	  layoutCfg : {
	      horizonMargin: 5,
        
        /**
         * 该值须与左边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navLeftWidth: 24,
        
        /**
         * 该值须与右边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navRightWidth: 24
	  },
	  
    initComponent: function() {
      superclass.initComponent.call(this);
      if (this.itemAutoConnect) {
        this.on('selected', this.onSelected);
      }
    },

    /**
         * 如果允许自动加载TabItem内容,监听选择事件并加载内容.
         * 当项选择后才会加载.
         */
    onSelected: function(item) {
      if ((!item.url && !item.src) || !this.itemAutoConnect) return;
      var p = item.panel;
      if (!p) {
        p = item.getContentPanel(true);
        p.defLoadSuccess = this._defItemLoadOnSuccess;
        if (this.contentPanel) this.contentPanel.add(p);
      }
      else if (p.loaded || p.busy) {
        return;
      }

      if (!p.loadIndicator) {
        //自定Loading标识
        p.getLoadIndicator({
          markIndicator: this.onItemMarkIndicator,
          stopIndicator: this.onItemStopIndicator
        });
      }

      //Panel指向TAB项的引用
      p.bindingTabItem = item;
      p.connect(item.src || item.url);
    },

    /**
         * TabItem内容面板加载时样式设置,这里主要在TabItem上显示一个loading图标.
         */
    onItemMarkIndicator: function() {
      var t = this.target.bindingTabItem;
      //此时的this为loading indicator.
      t.addClass(t.parentContainer.itemLoadCS);
      t._closeable = t.closeable;
      t.closeable = false;
    },

    onItemStopIndicator: function() {
      //此时的this为loading indicator.
      var tg = this.target,
      t = tg.bindingTabItem;
      if (t) {
        t.delClass(t.parentContainer.itemLoadCS);
        t.closeable = t._closeable;
        delete t._closeable;
        delete tg.bindingTabItem;
      }
    },

    /**
         * TabItem内容面板加载成功后默认的Ajax处理.
         */
    _defItemLoadOnSuccess: function(ajax) {
      this.wrapper.html(ajax.getText(), true);
    },

    /**
         * 关闭指定CTabItem,当只有一个CTabItem时忽略.
         */
    close: function(item) {
      item = this.$(item);
      if (!item.closeable || this.getDisc() == 1) return;
      if (this.fire('close', item) === false) return false;
      this.displayItem(item, 0);
      this.fire('closed', item);
	  if(this.destoryItemOnclose){
	  	if(item.panel){
			if(item.panel.view)
				item.panel.destoryComponent();
			else item.panel.parentNode.removeChild(item.panel);
		 }
		 this.remove(item);
		 item.destoryComponent();
	  }
    },

    //@override
    add: function(it) {
      if (superclass.add.call(this, it) === false) return false;
      //
      if (it.panel) {
      	it.panel.display(false);
      }

      if (this.itemWidth) it.setWidth(this.itemWidth);
      //this._ajust();
    },

    _ajust: fGo,

    //是否显示指定的TabItem,
    //参数a可为TabItem实例也可为TabItem的id,b为true或false.
    displayItem: function(a, b) {
      a = this.$(a);
      //Cann't change this attribute.
      if (!a.closeable && !b) {
        return false;
      }

      var isv = !a.hidden;

      superclass.displayItem.call(this, a, b);

      if (isv != b) {
        this._ajust();
      }

      //切换下一个CTabItem
      if (!b && this.selected == a) {
        var idx = this.indexOf(a);
        var tmp = idx - 1;
        var chs = this.children;
        while (tmp >= 0 && (chs[tmp].hidden || chs[tmp].disabled)) {
          tmp--;
        }
        if (tmp >= 0) {
          this.select(chs[tmp]);
          return;
        }

        tmp = chs.length;
        idx += 1;
        while (idx < tmp && (chs[idx].hidden || chs[idx].disabled)) {
          idx++;
        }
        if (idx < tmp) {
          this.select(chs[idx]);
        }
      }
    },

    //选择某个TabItem,
    //参数a可为TabItem实例也可为id.
    //b为强制选择
    onSelect: function(a) {
      superclass.onSelect.call(this, a);
      a = this.$(a);
      for (var i = 0, len = this.size(); i < len; i++) {
        var ch = this.children[i];
        if (ch != a && ch.panel) {
        	var p = ch.panel;
          if (!p.hidden)
          	p.display(false);
        }
      }

      if (!a) return;
      a.show();
      if (a.panel){
      	(function(){
        	a.panel.display(true);
      	}).timeout(20);
      }
    },

    //返回显示的TabItem个数.
    getDisc: function() {
      var cnt = 0;
      var chs = this.children;
      for (var i = 0, len = chs.length; i < len; i++) {
        if (!chs[i].hidden) {
          cnt++;
        }
      }
      return cnt;
    }
  };
});
//tree.js
CTemplate['CTree'] = '<div class="g-tree"><div class="g-panel-body g-panel-body-noheader" id="_scrollor"><ul id="_ctx" class="g-tree-nd-ct  g-tree-arrows" tabindex="1" hidefocus="on"></ul></div></div>';
CTemplate['CTreeItem'] = '<li class="g-tree-nd"><div class="g-tree-nd-el g-unsel" unselectable="on" id="_head"><span class="g-tree-nd-indent" id="_ident"></span><img class="g-tree-ec-icon g-tree-elbow-minus" id="_elbow" src="'+CTemplate.BLANK_IMG+'"/><img unselectable="on" class="g-tree-nd-icon" src="'+CTemplate.BLANK_IMG+'" id="_ico" /><a class="g-tree-nd-anchor" unselectable="on" hidefocus="on" id="_tle"></a></div><ul class="g-tree-nd-ct" id="_bdy" style="display:none;" tabindex="1" hidefocus="on"></ul></li>';
CTemplate['CTreeItemSpacer'] = '<img class="g-tree-icon" src="'+CTemplate.BLANK_IMG+'"/>';
/**
 * 树型控件实现
 */
CC.create('CTreeItem', CContainerBase, function(superclass){
return {
	/**
	 *每个CTreeItem都有一个指向根结点的指针以方便访问根结点.
	 */
	root : null,
	
	/**
	 * 指明容器结点为视图中ID结点.
	 */
	container : '_bdy',
	
	/**
	 *@override 设置触发事件的结点ID.
	 */
	dragNode : '_head',
	
	/**
	 * 鼠标掠过时样式.
	 */
	hoverCS : 'g-tree-nd-over g-tree-ec-over',
	splitEndPlusCS : 'g-tree-split-end-plus',
	splitEndMinCS : 'g-tree-split-end-minus',
	splitPlusCS : 'g-tree-split-plus',
	splitMinCS :'g-tree-split-minus',
	splitCS : 'g-tree-split',
	splitEndCS : 'g-tree-split-end',
	nodeOpenCS : 'g-tree-nd-opn',
	nodeClsCS : 'g-tree-nd-cls',
	nodeLeafCS : 'g-tree-nd-leaf',
	loadCS:'g-tree-nd-loading',
	/**
	 * 空占位结点样式.
	 */
	elbowLineCS :'g-tree-elbow-line',
	
	springCS : 'spring',
	/**
	 * 鼠标掠过时添加样式的触发结点id
	 *@see CBase#bindAlternateStyle
	 */
	mouseoverNode : '_head',
	
	/**
	 * 鼠标掠过时添加样式目标结点id.
	 */
	mouseoverTarget : '_head',
	
	//树结点是否为目录,默认false.
	nodes : false,
	
	//监视子项点击
	itemClickEvent : 'mousedown',
	
	itemClickEventNode : '_head',
	
	template : 'CTreeItem',
	
	ItemClass : 'CTreeItem',
	
	initComponent : function(opt) {
		//
		if(!this.root)
			this.root = this;
		if(this.array && !this.nodes)
			this.nodes = true;
		
		superclass.initComponent.call(this);
		this._ident = this.$$('_ident');
		this._elbow = this.$$('_elbow');
		this._head  = this.$$('_head');
		
		//文件夹
		if(this.nodes) {
			this.domEvent('dblclick', this.expand, true, null, this._head.view);
			this.domEvent('mousedown', this.expand, true, null, this._elbow.view, false);
		}
		else
			this._head.addClass(this.nodeLeafCS);
		
		this._attachElbowStyle(false);
	},
	
	addIcon : function(icon, cfg){
		var cn = CTemplate.$('CTreeItemSpacer');
		if(cfg)
			CC.extend(cn, cfg);
		CC.fly(cn).addClass(icon).unfly();
		this.fly(this.titleNode).insertBefore(cn).unfly();
		return this;
	},
	
	addSpring : function(spring){
		if(spring.view)
			this.follow(spring);
		this.fly(this.titleNode).insertBefore(spring).unfly();
		CC.fly(spring).addClass(this.springCS).unfly();
	},
	
	expand : function(b) {
		if(b !== true && b !== false)
			b = !CC.display(this.container);
		if(this.root.tree.fire('expand',this,b)===false)
			return false;
    this._attachElbowStyle(b);
    
		CC.display(this.container,b);
	  this.expanded = b;
	  
		if(this.root.tree.fire('expanded',this,b)===false)
				return false;
	},
	
	_attachElbowStyle : function(b) {
		if(arguments.length==0)
			b = CC.display(this.container);
			
		var p = this.parentContainer;
		var last = (!p) || (p.container.lastChild == this.view);
		var en = this._elbow, 
		    sepcs = this.splitEndPlusCS, 
		    semcs = this.splitEndMinCS,
		    spcs = this.splitPlusCS,
		    smcs = this.splitMinCS;

    if(this.nodes){
			if(!last) {
	    		if(en.hasClass(sepcs))
	    			en.delClass(sepcs);
	    		else if(en.hasClass(semcs))
	    			en.delClass(semcs);
			}else {
	    		if(en.hasClass(spcs))
	    			en.delClass(spcs);
	    		else if(en.hasClass( smcs))
	    			en.delClass(smcs);
			}
	    if (b) {
	    	if(!last)
	    		en.switchClass(spcs, smcs);
	      else 
	      	en.switchClass(sepcs, semcs);
	      this._head.switchClass(this.nodeClsCS, this.nodeOpenCS);
	      
	    } else {
	    	if(!last)
	    		 en.switchClass(smcs, spcs);
	    	else
	    		en.switchClass(semcs, sepcs);
	      this._head.switchClass(this.nodeOpenCS, this.nodeClsCS);
	    }
	    return;
		}
	  //leaf
    (last) ? 
    	en.switchClass(this.splitCS, this.splitEndCS) :
    	en.switchClass(this.splitEndCS, this.splitCS);
	},
	
	add : function(item) {
		var pre = this.children[this.children.length-1];
		superclass.add.call(this, item);
		item._applyChange(this);
		if(pre)
			pre._attachElbowStyle();
		item._attachElbowStyle();
	},
	/**
	 * 该结点发生变动时重组
	 */
	_applyChange : function(parentNode) {
		//所有事件由据结点的事件监听者接收
		this._applyRoot(parentNode.root);
		this._applySibling();
		this._fixSpacer(parentNode);
		if(this.nodes) {
			this.ItemClass = parentNode.root.ItemClass;
			CC.addClass(this._ident.view.lastChild,parentNode.elbowLineCS);
		}
	},
	
	_applyRoot : function(root){
		if(this.root == root)
			return;
		this.root = root;
		if(this.nodes){
			var chs = this.children;
			for(var k=chs.length - 1;k>=0;k--){
				if(chs[k].nodes)
					chs[k]._applyRoot(root);
				else chs[k].root = root;
			}
		}
	},
	
  _applySibling : function(detach){
  	if(detach){
  		if(this.previousSibling)
				this.previousSibling.nextSibling = this.nextSibling;
			
			if(this.nextSibling)
				this.nextSibling.previousSibling = this.previousSibling;
			
		  this.nextSibling = this.previousSibling = null;
		  return;
  	}
  	
  	var ct = this.parentContainer;
  	if(!ct){
  		this.previousSibling = this.nextSibling = null;
  		return;
  	}
  	c = ct.children, idx = c.indexOf(this);
		this.nextSibling = c[idx+1];
		if(this.nextSibling)
			this.nextSibling.previousSibling = this;
		this.previousSibling = c[idx-1];
		if(this.previousSibling)
			this.previousSibling.nextSibling = this;
  },
  
    //子项点击事件回调,发送itemclick事件.
   _itemClickTrigger : function(event){
   		 //if(Event.element(event) != this._elbow.view)
       	 this.root.tree.fire('itemclick', this, event);
   },
    
	remove : function(item) {
		var item = this.$(item);
		var last = this.children[this.children.length-1] == item;
		item._applySibling(true);
		superclass.remove.call(this, item);
		
		//如果删除当前选择项,重设选择为空.
		if(item == this.root.tree.selected)
			this.root.tree.select(null);
		
		if(last)
			if(this.size()>0)
				this.children[this.children.length-1]._attachElbowStyle();
		return this;
	},
	
	/**
	 * 只有在渲染时才能确定根结点
	 */
	onRender : function(){
		this.root = this.parentContainer.root;
		this._applySibling();
		superclass.onRender.call(this);
	},
	
	insert : function(idx, item){
		superclass.insert.call(this, idx, item);
		item._applyChange(this);
		item._attachElbowStyle();
	},
	
	getSpacerHtml : function() {
		if(this.root == this)
			return CTemplate['CTreeItemSpacer'];
		return this._ident.view.innerHTML + CTemplate['CTreeItemSpacer'];
	},
	
	_fixSpacer : function(parentNode) {
		this._ident.view.innerHTML = parentNode.getSpacerHtml();
		if(this.nodes){
			for(var i=0,len=this.size();i<len;i++) {
				this.children[i]._fixSpacer(this);
			}
		}
	}
};
});

CC.create('CTree', CSelectedContainer, function(superclass){
	
	return {
		
	container : '_ctx',

	parentParamName : 'pid',
	
	navKeyEvent : true,
	
	selectedCS : 'g-tree-selected',
 
	_itemClickTrigger : CTreeItem.prototype._itemClickTrigger,
	
	/**
	 * 项的选择事件触发结点为视图中指向的id结点.
	 */
	itemClickEventNode : '_head',
	
	selectedCSTarget : '_head',
	
	itemClickEvent : true,
	
	initComponent : function() {
		
		superclass.initComponent.call(this);
		
		if(!this.root) {
			opt = {nodes:true, draggable:false, ItemClass:CTreeItem};
			this.root = new CTreeItem(opt);
		}
		this.root.tree = this;
		this.root.setTitle(this.title);
		var self = this;
		this.add(this.root);
		this.on('expand', this.onExpand, this);
	},
	
	//自动加载功能
	onExpand : function(item, b) {
		//
		// 如果结点已经加载,忽略.
		//
		if(!this.autoConnect  || !b || item.busy || item.loaded){
			return;
		}
		
		var url = this.url;
		if(url){
			url+='&'+this.parentParamName+'='+item.id;
			if(!item.loadIndicator){
				//自定Loading标识
				item.getLoadIndicator({markIndicator:this.onItemMarkIndicator, stopIndicator:this.onItemStopIndicator});
			}
			item.connect(url);
			return (item.children.length>0);
	  }
	},
	
	onItemMarkIndicator : function(){
		//此时的this为loading indicator.
		this.target._head.addClass(this.target.loadCS);
	},
	
	onItemStopIndicator : function(){
		//此时的this为loading indicator.
		this.target._head.delClass(this.target.loadCS);
		this.target.expand(true);
	},

	findChildDeep : function(childId){
	  if(this.id == childId)
	  	return this;
	    
	  if(!this.nodes)
	     return false;
	  
	  var chs = this.children, fnd, ch;
	  for(var i=0,len = chs.length;i<len;i++){
	  	ch = chs[i];
	  	if(ch.id = childId)
	    	return ch;
	    if(ch.nodes){
	    	fnd = ch.findChildDeep(childId);
		    if(fnd)
		    	return fnd;
	    }
		}
	},
	
	//@override
	$ : function(a){
		return a;
	},
	/**
	 * 按键导航
	 */
  selectNext : function(t){
  	var s = this.selected;
  	if(!s){
   		this.select(this.root);
    	return this.root;
    }
		var n = s, 
	      dir = !(n.nodes && n.expanded && n.children.length>0);
    if(!dir)
    	//向下
    	n = n.children[0];

    while(true){
    	if(dir){
	    	if(!n.nextSibling){
	    		  //上溯到顶
	    			if(n == this.root)
	    				return null;
		    		n = n.parentContainer;
	    			continue;
	    	}
	      n = n.nextSibling;
	      if(n.hidden || n.disabled)
	    	 continue;
	    	else break;
	    }else {
	    	if(n.hidden || n.disabled)
	    	 dir = true;
	    	else break;
	    }
    }
    
    this.select(n);

    return null;
  },
  
  selectPre  : function(item){
  	var s = this.selected;
  	if(!s){
   		this.select(this.root);
    	return;
    }
    var n = s.previousSibling;
    while((!n || n.hidden || n.disabled || (n.nodes && n.expanded && n.children.length>0)) && n != this.root){
    	if(!n){
    			if(s == this.root)
    				return null;
	    		n = s.parentContainer;
	    		break;
    	}
    	else if(n.nodes && !n.disabled && !n.hidden){
    		n = n.children[n.children.length-1];
    	}else n = n.previousSibling;
    }
    
    if(n!=s)
    	this.select(n);
    return n;
  }
}
});
//datepicker.js
CTemplate['CDatepicker'] = '<div class="g-datepicker" ><div style="position: relative;"><table cellspacing="0" cellpadding="0" class="entbox"><tbody><tr><td class="headline"><table width="100%" cellspacing="0" cellpadding="1" align="center" class="dxcalmonth"><tbody><tr><td align="left" class="month_btn_left"><span></span></td><td align="center"><table cellspacing="0" cellpadding="0" align="center"><tbody><tr><td><div id="_seltor" class="g-datepicker-selecor" style="display:none;"></div><div id="_planeY" class="planeYear" title="点击选择或直接输入年份值" style="cursor: pointer;">1955</div></td><td class="comma">,</td><td><div id="_planeM" class="planeMonth" title="点击选择或直接输入年份值"></div></td></tr></tbody></table></td><td align="right" class="month_btn_right"><span></span></td></tr></tbody></table></td></tr><tr><td><table width="100%" cellspacing="0" cellpadding="0" class="g-datepicker-body"><tbody><tr><th class="month_spr"><span>月</span></th><th><span>日</span></th><th><span>一</span></th><th><span>二</span></th><th><span>三</span></th><th><span>四</span></th><th><span>五</span></th><th><span>六</span></th><th class="month_spr"><span>月</span></th></tr></tbody></table></td></tr><tr><td id="_monthWrap"></td></tr><tr><td style="text-align:center;padding-bottom:5px;" id="_tdytd"></td></tr></tbody></table><div class="leftsplit" id="_preBar" onmouseover="CC.addClass(this, \'leftsplitOn\')" onmouseout="CC.delClass(this, \'leftsplitOn\')" ></div><div class="rightsplit" onmouseover="CC.addClass(this, \'rightsplitOn\')" onmouseout="CC.delClass(this, \'rightsplitOn\')" id="_nxtBar"></div></div></div>';

CC.create('CDatepicker', CPanel, function(superclass) {
  var monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  //是否闰年
  function isLeapYear(year) {
    return !! ((year & 3) == 0 && (year % 100 || (year % 400 == 0 && year)));
  }
  //指定月天数,mm由1开始
  function sumDays(yy, mm) {
    return (mm != 2) ? monthDays[mm - 1] : (isLeapYear(yy)) ? 29 : 28;
  }
  //该月的第一天为星期几
  function firstDayOfMonth(date) {
    var day = (date.getDay() - (date.getDate() - 1)) % 7;
    return (day < 0) ? (day + 7) : day;
  }

  return {

    shadow: true,

    unselectable: true,

    eventable: true,

    value: new Date(),

    fmt: 'yy/mm/dd',

    mm: null,

    yy: null,

    dd: null,

    initComponent: function() {
      superclass.initComponent.call(this);
      this.monthWrap = this.dom('_monthWrap');
      this.domEvent('click', this.onDayClick, true, null, this.monthWrap);
      this.domEvent('click', this.onYearList, true, null, '_planeY');
      this.domEvent('click', this.onNavBarMove, true, null, '_nxtBar');
      this.domEvent('click', this.onNavBarMove, true, null, '_preBar');
      if (this.value) {
        this.setValue(this.value, true);
      }
      this.todayBtn = new CButton({
        showTo: this.dom('_tdytd'),
        title: '今天'
      });
      this.follow(this.todayBtn);
      this.domEvent('click', this.toToday, true, null, this.todayBtn.view);
      this.selectorNode = this.dom('_seltor');
    },

    _hideYearSel: function() {
      CC.fly(this.selectorNode).display(false).unfly();
    },

    onNavBarMove: function(evt) {
      var el = Event.element(evt);
      if (el.id == '_nxtBar') {
        this.selectYear(this.yy + 1);
      } else this.selectYear(this.yy - 1);
    },

    selectYear: function(yy) {
      this.setValue(new Date(yy, this.mm, 1), true);
    },

    toToday: function() {
      this.setValue(new Date());
    },

    onYearList: function() {
      var dv = this.selectorNode;
      var c = CC.fly(dv);
      c.bindContext().display(true).unfly();

      if (!dv.firstChild) {
        this.createSelectorContent();
      }

      dv.firstChild.value = this.yy;
      dv.lastChild.value = '';
      (function() {
        dv.lastChild.focus();
      }).timeout(30);
    },

    createSelectorContent: function() {
    	var dv = this.selectorNode;
      dv.innerHTML = this.getSelectListHtml();
      var pan = this.fly('_planeY');
      var sz = pan.getSize(),
      sel = dv.firstChild,
      txt = dv.lastChild;
      pan.unfly();
      CC.fly(txt).style('width', sel.offsetWidth).style('height', sel.offsetHeight).unfly();

      this.noUp('click', dv);
      this.domEvent('change', function() {
        this.selectYear(sel.value);
        this._hideYearSel();
      },
      false, null, sel);
      this.bindEnter(function() {
        var v = parseInt(txt.value.trim());
        if (!isNaN(v)) this.selectYear(v);

        this._hideYearSel();
      },
      false, null, txt);
    },

    getSelectListHtml: function() {
      var html = ['<select>'],
      ys = this.selectYearStart || 1900,
      es = this.selectYearEnd || 2100;
      for (var i = ys; i <= es; i++) {
        html.push('<option value="' + i + '">' + i + '</option>');
      }
      html.push('<input type="text" />');
      return html.join('');
    },

    onDayClick: function(evt) {
      var el = Event.element(evt);
      if (el == this.monthWrap) return;
      var id = CC.tagUp(el, 'TD').id;
      if (id.indexOf('/') > 0) this.setValue(new Date(id));
      else this.setValue(new Date(this.yy, parseInt(id), 1), true);
    },

    setValue: function(v, cancelEvent) {
      var pre = this.currentDate;
      if (!CC.isDate(v)) {
        v = CC.dateParse(v, this.fmt);
      }

      var yy = v.getFullYear();
      if (isNaN(yy)) {
        console.debug('invalid date :' + v);
        return;
      }

      var mm = v.getMonth(),
      dd = v.getDate();
      if (this.disableFilter) if (this.disableFilter(yy, mm + 1, dd)) return;
      this.yy = yy;
      this.mm = mm;
      this.dd = dd;

      this.currentDate = v;
      this.update(pre);
      if (!cancelEvent) this.fire('select', CC.dateFormat(v, this.fmt), v);
    },

    update: function(preDate) {
      var mm = this.mm + 1,
      yy = this.yy,
      dd = this.dd;

      this.dom('_planeM').innerHTML = mm + '月';
      this.dom('_planeY').innerHTML = yy + '年';
      var mw = CC.fly(this.monthWrap),
      id;
      if (preDate && yy == preDate.getFullYear() && mm == preDate.getMonth() + 1) {
        id = (preDate.getMonth() + 1) + '/' + preDate.getDate() + '/' + preDate.getFullYear();
        CC.delClass(mw.dom(id), 'selday');
      } else this.monthWrap.innerHTML = this.getMonthHtml(this.currentDate);

      id = mm + '/' + dd + '/' + yy;
      var dom = mw.dom(id);
      if (dom) CC.addClass(dom, 'selday');
      mw.unfly();
    },

    getMonthHtml: function(date) {
      var html = [];
      var mm = date.getMonth() + 1,
      yy = date.getFullYear(),
      days = sumDays(yy, mm),
      ct = mm - 1,
      py = date.getFullYear();

      var ny = py;
      var preM = ct == 0 ? 12 : ct;
      if (preM == 12) py -= 1;

      ct = mm + 1;
      var nxtM = ct > 12 ? 1 : ct;
      if (nxtM == 1) ny += 1;

      var fstday = firstDayOfMonth(date);
      var psum = sumDays(py, preM);
      var psd = psum - fstday + 1;
      //sunday, show more days to previous month.
      if (fstday == 0) psd = psum - 6;

      html.push('<table class="g-datepicker-days"  width="100%" cellspacing="0" cellpadding="0"><tbody>');
      //visible two months
      var state = 0,
      cls = 'preday',
      m = preM,
      y = py,
      df = this.disableFilter;

      for (var i = 0; i < 6; i++) {
        //week days
        html.push('<tr><td class="month_sep" id="' + i + '"><a href="javascript:fGo()" hidefocus="on">' + (i + 1) + '</a></td>');
        for (var j = 0; j < 7; j++) {
          html.push('<td class="' + cls);
          if (j == 6) html.push(' sateday');
          else if (j == 0) html.push(' sunday');

          if (df) if (df(y, m, psd)) html.push(' disabledday');
          html.push('" id="' + m + '/' + psd + '/' + y + '"><a href="javascript:fGo()" hidefocus="on">' + psd + '</a></td>');

          psd++;
          if (psd > psum && state == 0) {
            psd = 1;
            state = 1;
            cls = 'curday';
            m = mm;
            y = yy;
          } else if (state == 1 && psd > days) {
            state = 2;
            psd = 1;
            cls = 'nxtday';
            m = nxtM;
            y = ny;
          }
        }
        html.push('<td class="month_sep month_r" id="' + (i + 6) + '"><a href="javascript:fGo()" hidefocus="on">' + (i + 7) + '</a></td></tr>');
      }
      html.push('</tbody></table>');
      return html.join('');
    }
  };
});

/**
 * 全局实例
 * 用法 <input type="text" onclick="CDatepicker.show(this)" />
 */

CDatepicker.dateFormat = 'yy/mm/dd';

CDatepicker.show = (function(DP) {
  var instance;
  function onselect(v) { (function() {
      instance.hide();
      instance.bindingEditor.value = v;
      instance.bindingEditor = null;
    }).timeout(200);
  }

  function showDatepicker() {
    var dp = instance,
    f = CC.fly(dp.bindingEditor);
    dp.display(true);
    dp.setValue(dp.bindingEditor.value.trim(), true);
    //get the right position.
    var xy = f.absoluteXY();
    dp.setXY(xy[0], xy[1] + f.getHeight());
    dp.bindContext();
  }

  return function(input) {
    if (!instance) {
      instance = DP.instance = new DP({
        hidden: true,
        showTo: document.body,
        autoRender: true
      });
      instance.on('select', onselect);
    }
    instance.dateFormat = DP.dateFormat;
    instance.bindingEditor = input;
    showDatepicker(true);
  };
})(CDatepicker);

/**
 * Datepicker field element
 */
CTemplate['CDatepickerField'] = '<div class="g-datepicker-field"><input type="text" id="_el" /><a title="点击选择日期" class="trigger" id="_trigger" href="javascript:fGo();"><b> </b></a></div>';

CC.create('CDatepickerField', CFormElement, {
  template: 'CDatepickerField',
  focusCS: 'g-datepicker-field-focus',
  triggerHoverCS: 'triggerOn',
  contextCS: 'g-datepicker-field-ctx',
  initComponent: function() {
    CFormElement.prototype.initComponent.call(this);
    this.bindHoverStyle(this.triggerHoverCS, true, null, null, null, '_trigger', '_trigger');
    this.domEvent('click', this.onTriggerClick, true, null, '_trigger');
  },

  onTriggerClick: function() {
    this.showDatepicker(!!this.getDatepicker().hidden);
  },

  showDatepicker: function(b) {
    var dp = this.getDatepicker();
    this.datepicker.display(b);
    if (b) {
      if (this.getValue()) {
        dp.setValue(this.getValue(), true);
      }
      //get the right position.
      var xy = this.absoluteXY();
      dp.setXY(xy[0] + (this.getWidth() - dp.getWidth(true)), xy[1] + this.getHeight(true));
      dp.bindContext(null, false, null, null, this, this.contextCS);
    }
  },

  onRender: function() {
    CFormElement.prototype.onRender.call(this);
    this.setWidth(this.getWidth());
  },

  getDatepicker: function() {
    var dp = this.datepicker;
    if (!dp) {
      dp = this.datepicker = new CDatepicker({
        showTo: document.body,
        autoRender: true,
        hidden: true
      });
      this.follow(dp);
      dp.on('select', this._onDateSelect);
    }
    return dp;
  },

  _onDateSelect: function(v) {
    var self = this;
    (function() {
      self.parentContainer.showDatepicker(false);
      self.parentContainer.setValue(v);
    }).timeout(200);
  },

  setWidth: function(a) {
    CFormElement.prototype.setWidth.call(this, a);
    var f = this.fly('_trigger');
    CC.fly(this.element).setWidth(a - (f.getWidth()||22)).unfly();
    f.unfly();
  }

});

CFormElement['datepicker'] = CDatepickerField;
//grid.js
CTemplate['CGrid'] = '<div class="g-panel g-grid"><table class="g-panel-wrap g-grid-main" id="_wrap"  cellspacing="0" cellpadding="0"><tbody><tr><td style="vertical-align: top;" id="_hdctx"></td></tr><tr><td style="vertical-align: top;"><div id="_grid_ctx" class="g-gridview-ctx"><div class="g-grid-end" id="_g_end"></div></div></td></tr></tbody></table></div>';

/**
 * 表格列.
 * @class CColumn
 * @super CBase
 * @param {Object} superclass
 */
CC.create('CColumn', CBase, function(superclass){
    //
    // 隐藏插入条,插入条是在列拖放的时候的插入图标提示
    //
    function hideDDRBar(){
        Cache.put('CItemDDRBarUp', Cache.get('CItemDDRBarUp').display(false));
    }
    
    return {
        inherentCS: 'g-grid-hdcol',
        sortable: true,
        draggable: true,
        ondropable: true,
        initComponent: function(){
            this.view = CC.$C({
                tagName: 'TD'
            });
            this.view.appendChild(CC.$C({
                tagName: 'DIV',
                className: 'hdrcell',
                id: '_tle'
            }));
            superclass.initComponent.call(this);
        },
        //
        // 如果正在列缩放范围,取消拖放.
        //
        beforeDragStart: function(){
            if (this.view.style.cursor == 'col-resize') 
                return false;
        },
        
        //
        // 拖放开始,设置提示
        //
        dragStart: function(){
            CGhost.instance.enableTip = true;
            CGhost.instance.setTitle(this.title);
        },
        //
        // 拖放列位于当前列上空时,测试是否允许放下
        //
        dragSBOver: function(col){
            //是否允许放下
            var b = (col.parentContainer && col.parentContainer == this.parentContainer);
            if (b) {
                //显示插入条
                var pxy = this.absoluteXY(), bar = Cache.get('CItemDDRBarUp');
                pxy[0] -= 9;
                pxy[1] -= bar.getHeight(true);
                bar.setXY(pxy).display(true);
                Cache.put('CItemDDRBarUp', bar);
            }
            return b;
        },
        
        dragSBOut: hideDDRBar,
        //
        // 拖放列放下时
        //
        SBDrop: function(col){
            var ct = this.parentContainer;
            ct.fire('colswap', this, col, ct.indexOf(this), ct.indexOf(col));
            hideDDRBar();
        },
        
        afterDrop: hideDDRBar,
        
        /**
         * 设置列宽时,表头会发送colresize事件以通过表格的其它列更新宽度.
         * 当该列的disabledResize属性为false,设置宽无效.
         *@override
         */
        setWidth: function(a){
            if (this.disabledResize) 
                return this;
            var delta = a - this.width;
            superclass.setWidth.call(this, a);
            var ct = this.parentContainer;
            if (ct) 
                ct.fire('colresize', this, ct.indexOf(this), delta);
            return this;
        },
        
        _setWidth: function(a){
            superclass.setWidth.call(this, a);
        },
        
        /**
         * 创建该列的比较器,比较器创建后存在属性comparator中,用于两列值比较.
         */
        createComparator: function(){
            var converter = this.converter, self = this;
            if (!converter) 
                converter = this.createConverter();
            this.comparator = (function(a1, a2){
                //mark
                var idx = self.columnIdx;
                var v1 = converter(a1.children[idx]), v2 = converter(a2.children[idx]);
                if (v1 > v2) 
                    return 1;
                
                if (v1 < v2) 
                    return -1;
                
                return 0;
            });
        },
        /**
         * 数据类型转换器,创建后存在属性converter中,用于比较器比较两列值.
         *@return {Object} 该列的数据类型转换器
         */
        createConverter: function(){
            var numReg = /[\$,%]/g;
            var datmat = this.dateFormat, cv;
            switch (this.dataType) {
                case "":
                case undefined:
                    cv = function(v){
                        if (v === null || v === undefined) 
                            return v;
                        // for item value
                        return v.toString();
                    };
                    break;
                    
                case "string":
                    cv = function(v){
                        return (v === undefined || v === null) ? '' : v.toString();
                    };
                    break;
                case "int":
                    cv = function(v){
                        return v !== undefined && v !== null && v !== '' ? parseInt(v.toString().replace(numReg, ""), 10) : '';
                    };
                    break;
                case "float":
                    cv = function(v){
                        return v !== undefined && v !== null && v !== '' ? parseFloat(v.toString().replace(numReg, ""), 10) : '';
                    };
                    break;
                    
                case "bool":
                    cv = function(v){
                        return v === true || v === "true" || v == 1;
                    };
                    break;
                case "date":
                    cv = function(v){
                        if (!v) {
                            return '';
                        }
                        if (CC.isDate(v)) {
                            return v;
                        }
                        if (datmat) {
                            if (datmat == "timestamp") {
                                return new Date(v * 1000);
                            }
                            if (datmat == "time") {
                                return new Date(parseInt(v, 10));
                            }
                            return Date.parseDate(v, datmat);
                        }
                        var parsed = Date.parse(v);
                        return parsed ? new Date(parsed) : null;
                    };
                    break;
            }
            this.converter = cv;
            return cv;
        },
        /**
         * 排序该列,表头只是发送一个colsort事件表明要对该行进行排序,自己并没什么实际行动,并在排序后发送colsorted事件.
         * 当列排序后,当前排序方式desc或asc保存在属性sortType中,当前排序列保存在父容器的sortedColumn属性中.
         *@param {string} sortType=desc|asc
         */
        sortColumn: function(sortType){
            if (!this.sortable) 
                return this;
            var ct = this.parentContainer, idx = ct.indexOf(this);
            //内部使用,作标记,该标记只在排序期间有效,使得比较器不必每次询问当前列下标值.
            this.columnIdx = idx;
            
            if (ct.fire('colsort', this, idx, sortType) === false) 
                return this;
            this.sortType = sortType;
            ct.sortedColumn = this;
            
            ct.fire('colsorted', this, idx, sortType);
            return this;
        }
    };
});

CTemplate['CGridHeader'] = '<div class="g-grid-header"><table  id="_hdtbl" class="g-grid-header-tbl" cellspacing="0" cellpadding="0"><tbody><tr id="_hdColHolder"></tr></tbody></table></tbody></table></div>';
/**
 * 表格表头
 * @class CGridHeader
 * @super CPanel
 * @event colswap 表格列置换时发送.
 * @event colresize 表格列缩放时发送. 
 * @property {Boolean} resizing 指示列是否在缩放状态
 * @param {Object} superclass
 */
CC.create('CGridHeader', CPanel, function(superclass){
    //类静态成员
    var hdRzA, hdRzB, maxRz, minRz, initMx, initLeft;
    
    //
    // 如果父容器为自动调整
    //
    
    function onLayout(){
        var ct = this.container;
        var grid = ct.parentContainer;
        if (grid.autoFit) {
			ct.hdWidthAnchor.setWidth(ct.getWidth(true));
			var rsl = 0, k = 0, hdcs = grid.header.children, i, ch;
			//不能变动的
			for (i = 0; i < hdcs.length; i++) {
				ch = hdcs[i];
				if (ch.disabledResize || ch.disabled) {
					rsl += ch.getWidth(true);
					continue;
				}
				k++;
			}
			
			var off = parseInt((grid.header.getWidth(true) - rsl) / k);
			
			for (i = 0; i < hdcs.length; i++) {
				ch = hdcs[i];
				if (ch.disabledResize || ch.disabled) {
					continue;
				}
				ch._setWidth(off);
			}
		}
		//初始时列自动宽度
		else {
			if (ct.hdWidthAnchor.width === false) {
				var f = ct.hdWidthAnchor;
				ct.addClass(ct.autoWidthCS);
				//hack ff
				grid.delClass(grid.noAutoFitCS);
				f.setWidth(ct.getWidth(true));
				var chs = ct.children, c;
				ct._stopSyncHd = true;
				for (var i = 0; i < chs.length; i++) {
					c = chs[i];
					if (c.width === false) {
						c.setWidth(c.getWidth());
					}
				}
				delete ct._stopSyncHd;
				
				ct.delClass(ct.autoWidthCS);
				grid.addClass(grid.noAutoFitCS);
			}
		}
    };
    
    
    return {
    	  defferLayout : false,
        container: '_hdColHolder',
        ItemClass: CColumn,
        template: 'CGridHeader',
        unselectable: true,
        height: 21,
        sortable: true,
		colHoverCS:'g-grid-hd-on',
        resizeSpliterCS: 'g-grid-hd-spliter',
        autoWidthCS: 'g-grid-header-autowidth',
        initComponent: function(){
            this.layout = new CLayout({
                onLayout: onLayout
            });
            superclass.initComponent.call(this);
            var hdtbl = this.hdWidthAnchor = this.$$('_hdtbl');
            hdtbl.view.onmousemove = this.onHDMouseMove.bindAsListener(this);
            hdtbl.view.onmousedown = this.onHDMouseDown.bindAsListener(this);
            if (this.sortable) 
                this.itemAction('click', this.colSortTrigger, false, null, null, 'DIV');
            this.itemAction('mouseover', this.onMouseOver, false, null, null, 'DIV');
            this.itemAction('mouseout', this.onMouseOut, false, null, null, 'DIV');
            
            this.on('colresize', this.onColResized);
        },
		
        /**
         * 处理列宽调整
         * @param {CColumn} col Resized的列
         * @param {Number} idx  列下标
         * @param {Number} dt   Resized的增量
         */
        onColResized: function(col, idx, dt){
            if (dt != 0 && !this._stopSyncHd && this.parentContainer && !this.parentContainer.autoFit) {
                this.hdWidthAnchor.setWidth(this.hdWidthAnchor.getWidth(true) + dt);
            }
        },
        
        onMouseOver: function(item){
            item.addClass(this.colHoverCS);
        },
        
        onMouseOut: function(item){
            item.delClass(this.colHoverCS);
        },
        
        startResizeSpliter: function(col, ev){
            var l = hdRzA, r = hdRzB;
            if (!r) {
                l = hdRzA = CBase.create({
                    view: Cache.get('div'),
                    hidden: true,
                    inherentCS: this.resizeSpliterCS,
                    showTo: document.body,
                    autoRender: true
                });
                r = hdRzB = CBase.create({
                    view: Cache.get('div'),
                    hidden: true,
                    inherentCS: this.resizeSpliterCS,
                    showTo: document.body,
                    autoRender: true
                });
            }
            var g = col.parentContainer.parentContainer, 
			    xy = col.absoluteXY(), 
				colw = col.getWidth(true), 
				startH = CC.borderBox ? col.parentContainer.getHeight(true) : col.parentContainer.getHeight(true) + 1, 
				ctxh = g.wrapper.view.clientHeight;
            
            r.setXY(xy[0] + colw - 1, xy[1]).setHeight(g.wrapper.view.clientHeight + startH - 20).display(true);
            l.setXY(xy[0] - 1, xy[1]).setHeight(r.height).display(true);
            minRz = l.left - r.left + (this.resizerBarLen || 4);
            maxRz = g.autoFit ? this.getMaxResizableAutoFitWidth(col) : Math.MAX_VALUE;
            //初始x坐标
            initMx = Event.pageX(ev);
            //初始长度
            initLeft = r.left;
        },
        /**
         * 在autoFit情况下返回col列最大可扩宽度
         */
        getMaxResizableAutoFitWidth: function(col, idx){
            if (col.disabledResize) 
                return 0;
			if(idx === undefined)
				idx = this.indexOf(col);
            var len = 0;
			var its = this.children;
			var sz = its.length;
			//计算接下来列宽和
			for(++idx;idx<sz;idx++){
				col = its[idx];
				if (col.disabledResize || col.disabled)
					continue;
				len += col.getWidth(true) - col.minW; 
			}
            return len;
        },
        
        endResizeSpliter: function(col){
            hdRzA.display(0);
            hdRzB.display(0);
        },
        
        onHDMouseMove: function(ev){
            var el = CC.tagUp(ev.target || ev.srcElement, 'TD');
            var st = el.style;
            if (this.disabledResize || this.resizing || CGhost.instance.draging) {
                if (st.cursor != '') 
                    st.cursor = "";
                return;
            }
            var col = this.$(el);
            if (!col || col.disabledResize || col.disabled) {
                if (st.cursor != '') 
                    st.cursor = "";
                return;
            }
            
            var px = el.offsetWidth - Event.pageX(ev) + col.absoluteXY()[0];
            if (px < (this.resizerBarLen || 10)) {
                st.cursor = "col-resize";
            }
            
            else 
                if (st.cursor != '') 
                    st.cursor = "";
        },
        
        onHDMouseDown: function(ev){
            var el = CC.tagUp(ev.target || ev.srcElement, 'TD');
            var col = this.$(el);
            if (!col) 
                return;
            if (el.style.cursor != 'col-resize' || col.disabledResize) 
                return;
            this.resizing = true;
            var self = this;
            this.startResizeSpliter(col, ev);
            CC.$body.domEvent('mouseup', this.onHDMouseUp, true, col);
            CC.$body.domEvent('mousemove', this.onHDResize, true, this);
            this.fire('colresizestart', col, this.indexOf(col));
        },
        
        //col === this
		/**
		 * 列宽变动时.
		 * @param {Object} event
		 */
        onHDResize: function(event){
            //this为header
            var pace = Event.pageX(event) - initMx;
            if (pace < 0 && pace < minRz) {
                pace = minRz
            }
            else 
                if (pace > maxRz) {
                    pace = maxRz;
                }
            hdRzB.setLeft(initLeft + pace);
        },
        
        onHDMouseUp: function(event){
            //当前this为resize列
            var ct = this.parentContainer;
            ct.endResizeSpliter();
            CC.$body.unDomEvent('mouseup', ct.onHDMouseUp);
            CC.$body.unDomEvent('mousemove', ct.onHDResize);
			var dx = hdRzB.left - initLeft;
            if (dx != 0) {
				this.setWidth(this.width + dx);
			}
            ct.fire('colresizeend', this, ct.indexOf(this));
            ct.resizing = false;
        },
        
        destoryComponent: function(){
            //fix when resizing but in destorying.
            if (this.resizing) {
                CC.$body.unDomEvent('mouseup', this.onHDMouseUp);
                CC.$body.unDomEvent('mousemove', this.onHDResize);
            }
            superclass.destoryComponent.call(this);
        },
        
        colSortTrigger: function(item, evt){
            if (item.style('cursor') != 'col-resize') {
                var t = (item.sortType == 'desc') ? 'asc' : 'desc';
                item.sortColumn(t);
            }
        }
    };
});

CC.create('CGridCell', CBase, function(superclass){
    Cache.register('CGridCell', function(){
        var td = CC.$C({
            tagName: 'TD'
        });
        td.appendChild(CC.$C({
            tagName: 'DIV',
            className: 'rowcell',
            id: '_tle'
        }));
        return td;
    });
	
    return {
        initComponent: function(){
            this.view = Cache.get('CGridCell');
            superclass.initComponent.call(this);
        },

        destoryComponent: function(){
            var c = this.view.firstChild;
            superclass.destoryComponent.call(this);
            c.innerHTML = '';
            c.className = '';
            Cache.put('CGridCell', this.view);
        }
    };
});

CC.create('CGridRow', CContainerBase, function(superclass){
    Cache.register('CGridRow', function(){
        return CC.$C({
            tagName: 'TR',
            className: 'g-grid-row'
        });
    });
	
    var rowLayout = {
		doLayout : function(){
		   var i = 0, ch, chs = this.container.children, len = chs.length;
		   for (; i < len; i++) {
		       ch = chs[i];
		       if (!ch.rendered) {
				ch.render();
			   }
		   }
	    },
		
		//因为没必要，所以置为空调用
		addComponent : fGo,
		removeComponent : fGo,
		displayItem : fGo,
		insertComponent:fGo
	};
		
    return {
        eventable: false,
        ItemClass: CGridCell,
        hoverCS: 'g-row-over',
        initComponent: function(){
            if(!this.layout)
				this.layout = new CLayout['default'](rowLayout);
            this.view = Cache.get('CGridRow');
            superclass.initComponent.call(this);
        },
        
        onMouseOver: function(ev){
            this.parentContainer.onRowOver(this, ev);
        },
        
        onMouseOut: function(item, ev){
            this.parentContainer.onRowOut(this, ev);
        }
    };
});

/**
 * CGridView不具备管理自身布局能力,让唯一能做的事就是提供方法让别人管理
 */
CTemplate['CGridView'] = '<div class="g-gridview"><table class="g-gridview-tbl" id="_gridviewtbl" cellspacing="0" cellpadding="0"><tbody id="_ctx"></tbody></table></div>';
CC.create('CGridView', CContainerBase, function(superclass){

    //布局使得表格每行列与表头列对齐
    function layoutRow(row){
        var hd = this.container.parentContainer.header, i = 0, chs = hd.children, len = chs.length;
        for (; i < len; i++) {
            row.children[i].setWidth(chs[i].getWidth(true));
        }
    }
    
    function onLayout(){
    	this.container.view.style.display = 'none';
    	CLayout.prototype.onLayout.call(this);
    	this.container.view.style.display = '';
    }
    
    return {
    
        ItemClass: CGridRow,
        
        container: '_ctx',
                
        type: 'CGridView',
        
        useContainerMonitor: true,
        
        initComponent: function(){
            this.layout = new CLayout({
                layoutChild: layoutRow,
                onLayout : onLayout,
                defferLayout : 0
            });
            superclass.initComponent.call(this);
            this.itemAction('mousedown', this._containerSelectTrigger, false, null, '_gridviewtbl');
            this.itemAction('dblclick', this.onRowDBClick, false, null, '_gridviewtbl');
            this.tableNode = this.dom('_gridviewtbl');
        },
        
        onRowOver: fGo,
        
        onRowOut: fGo,
        
        onRowDBClick: function(item, event){
            var cell = item.$(event.target || event.srcElement);
            if (cell) {
                this.parentContainer.fire('celldbclick', cell);
            }
            this.parentContainer.fire('rowdbclick', item);
        },
        
        _containerSelectTrigger: function(item, event){
            if (this.selectedCS) 
                item.hasClass(this.selectedCS) ? item.delClass(this.selectedCS) : item.addClass(this.selectedCS);
            var cell = item.$(event.target || event.srcElement);
            if (cell) {
                this.parentContainer.fire('cellclick', cell);
            }
            this.parentContainer.fire('rowclick', item);
        },
        
        swapColumn: function(idx1, idx2){
            var cells = this.children;
            for (var i = 0, len = cells.length; i < len; i++) {
                cells[i].swap(idx1, idx2);
            }
        },
        
        
        setCellWidth: function(idx, w){
            var chs = this.children, len = chs.length, i = 0;
            for (; i < len; i++) {
                chs[i].children[idx].setWidth(w);
            }
        }
    };
});


CC.create('CGrid', CSelectedPanel, function(superclass){
    //
    function layoutView(v){
        var ct = this.container, w = ct.header.hdWidthAnchor.width;
        //表头锚宽对齐
        v.setWidth(w);
		    CC.fly(v.tableNode).setWidth(w).unfly();
        v.doLayout.bind(v).timeout(0);
    }
    
    function onLayout(){
        var ct = this.container;
        if (ct.height !== false) 
            ct.wrapper.setHeight(ct.getHeight(true) - ct.header.getHeight(true));
        ct.header.setWidth(ct.getWidth(true));
        CLayout.prototype.onLayout.call(this);
    }
    
    return {
        container: '_grid_ctx',
        
        ascCS: 'g-col-asc',
        
        descCS: 'g-col-desc',
        
		noAutoFitCS : 'g-grid-noautofit',
		
        navKeyEvent: true,
		
		autoFit : true,
        
        initComponent: function(){
            if (!this.layout) 
                this.layout = new CLayout({
                    layoutChild: layoutView,
                    onLayout: onLayout
                });
            
            superclass.initComponent.call(this);
            if (CC.isArray(this.header)) {
                this.header = new CGridHeader({
                    showTo: this.dom('_hdctx'),
                    array: this.header
                });
            }
            
            this.header.on('colresize', this.onColumnResize, this);
            this.header.on('colsort', this.onColumnSort, this);
            this.header.on('colswap', this.onColumnSwap, this);
            this.domEvent('scroll', this.onContainerScroll, false, null, this.container);
            this.follow(this.header);
            this.setAutoFit(this.autoFit);
            
            this.endNode = this.dom('_g_end');
        },
        
        _addNode: function(viewNode){
            if (this.endNode) 
                this.container.insertBefore(viewNode, this.endNode);
            else 
                superclass._addNode.call(this, viewNode);
        },
        
        setAutoFit: function(b){
            this.autoFit = b;
			!b? this.addClass(this.noAutoFitCS) : this.delClass(this.noAutoFitCS);
            if (this.rendered) 
                this.doLayout();
        },
        
        onContainerScroll: function(evt){
            this.header.view.scrollLeft = this.container.scrollLeft;
        },
        
        onColumnSwap: function(colA, colB, idxA, idxB){
            //swap header
            this.header.swap(idxA, idxB);
            //swap grid views
            this.each(function(){
                this.swapColumn(idxA, idxB);
            });
        },
        
        /**
         * 实际对列排序的方法.
         */
        onColumnSort: function(col, idx, sortType){
            //
            if (!col.comparator) 
                col.createComparator();
            //切换排序样式
            if (sortType == 'desc') 
                col.switchClass(this.ascCS, this.descCS);
            else 
                col.switchClass(this.descCS, this.ascCS);
            var ct = col.parentContainer;
            if (ct.sortedColumn && ct.sortedColumn != col) 
                ct.sortedColumn.delClass(this.ascCS).delClass(this.descCS);
            
            //第一次排序?
            var bs = idx === this.currSortedIdx;
            //排序数据视图
            this.each(function(){
                if (!bs) 
                    this.sort(col.comparator);
                else 
                    this.reverse();
            });
            this.currSortedIdx = idx;
        },
        
        onColumnResize: function(col, idx){
            if (this.autoFit) {
                //避免再次被布局
                col.disabledResize = true;
                this.header.doLayout();
                this.doLayout();
                col.disabledResize = false;
            }
            else {
                var w = col.getWidth(true);
				var ly = this.layout;
                this.each(function(){
                    this.setCellWidth(idx, w);
					ly.layoutChild(this);
                });
            }
        },
        
        selectNext: function(){
        
        },
        
        selectPre: function(){
        
        }
    };
});


//gridgroupview.js
CC.create('CGridGroupView', CGridView, function(father) {
  return {
    
    template: 'CGridView',
    
    initComponent: function() {
      father.initComponent.call(this);
      this.foldbar = new CFoldable({target:this, foldNode:this.container.parentNode, nodeBlockMode:''});
      this.view.insertBefore(this.foldbar.view, this.view.firstChild);
    },
    
    render: function() {
      father.render.call(this);
      this.foldbar.setTitle(this.title);
    },
    
    destoryComponent:function(){
    	this.foldbar.destoryComponent();
    	father.destoryComponent.call(this);
    }
  };
});
//propertygird.js
CC.create('CPropertyRow', CGridRow, function(superclass){
	return {
		eventable:true,
		
		initComponent:function(){
			superclass.initComponent.call(this);
			var kCol = new CGridCell({title:this.key, tip:this.tip});
			var kVal = new CGridCell({title:this.value});
			//kVal.append(this.editor);
			this.add(kCol).add(kVal);
		},
		
		destoryComponent : function(){
			superclass.destoryComponent.call(this);
			//this.editor.destoryComponent();
		}
	};
});



CC.create('PropertyGrid', CGrid, function(superclass){
	function onSplitEnd(){
		var col = this.parentContainer.header.$(0);
		col.setWidth(col.getWidth(true)+this.splitDX);
	}
	
	return {
		template : 'CGrid',
		separatorCS : 'g-prpty-sp',
		initComponent : function(){
			superclass.initComponent.call(this);
			this.spliter = new CSpliter({container:this.container,parentContainer:this, disableTB:true,onSplitEnd:onSplitEnd});
			this.spliter.addClass(this.separatorCS);
			this.follow(this.spliter);
			this.header.on('colresizeend', this.fixSpliter, this);
			//hide the spliter when collapsed.
			CC.fly(this.container).style('overflow','hidden');
		},
		
		onResized : function(a, b, c, d){
			superclass.onResized.call(this, a, b, c, d);
			this.fixSpliter();
		},
		
		fixSpliter : function(){
			var sp = this.spliter;
			sp.setHeight(this.getHeight());
			sp.setLeft(this.header.children[0].getWidth(true)-Math.floor(sp.getWidth()/2));
		},
		
		onRender : function() {
			superclass.onRender.call(this);
			if(this.hideHeader)
				this.header.display(false);
			this.fixSpliter();
		}
	};
});
//msgbox.js
/**
 * @property
 * @template
 */
CTemplate['CUtil.alert.input'] = '<div class="msgbox-input"><table class="swTb"><tbody><tr><td valign="top"><b class="icoIfo" id="_ico"></b></td><td><span id="_msg" class="swTit"></span>&nbsp;<input type="text" style="" class="gIpt" id="_input"/><p class="swEroMsg"><span id="_err"></span></p></span></td></tr></tbody></table></div>';
CC.extendIf(CUtil, (function(){
	/**
	 * 根据对话框类型过滤按钮
	 * 当前this为过滤字符串
	 * @function
	 * @private
	 * @see CContainerBase#filter
	 */
	function buttonMatcher(item){
		return this.indexOf(item.id)>=0;
	}
	
return {
	/**
	 * 系统对话框引用,如果要获得系统对话框,请用CUtil.getSystemWin方法.
	 * @private
	 * @see CUtil#getSystemWin
	 */
	_sysWin : null,
	/**
	 * 返回系统全局唯一对话框.
	 * 该对话框为系统消息窗口.
	 * @function
	 * @return {CDialog} 系统对话框
	 */
  getSystemWin: function() {
    var w = this._sysWin;
    if (!w) {
      w = this._sysWin = new CDialog({
        id: 'sysWin',
        //@override 无状态控制
        setState: fGo,
        cs: 'sysWin bot',
        resizeable: false,
        width: 400,
        hidden: true,
        autoRender: true,
        navKeyEvent : true,
        showTo: document.body,
        //@override 不受窗口zIndex管理
        setZ: fGo,
        //对话框默认按钮
				buttons : [
					{title: '取&nbsp;消',     id :'cancel'}, 
          {title: '确&nbsp;定',     id :'ok'},
        	{title: '&nbsp;否&nbsp;', id :'no'},
        	{title: '&nbsp;是&nbsp;', id :'yes'},
        	{title: '关&nbsp;闭',     id :'close'}
        ]
      });
      /**
       * 得到inputBox中input元素
       * @function
       * @return {Element} inputBox中input元素
       */
      w.getInputEl  = (function(){
      	return this.wrapper.dom('_input');
      });
    }
    return w;
  },

  /**
   * 弹出对话框.
   * @function
   * @param {String} msg 消息
   * @param {String} 标题
   * @param {String} 显示按钮ID,用|号分隔,如ok|cancel|yes|no
   * @param {Function} callback 当对话框返回时回调
   * @param {CWin} modalParent 父窗口,默认为document.body层
   * @defButton {String} 聚焦按钮ID,默认为 'ok'
   */
  alert: function(msg, title, callback, buttons, modalParent, defButton) {
    title = title || '提示';
    var s = this.getSystemWin();
    s.setTitle(title)
     .setSize(400, 153)
     .wrapper.html('<div class="msgbox-dlg">' + (msg||'') + '</div>');
    
    if(!buttons){
    	buttons = 'ok';
    	defButton = 'ok';
    }
    
    s.bottomer.filter(buttonMatcher, buttons);
    
    if(defButton)
    	s.defaultButton = defButton;
    
    s.show(modalParent||document.body, true, callback);
  },

  /**
   * 弹出输入对话框.
   * @function
   * @param {String} msg 消息
   * @param {String} 标题
   * @param {String} 显示按钮ID,用|号分隔,如ok|cancel|yes|no,默认为ok|cancel
   * @param {Function} callback 当对话框返回时回调
   * @param {CWin} modalParent 父窗口,默认为document.body层
   * @defButton {String} 聚焦按钮ID,默认为 'ok'
   */
  inputBox: function(msg, title, callback, buttons, modalParent, defButton) {
    title = title || '提示';
    var s = this.getSystemWin();
    s.setTitle(title)
     .setSize(400, 175)
     .wrapper.html(CTemplate['CUtil.alert.input'])
     .dom('_msg').innerHTML = msg;
    
    var ipt = s.wrapper.dom('_input');
        
    if(!buttons){
    	buttons = 'ok|cancel';
    	defButton = 'ok';
    }
    
    s.bottomer.filter(buttonMatcher, buttons);
    
    if(defButton)
    	s.defaultButton = defButton;
    
    s.show(modalParent||document.body, true, callback);
    (function(){s.getInputEl().focus();}).timeout(0);
  }
};
})());
//combo.js
//控件HTML模板
CTemplate['CCombox'] = '<div class="g-panel g-combo"><div class="g-panel-wrap g-combo-wrap" id="_wrap"><div class="unedit-txt" id="_uetxt" tabindex="1" hidefocus="on"></div><span class="downIco bgF1" id="_trigger"></span></div></div>';

/**
 * 继承CFormElement类
 */
CC.create('CCombox', CFormElement, function(superclass) {

  return {
    hoverCS: 'g-combo-on',
    uneditCS: 'g-combo-unedit',
    downCS: 'g-combo-dwn',
    
    initComponent: function() {
      var array = CC.delAttr(this, 'array');
      this.editor = new CText({name: this.name});
      this.element = this.editor.element;
      
      //调用父类初始化
      superclass.initComponent.call(this);

      this.uneditNode = this.dom('_uetxt');

      this.dom('_wrap').insertBefore(this.editor.view, null);

      var st = this.selector;
      if (!st) {
        st = this.selector = CUtil.createFolder({
          showTo: document.body,
          shadow: true
        });
        //hack:
        st.shadow.setZ(999);
        this.follow(st);
      }

      st.display(false);
      
      if (array) 
       st.fromArray(array);
      
      //bind scrolor
      st.scrollor = st.dom('_scrollor');
      
      this.attach(st);
      this._bindKey();
      
   		if(this.uneditable){
   			delete this.uneditable;
   			this.setEditable(false);
   		}else
   			this.setEditable(true);

      if (this.selected) 
       st.select(selected);
    },

    disable: function(b) {
      superclass.disable.call(this, b);
      this.editor.disable(b);
    },
    
    setScrollorHeight : function(h){
    	this.selector.fly('_scrollor').setHeight(h).unfly();
    },
    
    setEditable: function(b) {
    	if(this.uneditable !== undefined && this.uneditable == b)
    		return this;
    	
    	if(this.uneditable && b){
    		this.delClass(this.uneditCS);
        this.unDomEvent('click', this.onUneditableClick);
        this.unDomEvent('keydown', this._keyHandler, this.uneditNode);
    	}else if(b){
    		this.domEvent('click', this.onUneditableClick, true, null, '_trigger');
    	}else {
        this.addClass(this.uneditCS);
        this.domEvent('click', this.onUneditableClick);
        this.domEvent('keydown', this._keyHandler, false, null, this.uneditNode);
        this.unDomEvent('click', this.onUneditableClick, '_trigger');        
      }
      
      this.uneditable = !b;
      return this;
    },

    onUneditableClick: function(evt) {
      var b = !this.selector.hidden;
      this.showBox(!b);
    },

    attach: function(selector) {
      if (this.selector) this.detach();
      this.selector = selector;
      selector.addClass(this.selectorCS || 'g-combo-list');
      selector.on('selected', this.onSelected, this);
      selector.on('itemclick', this.onItemClick, this);
      this._savSelKeyHdr = selector._defKeyNav;
      var self = this;
      selector._defKeyNav = (function(ev) {
        self._keyHandler(ev, true);
      });
    },

    onBoxContexted: function(evt) {
      var el = Event.element(evt);
      if (this.ancestorOf(el)) return false;
      this.showBox(false, true);
    },

    onItemClick: function() {
      this.showBox(false);
    },

    detach: function() {
      var se = this.selector;
      this.selector = null;
      se.delClass(this.selectorCS || 'g-combo-list');
      se.un('selected', this.onSelected);
      se.un('itemclick', se.hide);
      se._defKeyNav = this._savSelKeyHdr;
      delete this._savSelKeyHdr;
    },

    _keyHandler: function(ev, isSelectorEv) {
      var kc = ev.keyCode;
      if (kc == 27 || kc == 13) {
        this.showBox(false);
        return;
      }
      //handle to selector.
      if (!isSelectorEv) {
        var s = this.selector;
        s.onKeyPressing(ev);
      }
    },

    _filtHandler: function(ev) {
      var kc = ev.keyCode;
      var s = this.selector;
      if (kc == s.KEY_UP || kc == s.KEY_DOWN || this.noFilt || kc == 27 || kc == 13) return;

      var v = this.editor.element.value;
      if (v == '') {
        s.select(null);
      }

      if (v != this.preValue) {
        s.filter(this.matcher, this);
        this.preValue = v;
      }

      this.showBox(true);
    },

    showBox: function(b, leaveFocus) {
      var s = this.selector;
      var ds = !s.hidden;
      if (b.type) b = !ds;
      if (!b) {
        s.display(false);
        if(!leaveFocus){
        	if(!this.uneditable)
        		this.editor.focus(true);
        	else
        		this.uneditNode.focus(true);
        }
        this.delClass(this.downCS);
        return;
      }

      this.preferPosition();
      if (this.selector.shadow) 
      	this.selector.shadow.reanchor();
      if (!this.uneditable) 
      	this.editor.focus(true);
      else this.uneditNode.focus(true);
      
      if (ds) return;

      this.selector.fire('comboxshow', this);
      this._checkSelected();
      this.addClass(this.downCS);
      s.bindContext(this.onBoxContexted, false, this).display(true);
    },

    _checkSelected: function() {
      var s = this.selector;
      var v = this.editor.value;
      if (!s.selected) return;

      if (v) return;

      if (s.selected.title != v) {
        s.select(null);
        return;
      }

      s.each(function(it) {
        if (it.title == this) {
          it.parentContainer.select(it);
          return false;
        }
      },
      v);
    },

    /**
	 * 定位选择容器位置
	 */
    preferPosition: function() {
      var s = this.selector;
      var off = this.absoluteXY();
      s.setXY(off[0], off[1] + this.getHeight());
      if (!this.noAutoWidth) s.setWidth(this.getPreferWidth());
    },

    /**
	 * 返回最佳宽度,重写该函数自定下拉选择容器的宽度
	 * 默认返回combox的宽度
	 */
    getPreferWidth: function() {
      return this.getWidth();
    },

    _bindKey: function(event) {
      this.domEvent('keydown', this._keyHandler, false, null, this.editor.view);
      this.domEvent('keyup', this._filtHandler, false, null, this.editor.view);
    },

    onSelected: function(item) {
      this.editor.setValue(item.title);
      if (!this.uneditable) this.editor.focus(true);
      else this.uneditNode.innerHTML = item.title;
    },

    /**
	 * 自定过滤重写该函数即可.
	 */
    matcher: function(item) {
      var tle = item.title;
      var v = this.editor.element.value;
      if (v == '') {
        item.setTitle(item.title);
        return true;
      }

      if (tle.indexOf(v) >= 0) {
        //item.addClass('g-match');
        item.dom('_tle').innerHTML = tle.replace(v, '<span class="g-match">' + v + '</span>');
        return true;
      }
      item.setTitle(item.title);
      return false;
    },

    select: function(id) {
      this.selector.select(id);
    }
  };
});
CFormElement['combo'] = CCombox;

//tips.js
/**
 * 浮动提示框.
 */

if(!CC.ie)
  CTemplate['CFloatTip'] = '<div class="g-float-tip g-clear"><div class="tipbdy"><div id="_tle" class="important_txt"></div><div id="_msg" class="important_subtxt"></div></div><div class="btm_cap" id="_cap"></div></div>';
else 
	CTemplate['CFloatTip'] = '<table class="g-float-tip g-clear"><tr><td><table class="tipbdy"><tr><td id="_tle" class="important_txt"></td></tr><tr><td id="_msg" class="important_subtxt"></td></tr></table></td></tr><tr><td class="btm_cap" id="_cap"></td></tr></table>';
CC.create('CFloatTip', CPanel,function(superclass){

var instance;
var globalPos = [-10000,-10000];
var docEvtBinded = false;

function onDocMousemove(event){
	globalPos = Event.pageXY(event || window.event);
}

CUtil.ftip = function(msg, title, proxy, getFocus, timeout){
	if(!instance)
		instance = new CFloatTip({showTo:document.body, autoRender:true});
	CC.fly(instance.tail).show().unfly();
	instance.show(msg, title, proxy, getFocus, timeout);
	
	return instance;
};
  
CUtil.qtip = function(proxy, msg){
	if(!instance)
		instance = new CFloatTip({showTo:document.body, autoRender:true});
	instance.tipFor(proxy, msg);
};

return {
  /**
   *@cfg {Number} timeout = 2500 设置消失超时ms, 如果为0 或 false 不自动关闭.
   */
  timeout: 2500,
	
	delay : 500,
	
	type : "CFloatTip",
	
	template : 'CFloatTip',
	/**
	 *@cfg {Boolean} reuseable = false 是否可复用
	 */
	reuseable : true,
	
	shadow:true,
  
  qmode : false,
  
  zIndex : 10002,
  
  hoverTipCS : 'g-small-tip',
  
  initComponent: function() {
    CPanel.prototype.initComponent.call(this);
    if(this.msg)
    	this.setMsg(this.msg);
    this.tail = this.dom('_cap');
    this.setXY(-10000,-10000).setZ(this.zIndex);
    if(this.qmode)
    	this._returnQtip();
    else this._returnFtip();
  }
  ,	
  
  //@override
  display : function(b) {
    if(arguments.length == 0){
    	return CPanel.prototype.display.call(this);
    }

    //无论怎样,先清除前面一个timout
    this.killTimer();

    CPanel.prototype.display.call(this, b);
    
    if(!b)
    	return this;
    
    if(this.timeout)
    	this.timerId = this._timeoutCall.bind(this).timeout(this.timeout);
    return this;
  }
  ,
  
  setRightPosForTarget : function(target){
  	var f = CC.fly(target);
	    var xy = CC.fly(target).absoluteXY();
	    this.setXY(xy[0] - 2, xy[1] - this.view.offsetHeight - 2);
	  f.unfly();
  },
  
  setRightPosForHover : function(xy){
  	this.setXY(xy[0], xy[1] + 24);
  },
  
  _timeoutCall : function(){
  	CPanel.prototype.display.call(this, false);
  	this.killTimer(true);
  	if(this.ontimeout)
  		this.ontimeout();
  },
  
  /**
   * @param {boolean} check 是否作回收(reuseable)检查
   */
  killTimer : function(check){
    if(this.timerId){
    		clearTimeout(this.timerId);
    		this.timerId = false;
    }
    
    if(!this.reuseable && check)
  		this.destoryComponent();
  },
  
  setMsg: function(msg, title) {
  	this.fly('_msg').html(msg).unfly();
    if(title)
    	this.setTitle(title);
    return this;
  },
  
  /**
   * @override
   * @param {Mixed} target
   */
  show : function(msg, title, target, getFocus, timeout){
  	if(arguments.length == 0)
  		return CPanel.prototype.show.call(this);
  		
  	this.setMsg(msg, title);
  	
  	if(timeout !== undefined)
  		this.timeout = timeout;
  	
  	if(this.qmode)
  		this._returnFtip();
  	
  	this.display(true);
  	if(target){
    	this.setRightPosForTarget(target);
    	if(getFocus)
  			CC.fly(target).focus(true).unfly();
    }
  	return this;
  },
  
  _returnFtip : function(){
  	this.qmode = false;
    this.delClass(this.hoverTipCS);
  	if(this.shadow){
  		this.shadow.inpactY = -1;
  		this.shadow.inpactH = -12;
  	}
  },
  
  _returnQtip : function(){
  	this.qmode = true;
    this.addClassIf(this.hoverTipCS);
  	if(this.shadow){
  		this.shadow.inpactY = CShadow.prototype.inpactY;
  		this.shadow.inpactH = CShadow.prototype.inpactH;
  	}
  },
  
  tipFor : function(proxy, msg, title){
  	CC.fly(proxy)
  	  .domEvent('mouseover', 
  	    function(evt){
  	    	var self = this;
					if(!docEvtBinded){
						Event.addListener(document, 'mousemove', onDocMousemove);
						docEvtBinded = true;
					}
					
					this.timerId = (function(){
						self.setMsg(proxy.qtip || proxy.tip || proxy.title || msg, title);
						CC.fly(self.tail).hide().unfly();
  	    		if(!self.qmode)
  	    			self._returnQtip();
  	    		self.display(true)
  	    		    .setRightPosForHover(globalPos);
					}).timeout(this.delay);
					
  	  	}, true, this)
  	  .domEvent('mouseout', this.onTargetMouseout, true, this)
  	  .unfly();
  },
	
	onTargetMouseout : function(evt){
		if(this.qmode)
		   this.display(false);
		if(docEvtBinded){
			Event.removeListener(document, 'mousemove', onDocMousemove);
			docEvtBinded = false;
		}
	},
	
  getInstance : function(){
  	return instance;
  }
};
});