CC.create('AttributeBase', null, function(){	 
 return {
		initialize : function(cfg){
			CC.extend(this, cfg);
		},
		
		key: 'id',
		
		get : function(c) {
			return c[this.key]||'';
		},
		
		set : function(c, v){
			if(!c['set'+this.key.upperFirst()])
				c[this.key] = v;
			else c['set'+this.key.upperFirst()](v);
		},
		
		getCfgStr : function(c){
			var s= this.key+':'+'"'+c[this.key].toString().escapeQuote('"')+'"';
			console.debug(s);
			return s;
		},
		
		getScript : function(varName, c){
			if(!c['set'+this.key.upperFirst()])
				s= varName+'.set'+this.key.upperFirst()+'("'+c[this.key].toString().escapeQuote('"')+'");';
			else s = varName+'.'+this.key+'="'+c[this.key].toString().escapeQuote('"')+'";';
			return s;
		},
		
		activeEditor : function(c){
			if(!this.editor){
				this.createEditor();
				this.editor.display(false).render();
				this.vsRow.follow(this.editor);
			}
			if(!this.editor.display()){
				this.vsRow.valueCell.setTitle('');
				this.editor.appendTo(this.vsRow.valueCell.dom('_tle'));
				this.editor.setValue(this.get(c));
				this.editor.display(true).focus(0);
			}
		},
		
		applyComponent : function(c){
			this.vsRow.valueCell.setTitle(this.get(c));
		},
		
		createEditor : function(){
			this.editor = new CText();
			this.editor.domEvent('blur', this.onEditorBlur, true, this, this.editor.element);
			this.editor.bindEnter(this.onEditorBlur, true, this, this.editor.element);
		},
		
		onEditorBlur : function(){
			console.debug('blur', this.editor);
			var comp = IDE.getBindingComponent();
			this.editor.display(false).del();
			var v = this.editor.element.value;
			this.set(comp, v);
			this.vsRow.valueCell.setTitle(this.get(comp));
			if(!this.vsRow.hasClass('row-mdy'))
				this.vsRow.addClass('row-mdy');
		}
 };
});

var cfg_CBase = {
attrs : 
{
	id : {key:'id'},	
	title: {key:'title'}
},

vsAttr : {
	resizeable : false,
	enableH:false,
	enableW:false,
	attrCls : AttributeBase
}

};

CC.create('VSAttributeBase', null, function(){
	return {
		initialize : function(cfg){
			CC.extend(this, cfg);
		},
		
		resizeable : true,
		enableH:true,
		enableW:true,
		attrCls : AttributeBase,
	  dragVsCompOut : fGo,
	  
	  getInstance : function(){
	  	CUtil.startMode();
	  	var ins =  this.onInstance.apply(this, arguments);
	  	CUtil.endMode();
	  	return ins;
	  },
	  
	  onInstance : fGo,
		
		applyItem : fGo,
		
		dragVsCompOver : function(){
			return false;
		}
	};
});

CC.create('VSContainerAttributeBase', VSAttributeBase, {
	resizeable : true,
	enableH:true,
	enableW:true,
		
	applyItem : function(item, ctx){
		if(ctx.layout){
			var lycfg = item.layoutCfg;
			if(lycfg)
				lycfg = lycfg[ctx.layout.type];
			ctx.add(item, lycfg);
		}else{
			ctx.add(item);
		}
		
		VS.fire('vs_client_add_comp', item, ctx);
		
	},
		dragVsCompOver : function(){
			return true;
		}
});


var cfg_CWin = {
	
	vsAttr : new VSContainerAttributeBase({
		onInstance : function(){
			return new CWin({title:'样式窗口', shadow:false, anchorable:true});
	  }
	})
};

var cfg_CText = {
	vsAttr : new VSAttributeBase({
		resizeable:true,
	  enableW : true,
		getInstance : function(ctx, ctxCfg){
			var self = this;
			(function(){
			CUtil.inputBox('输入布局:', '文本框设置', 
				function(v){
					var inst = VSAttributeBase.prototype.getInstance.call(self,ctx, ctxCfg);
					inst.setValue(v);
					ctxCfg.vsAttr.applyItem(inst, ctx);
					CUtil.getAnchorBox().anchorTo(inst);
				}
			);
		}).timeout(20);
		return false;
	 },
	  
	  onInstance : function(){
	  	return new CText({value:'样例文本框', anchorable:true});
	  }
	})
};

var cfg_CPanel = {
	vsAttr : new VSContainerAttributeBase()
};

(function(){
IDE.registerComponentCfg('CBase',cfg_CBase);

IDE.registerComponentCfg('CWin',cfg_CWin);

IDE.registerComponentCfg('CText',cfg_CText);

IDE.registerComponentCfg('CPanel',cfg_CPanel);

//
// 增加中间面板主界面
//
IDE.registerPlugin('addComponentFolder', (function(fd){
	fd.root.fromArray([
	{title:'窗口', ctype:'CWin'},
	{title:'文本框', ctype:'CText'}
	]);
}));
})();