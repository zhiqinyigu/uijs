//Default Framework Plugins

//Tab Plugins
IDE.registerPlugin('addNorthPanel', (function(northPanel){
		this.tab = new CTab({cs:'fr-tab'});
		northPanel.add(this.tab);
		this.fire('addTab', this.tab);
}));

IDE.registerPlugin('addCenterPanel', (function(centerPanel){
	centerPanel.domEvent('click', function(evt){
		//如果点击面板空白区，取消anchorBox的定闪控件
		if(Event.element(evt) == this.view){
			CUtil.getAnchorBox().anchorTo(null);
		}
	});
	
			//
		//
		//
		centerPanel.SBDrop = function(item){
	  	var ctype = item.ctype;
	  	var cfg = IDE.getCompConfig(ctype);
	  	var vsCfg = cfg.vsAttr;
	  	var instance = vsCfg.getInstance(this, IDE.getCompConfig(this.type));
	  	if(instance !== false){
	  		this.add(instance);
	  	}
		};
		
		centerPanel.dragSBOver = function(ddrEl){
			return ddrEl.ctype !== undefined;
		}
}));

//Left Folder UI Plugins
IDE.registerPlugin('addWestPanel', (function(westPanel){
	  var G = CGhost.instance, anchorBox = CUtil.getAnchorBox();
	  var ComponentTreeItem = CC.create(CTreeItem, {
	  	draggable:true,
	  	type : 'ComponentTreeItem',
	  	icon:'iconEdit',
	  	dragStart : function(){
	  		G.enableTip = true;
	  		G.setTitle(this.title);
	  		G.setIcon(this.icon);
	  	},
	  	
	  	beforeDragStart : function(){
	  		anchorBox.fire('beforeVsCompDragStart', this);
	  	},
	  	
			/**
			 * 拖曳控件位于设计控件中的上空时通过anchorBox
			 */
			dragOverSB : function(c, evt){
				if(c.__vsComp)
					return anchorBox.fire('dragVsCompOver', this, c, evt);
				if(c == anchorBox)
					return anchorBox.fire('dragVsCompOver', this, c.anchorComp, evt);
				if(c == VS.centerPanel)
					return true;
				return false;
			},
		
			dragOutSB : function(c, evt){
				if(c.__vsComp)
					return anchorBox.fire('dragVsCompOut', this, c, evt);
				
				if(c == anchorBox)
					return anchorBox.fire('dragVsCompOut', this, c.anchorComp, evt);
				return false;
			},
			
			drag : function(){
				//anchorBox.dragVsComp(this);
			},
			
			dropSB : function(sb, evt){
				if(!CGhost.instance.acceptable || !sb)
					return;
				if(sb.__vsComp)
					return anchorBox.fire('applyVsComp', this, sb, evt);
				
				if(sb == anchorBox)
					return anchorBox.fire('applyVsComp', this, sb.anchorComp, evt);
								
				return anchorBox.fire('dropVsComp', this, sb, evt);
			},
			
	    afterDrop:function(evt){
	    	anchorBox.fire('afterDropVsComp', this, evt);
	    }
    
	  });
	  
	  
	  ComponentTreeItem.prototype.ItemClass = ComponentTreeItem;
		
		this.folderPanel = new CTitlePanel({title:'所有组件', height:265});
		this.componentFolder = new CTree({title:'Viewport', scrollor:this.folderPanel});
		
		this.componentFolder.root.ItemClass = ComponentTreeItem;
		this.componentFolder.root.expand(true);
		this.folderPanel.add(this.componentFolder);
		westPanel.add(this.folderPanel,{split:true});
		this.fire('addComponentFolder', this.componentFolder);
		
		this.checkerPanel = new CTitlePanel({title:'检查器'});
		this.componentChecker = new CTree({title:'检查器', scrollor:this.checkerPanel});
		this.checkerPanel.add(this.componentChecker);
		this.westPanel.add(this.checkerPanel);
		this.on('vs_client_add_comp',function(comp, ctx){
			
			var ct = this.componentChecker.findChildDeep(ctx.cacheId);
			if(!ct){
				ct = this.componentChecker.root;
			}
			
			ct.add(new CTreeItem({id:comp.cacheId,bindComp:comp, title:comp.type+' - '+(comp.title||comp.id)}));
		});

		this.on('vs_client_remove_comp',function(comp, ctx){
			var c = this.componentChecker.findChildDeep(comp.cacheId);
			if(c)
				c.parentContainer.remove(c);
		});
		
		this.componentChecker.on('selected', function(item){
			if(item.bindComp){
				CUtil.getAnchorBox().anchorTo(item.bindComp);
			}
		});
		
		CUtil.getAnchorBox().on('boxanchor', function(comp){
			if(!comp){
				VS.componentChecker.select(null);
				return;
			}
			var sel = VS.componentChecker.selected;
			if(!sel || VS.componentChecker.selected.id != comp.cacheId){
			 var it = VS.componentChecker.findChildDeep(comp.cacheId);
			 	VS.componentChecker.select(it);
			}
		});
		
		this.componentChecker.root.expand(true);
		
		this.fire('addComponentChecker', this.componentChecker);
}));


IDE.registerPlugin('addEastPanel',(function(eastPanel){
	var g = this.propertyGrid = IDE.getPropertyGrid();
	eastPanel.add(g);
	
	function updateComponentAttributes(comp){
		var prevs = this.preanchorComp,
		    vs = IDE.getComponentPropertyViews(comp),
		    i,v;
		if(prevs){
			prevs= IDE.getComponentPropertyViews(prevs);
			// hide previous attr views
			for(i=prevs.length-1;i>=0;i--){
				prevs[i].hide();
			}
	  }
	  g.bindingComponent = comp;
		//show current component attr views.
		for(i=vs.length-1;i>=0;i--){
			v = vs[i];
			v.show();
			v.applyComponent(comp);
	  }
	}
	
	this.anchorBox.on('boxanchored',updateComponentAttributes);
}));

//增加一个插件,主要功能是增加各TAB ITEM显示IFRAME
//IFRAME src在tabitem中设置
IDE.registerPlugin('addTab', (function(tab) {
    var fr = this;
}));


//
// 增加其它项控件
//
IDE.registerPlugin('rendered', (function(){
	
}));

//
// 增加中间面板主界面
//
IDE.registerPlugin('rendered', (function(){
}));