
if(!window.Event)
	window.Event = {};

Event.events = {
  'created class CBase' :[
  {
  	cb: function(cb){
  		(function(cb, cu){
  			var oriDomEvent = cb.domEvent;
  			
  			cb.domEvent = function(){
  				//如果为可视化开发控件,忽略所有注册事件
						if (g_mode) 
							return this;
						return oriDomEvent.apply(this, arguments);
					};
					
					var oriUnDomEvent = cb.unDomEvent;
					cb.unDomEvent = function(){
						//如果为可视化开发控件,忽略所有注册事件
						if (g_mode) 
							return this;
						return oriUnDomEvent.apply(this, arguments);
					};
					
					//
					// 所有可视化控件点击后定位框框
					//
					function bindResizeBoxOnclick(){
						//因为此时并未创建AnchorBox,所以在运行时调用获得AnchorBox
						cu.getAnchorBox().anchorTo(this);
					};
					
					
					var oriInitComponent = cb.initComponent;
					cb.initComponent = function(){
						oriInitComponent.apply(this, arguments);
						if (g_mode) {
							if (this.anchorable) {
								oriDomEvent.call(this, 'mousedown', bindResizeBoxOnclick, true);
								//标记作为vs控件
								this.__vsComp = true;
							}
						}
					};
					
					var orIDEstory = cb.destoryComponent;
					cb.destoryComponent = function(){
						if (this.__vsComp) {
							oriUnDomEvent.call(this, 'mousedown', bindResizeBoxOnclick);
						// 	   if(this.children)
						// 	   	this.enableDropBehavior(false);
						}
						orIDEstory.apply(this, arguments);
					};
				})(cb, CUtil);
			}
	}]
};