//Default Framework Plugins

//Tab Plugins
UI126.registerPlugin('addNorthPanel', (function(northPanel){
		this.tab = new CTab({cs:'fr-tab', /*itemAutoConnect:true,*/ layout: 'autoscroll', layoutCfg:{marginLeft:191}});
		northPanel.add(this.tab);
		this.fire('addTab', this.tab);
}));

//Left Folder UI Plugins
UI126.registerPlugin('addWestPanel', (function(westPanel){
		this.folderPanel = new CTitlePanel({title:'文件夹', tip:false});
		this.folder = CUtil.createFolder();
		
			//增加其它显示项,只是为了显示,没实质内容.
			this.folder.fromArray([
					{title:'背光脚本',icon:'icoNote', qtip:'<strong>背光脚本</strong><br/>构建自由WEB应用'},
	  			{title:'disabled item',icon:'icoIbx',disabled:true},
					{title:'粉红色',icon:'icoDft', qtip:'点击立即变换主题', skin:'fenghong'},
					{title:'绿色',icon:'icoNote', skin:'ru'},
					{title:'清除记录',icon:'icoDel'},
					{title:'无名色',icon:'icoDft', skin:'fengru'},
					{title:'蓝色',icon:'icoNote', skin:'lan'},
					{title:'玫瑰红',icon:'icoNote', skin:'shenhong'},
					{title:'背光脚本',icon:'icoNote', qtip:'<strong>背光脚本</strong><br/>构建自由WEB应用'},
	  			{title:'disabled item',icon:'icoIbx',disabled:true},
					{title:'粉红色',icon:'icoDft', qtip:'点击立即变换主题', skin:'fenghong'},
					{title:'绿色',icon:'icoNote', skin:'ru'},
					{title:'清除记录',icon:'icoDel'}
			]);
			
		this.folderPanel.add(this.folder);
		//
		this.folder.scrollor = this.folderPanel;
		
		
		var fdPanel2 = new CTitlePanel({title:'我的好友', tip:false, array:[
			CUtil.createFolder({array:[
					{title:'背光脚本',icon:'icoNote', qtip:'<strong>背光脚本</strong><br/>构建自由WEB应用'},
	  			{title:'disabled item',icon:'icoIbx',disabled:true},
					{title:'粉红色',icon:'icoDft', qtip:'点击立即变换主题', skin:'fenghong'},
					{title:'绿色',icon:'icoNote', skin:'ru'},
					{title:'清除记录',icon:'icoDel'},
					{title:'无名色',icon:'icoDft', skin:'fengru'},
					{title:'蓝色',icon:'icoNote', skin:'lan'},
					{title:'玫瑰红',icon:'icoNote', skin:'shenhong'},
					{title:'背光脚本',icon:'icoNote', qtip:'<strong>背光脚本</strong><br/>构建自由WEB应用'},
	  			{title:'disabled item',icon:'icoIbx',disabled:true},
					{title:'粉红色',icon:'icoDft', qtip:'点击立即变换主题', skin:'fenghong'},
					{title:'绿色',icon:'icoNote', skin:'ru'},
					{title:'清除记录',icon:'icoDel'}
			]})
		]});
		
		var ui126 = this;
			//组与tab联动例子
			this.folder.on('selected', function(item){
				var tabItem = ui126.tab.$(item.id);
				if(!tabItem){
					tabItem = new CTabItem({title:item.title, id:item.id, src:item.src});
					ui126.tab.add(tabItem);
				}
				if(ui126.tab.selected != tabItem)
					ui126.tab.select(tabItem);
					
				//是否有换肤, skin标志
				if(item && item.skin){
					var nd = CC.$('ui126-skin');
					var href = nd.href.substring(0, nd.href.replace('\\','/').lastIndexOf('/')+1);
					nd.href = href + item.skin+'_share.css';
				}
			});
			
		this.folderPanel.on('fold', function(fold){
			if(!fold && !this.loaded){
				//this.connect('http://www.bgscript.com/q?bg_q=test_group', {method:'GET'});
			}
		});
		
		westPanel.add(this.folderPanel,{collapsed:false});
		
		this.fire('addFolder', this.folder);
		
		this.treePanel = new CTitlePanel({title:'部门'});
		
		this.tree = new CTree({title:'部门组织'});
		this.tree.root.expand(true);
		this.treePanel.add(this.tree);
		this.tree.scrollor = this.treePanel;
		westPanel.add(this.treePanel);
		
		this.fire('addTree', this.tree);
		
		westPanel.add(fdPanel2);
		
}));


UI126.registerPlugin('addEastPanel',(function(eastPanel){
//tree combox
   //tree filter for combox
			function treeFilter(matcher, caller){
			  var caller = caller || window, fn = arguments.callee;
			  if(this.children){
			  	var cm = true;
	        CC.each(this.children, (function(){
	            if(!matcher.call(caller,this) && !this.nodes){
	                this.display(0);
	                cm = false;
	                return;
	            }
	            this.display(1);
	            if(this.nodes && this.expanded)
	            	fn.call(this, matcher, caller);
	        }));
      	}
			}
			
var eastTitlePanel = new CTitlePanel({title:'组件列表', tip:false, layout:'row'});
//selector of combox
var tree = new CTree({title:'tree2', url:'http://www.bgscript.com/q?bg_q=test_group', /*autoConnect:true,*/ shadow:false, showTo:document.body, hidden:true,filter:treeFilter});
var cb = new CCombox({id:'eastCombox', selectorCS:'g-combo-list g-combo-list-tree', autoRender:false,selector:tree, width:350});
//tree will be destoryed when combox destoryed. 
cb.follow(tree);
eastTitlePanel.add(cb);


//folderview
var ct = new CContainerBase({id:'fd_uidemolist', ItemClass: CFolderView});

//ct.connect('http://www.bgscript.com/q?bg_q=bg_uidemolist', {method:'GET'});
 
 ct.on('final',function(ajax){
		 CC.each(this.children, (function(){
			 //更新标题,显示数目
			 this.foldable.setTitle(this.title);
 }));
});
 
 eastTitlePanel.add(ct, {h:'lead'});
eastPanel.add(eastTitlePanel, {collapsed:false});
}));

//增加一个插件,主要功能是增加各TAB ITEM显示IFRAME
//IFRAME src在tabitem中设置
UI126.registerPlugin('addTab', (function(tab) {
    var fr = this;
    tab.on('selected', (function(item) {
      if (!item.panel && item.src) {
        item.panel = new CIFramePanel({
          src: item.src
        });
        //添加到中间面板去
        //布置配置h:lead表示由布置管理器自动高度
        fr.centerPanel.add(item.panel);
      }
    }));
}));


//
// 增加其它项控件
//
UI126.registerPlugin('addCenterPanel', (function(){
			var ui126 = this;
			//增加TAB项,IFRAME例子.
			this.tab.contentPanel = this.centerPanel;
			
			this.tab.fromArray([
			{title:'www.bgscript.com', src:'http://www.bgscript.com'},
			{title:'126', src:'http://www.126.com'},
			{title:'百度', src:'http://www.baidu.com'},
			{title:'禁用', disabled:true},
			{title:'google', src:'http://www.google.com'}
			]);
			
			this.tab.on('selected', function(item){
				var folder = ui126.folder;
				var foldItem = folder.$(item.id);
				if(folder.selected == foldItem)
					return;
				if(foldItem){
					folder.select(foldItem);
				}else 
					folder.select(null);
			});
			
			//this.tree.autoConnect = true;
			//this.tree.url = 'http://www.bgscript.com/q?bg_q=test_group';
			this.tree.root.fromArray([
				{title:'背光脚本', nodes:true, array:[
					{title:'背光脚本'},
					{title:'126邮箱'},
					{title:'Google'},
					{title:'Ajaxian', disabled:true}
				]},
				{title:'百度'},
				{title:'谷歌'}
			]);
}));

//
// 增加中间面板主界面
//
UI126.registerPlugin('addCenterPanel', (function(){
	var panel = new CPanel({layout:'row',view:Cache.get('div')});
	//toolbar
	var onToolbarClick = function(item){CUtil.alert(item.title);};
	var tb = CPanel.createBigBar({layout: 'autoscroll', 
		 array:[
			{icon:'iconCalendar',title:'小强旺财',qtip:'中型工具栏', dockable:true},
			{icon:'iconUser',title:'用户名单'},
			{icon:'iconEdit',title:'编辑黑名单'},
			{icon:'iconCalendar',title:'小强旺财'},
			{icon:'iconUser',title:'用户名单'},
			{icon:'iconEdit',title:'编辑黑名单'},
			{icon:'iconRef',title:'立即启动',disabled:true},
			{icon:'iconCalendar',title:'小强旺财',qtip:'中型工具栏'},
			{icon:'iconUser',title:'用户名单'}
	]});
	tb.on('selected',onToolbarClick);
	
	panel.add(tb);
	var opt = {createCustomComponent : function(){this.customComp = CC.$$(CC.$C('DIV'));}};
	var g = new CGrid({
		header:[
		    new CCustomColumn(),
				{title:'名称'},
				{title:'数目'},
				{title:'分类'},
				{title:'column D'},
				{title:'column E'}
			]
		,
		minW:150,
		autoFit:true
	});
	
	var v1 = new CGridGroupView({
		title : '收件箱',
		rowHoverCS:false,
		ItemClass : CCustomRow,
		itemOptions : opt
	});
	g.add(v1);
	
	v2 = new CGridGroupView({
		title : '发件箱',
		selectedCS:'g-row-selected',
		ItemClass : CCustomRow,
		id : 'ui-126-gridview2'
	});
	g.add(v2);
	
	g.on('cellclick', function(cell){
			CUtil.ftip('点击 '+cell.title+', index:'+cell.parentContainer.indexOf(cell), '单元格点击', cell.view);
  });
		
	panel.add(g, {h:'lead'});

  var small = this.smallbar = CPanel.createSmallBar({autoRender:true, layout:'autoscroll'});
  
	small.fromArray([
		{cs : 'mybutton', title:'你好',icon:'iconEdit', qtip:'这是一个可停靠，具有文本和图标的按钮', dockable:true},
		{cs : 'mybutton', icon:'iconEdit', tip:'单个图标按钮'},
		{cs : 'mybutton', icon:'iconUser', tip:'单个图标按钮'},
		{cs : 'mybutton', disabled:true,icon:'iconEdit', tip:'单个图标按钮,已禁用'},
		{cs : 'mybutton', icon:'iconEdit',dockable:true, docked:true,  tip:'单个图标按钮'},
		{cs : 'mybutton',  icon:'iconUser', tip:'单个图标按钮,无文本'},
		{cs : 'mybutton', title:'小按钮', tip:'单个图标按钮'},
		{cs : 'mybutton', title:'小按钮', tip:'单个图标按钮'},
		{cs : 'mybutton', title:'小按钮', icon:'iconCalendar', tip:'单个图标按钮'},
		{cs : 'mybutton', title:'你好',icon:'iconEdit', qtip:'这是一个可停靠，具有文本和图标的按钮', dockable:true},
		{cs : 'mybutton', icon:'iconEdit', tip:'单个图标按钮'},
		{cs : 'mybutton', icon:'iconUser', tip:'单个图标按钮'},
		{cs : 'mybutton', disabled:true,icon:'iconEdit', tip:'单个图标按钮,已禁用'},
		{cs : 'mybutton', icon:'iconEdit',dockable:true, docked:true,  tip:'单个图标按钮'},
		{cs : 'mybutton',  icon:'iconUser', tip:'单个图标按钮,无文本'},
		{cs : 'mybutton', title:'小按钮', tip:'单个图标按钮'},
		{cs : 'mybutton', title:'小按钮', tip:'单个图标按钮'},
		{cs : 'mybutton', title:'小按钮', icon:'iconCalendar', tip:'单个图标按钮'}
	]);
	
	panel.add(small, {h:26});
	
	this.centerPanel.add(panel, {h:'lead'});
	
	this.tab.insert(0, new CTabItem({title:'综合', qtip:'综合应用例子', panel:panel, id:'grid_tab'}));
	this.tab.on('selected',function(item){
		//在CFolderView标题中更新行数
		function onfinal(){
			this.foldbar.setTitle(this.foldbar.title);
		}
		
		if(item.id == 'grid_tab'){
			if(!v1.loaded){
				v1.on('final',onfinal);
				//v1.connect("http://www.bgscript.com/q?bg_q=grid_view_data");
				v1.fromArray([{array:[{title:'CellA'},{title:'Cell0'},{title:'H'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellB'},{title:'Cell7'},{title:'Z'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellC'},{title:'Cell4'},{title:'1'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellA'},{title:'Cell0'},{title:'H'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellB'},{title:'Cell7'},{title:'Z'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellC'},{title:'Cell4'},{title:'1'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellA'},{title:'Cell0'},{title:'H'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellB'},{title:'Cell7'},{title:'Z'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellC'},{title:'Cell4'},{title:'1'},{title:'CellD'},{title:'CellE'}]}]);
			}
			if(!v2.loaded){
				v2.on('final',onfinal);
				//v2.connect("http://www.bgscript.com/q?bg_q=grid_view_data2");
				v2.fromArray([{array:[{title:'CellA'},{title:'Cell0'},{title:'H'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellB'},{title:'Cell7'},{title:'Z'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellC'},{title:'Cell4'},{title:'1'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellA'},{title:'Cell0'},{title:'H'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellB'},{title:'Cell7'},{title:'Z'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellC'},{title:'Cell4'},{title:'1'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellA'},{title:'Cell0'},{title:'H'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellB'},{title:'Cell7'},{title:'Z'},{title:'CellD'},{title:'CellE'}]},{array:[{title:'CellC'},{title:'Cell4'},{title:'1'},{title:'CellD'},{title:'CellE'}]}]);
			}
			if( v1.loaded && v2.loaded){
				this.un('selected', arguments.callee);
			}
		}
	});
	
	//build the form dialog
	
        var fieldCombo = new CCombox({
            id: 'mycombo',
            value: 'combox can be dropped..',
            array: [{
                title: '粉绿色',
                icon: 'icoIbx'
            }, {
                title: '粉红色',
                icon: 'icoDft'
            }, {
                title: '绿色',
                icon: 'icoNote'
            }, {
                title: '清除记录',
                icon: 'icoDel',
                disabled: true
            }, {
                title: '粉红色',
                icon: 'icoDft'
            }, {
                title: '蓝色',
                icon: 'icoNote'
            }, {
                title: '清除记录',
                icon: 'icoDel'
            }]
        });
        
			  var menu = new CMenu({
			  	autoPopup : false,
			  	id:'dlg-menu',
			  	align:'x',
			  	noContext:true,
			  	array:[
			  	 {title:'文件(F)', 
			  	 	array:[{title:'新建'},{title:'打开', 
			  	 	   array:[{title:'最近打开...', 
			  	 	     array:[{title:'格式(O)', array:[{title:'自动换行'},{title:'字体'}]},
			  	              {title:'查看(V)', array:[{title:'状态栏'}]}]}, 
			  	              {title:'RMB.txt'}, {title:'US.txt', disabled:true}, {title:'满状态.txt'}]},
			  	 {title:'保存'},{title:'另存为'},CMenu.Separator,{title:'页面设置'},{title:'打印'},CMenu.Separator,{title:'退出'}]},
			  	 {title:'编辑(E)', array:[{title: '撤销'},{title: '重做'},{title: '复制'},{title: '删除'}, CMenu.Separator, {title: '全选'},{title: '选择行'}]},
			  	 {title:'格式(O)', array:[{title:'自动换行'},{title:'字体'}]},
			  	 {title:'查看(V)', array:[{title:'状态栏'}]},
			  	 {title:'帮助(H)', array:[{title:'帮助主题'},{title:'关于记事本'}]}
			  	]
			  });
        var menuPanel = new CContainerBase({
        	id:'dlg-menu-panel', 
        	template:'CWrapPanel', 
        	container:'_wrap', 
        	height:25
        });
        
  			menuPanel.add(menu);
  			
        //			var chk = new CCheckbox({title:'check this one!'});
        //			var rad = new CRadio({title:'check this one!'});
        var layer = new CFormLayer({
            id: 'ui-form-exp',
            array: [
            {
                title: 'Text area Here!',
                array: [{
                    ctype: 'textarea',
                    name: 'aa',
                    id: 'myarea',
                    value: 'Write some words here!'
                }]
            }, {
                title: 'Text field Here',
                array: [{
                	  cs : 'fm-txt-w',
                    title: 'Text field Here!',
                    ctype: 'text'
                },{
                	  cs : 'fm-txt-w',
                    title: 'Text field Here!',
                    ctype: 'text',
					disabled:true
                }]
            }, 
			{
				title:'Checkbox元素',
				array:[ {
                    title: 'Checkbox元素',
                    ctype: 'checkbox'
                }, {
                    title: 'Checkbox元素',
                    ctype: 'checkbox'
                },{
                    title: 'Checkbox元素',
                    ctype: 'checkbox',
					disabled:true
                }]
			},
			{
				title:'Radio元素',
				array:[ {
                    title: '元素Radio',
                    ctype: 'radio'
                }, {
                    title: '元素Radio',
                    ctype: 'radio'
                },{
                    title: '元素Radio',
                    ctype: 'radio',
					disabled:true
                }]
			},
			{
                title: 'Combo box下拉框',
                array: [fieldCombo]
            }, 
			{
                title: '进度条控件',
                array: [{ctype:'progressbar', value:62}]
            }, 
			{
                title: '日期选择控件',
                array: [new CDatepickerField({})]
            }]
        });
        
        var dlg = new CDialog({
            title: '背光JS库表单控件',
            showTo: document.body,
            height: 453,
            width: 536,
						buttons : [
							{title: '取&nbsp;消', id:'cancel'}, 
              {title: '确&nbsp;定', id:'ok'}
            ],
            defaultButton:'ok'
            });
        		
        var subDlg = new CDialog({
        	title:'子模式对话框',
        	showTo:document.body,
        	autoRender : true,
        	width:260,
        	height:145,
        	navKeyEvent : true,
        	hidden : true,
        	buttons :  [
        	{title: '&nbsp;否&nbsp;', id:'no'},
        	{ title: '&nbsp;是&nbsp;', id:'yes'}
          ],
          defaultButton:'no'
        });
        
        dlg.on('close', function(){
        	subDlg.show(dlg, true, function(){
        		if(this.returnCode == 'yes'){
        			this.modalParent.hide();
        		}
        	});
        	return false;
        });
        dlg.add(menuPanel).add(layer).render();
        dlg.center();
}));

UI126.registerPlugin('rendered', (function(){
	this.tab.select(0);
}));