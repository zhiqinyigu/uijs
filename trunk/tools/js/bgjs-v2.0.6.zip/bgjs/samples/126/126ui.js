CC.create('UI126', CViewport, function(father){
return {
	//BorderLayout布局
	layout:'border',
	
	id : 'ui126',
	
	loadFramework : function(){
		var self = this;
		//如果存在插件
		if(UI126.plugins){
			CC.each(UI126.plugins, (function(){
				if(CC.isArray(this)){
					self.on(this[0], this[1]);
				}else this(self);
			}));
			//release plugins.
			UI126.plugins = null;
		}
		//创建主要布局 - 东西北中
		this.northPanel = new CPanel({id:'frameworkNorthPanel', cs:'g-f2',height:70, maxH:70, layout:'card'});
		this.westPanel = CPanel.getBorderPanel({width:185, maxW:450, layout:'qq'});
		this.eastPanel = CPanel.getBorderPanel({width:400, layout:'qq'});
		this.centerPanel = CPanel.getBorderPanel({layout:'card'});
		this.southPanel = CPanel.getBorderPanel({insets:[1,0,0,0],height:70, layout:'card'});
		this.add(this.northPanel, {dir:'north', split:true,collapsed: true});
		this.fire('addNorthPanel', this.northPanel);
		this.add(this.southPanel, {dir:'south',split:true,collapsed: true});
		this.fire('addSouthPanel', this.southPanel);
		this.add(this.eastPanel, {dir:'east',split:true,collapsed: true});
		this.fire('addEastPanel', this.eastPanel);
		this.add(this.westPanel, {dir:'west',split:true,collapsed: true});
		this.fire('addWestPanel', this.westPanel);
		this.add(this.centerPanel, 'center');
		this.fire('addCenterPanel', this.centerPanel);
	},
	
	destoryComponent : function(){
		this.fire('destory');
		father.destoryComponent.call(this);
	}
};
});

UI126.registerPlugin = function(pln, c){
	if(!UI126.plugins)
		UI126.plugins = [];
	if(CC.isFunction(pln)){
		UI126.plugins.push(pln);
	}else {
		UI126.plugins.push([pln, c]);
	}
};
