CC.create('CFormLayout', CLayout, function(superclass) {

  return {
  	rows : [],
  	
  	hgap : 3,
  	
  	vgap : 3,
  	
  	layoutChild : function(){
  	},
  	
    addComponent : function(c, cfg){
    	//make component absolute Position.
    	if(c.style('position') != 'absolute')
    		c.setStyle('position', 'absolute');
      this.items[this.items.length] = c;
      superclass.addComponent.call(this, c, cfg);
    },
    
    attach: function(c) {
      superclass.attach.call(this, c);
      this.items = [];
    }
  };
});

CLayout['form'] = CFormLayout;