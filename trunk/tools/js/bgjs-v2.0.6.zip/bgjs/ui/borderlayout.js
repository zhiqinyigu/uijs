/**
 * 与Java swing中的BorderLayout具有相同效果.
 * 将容器内控件作为沿边框布局.
 */

CTemplate['CBorderLayoutSpliter'] = '<div class="g-layout-split"></div>';
CC.create('CBorderLayout', CLayout, function(superclass) {
  var CBorderLayoutSpliter = CC.create(CSpliter, function(spr) {

    return {

      type: 'CBorderLayoutSpliter',
      enableResizeMasker : true,
      initComponent: function() {
        this.container = this.layout.wrapper;
        if (this.dir == 'north' || this.dir == 'south') this.disableLR = true;
        else this.disableTB = true;
        spr.initComponent.call(this);
        this.domEvent('dblclick', this.onDBClick);
      },

      onDBClick: function() {
      },

      calculateRestrict: function() {
        var ly = this.layout,
        wr = this.container;
        var max, min, dir = this.dir,
        comp = ly[dir],
        op,
        cfg = comp.layoutCfg[ly.type],
        lyv = ly.vgap,
        lyh = ly.hgap,
        vg = cfg.gap == undefined ? lyv: cfg.gap,
        hg = cfg.gap == undefined ? lyh: cfg.gap,
        cfg2,cbg = ly.cgap,cg,
        ch = wr.height,
        cw = wr.width;
        switch (dir) {
        case 'north':
          min = -1 * comp.height;
          max = ch + min - vg;
          op = ly.south;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	max -= cg;
            }
            if(!op.hidden && !op.contexted)
            	max -= op.height + (cfg2.gap == undefined ? lyv: cfg2.gap);
          }

          if(max>comp.maxH-comp.height)
          	max = comp.maxH - comp.height;
          if(Math.abs(min)>comp.height - comp.minH)
          	min = -1*(comp.height - comp.minH);
          break;
        case 'south':
          max = comp.height;
          min = -1 * ch + max + vg;
          op = ly.north;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	min += cg;
            }
            
            if(!op.hidden && !op.contexted)
            	min += op.height + (cfg2.gap == undefined ? lyv: cfg2.gap);
          }
          
          if(max>comp.height - comp.minH)
          	max = comp.height - comp.minH;
          if(Math.abs(min)>comp.maxH-comp.height)
          	min = -1*(comp.maxH-comp.height);
          break;
        case 'west':
          min = -1 * comp.width;
          max = cw + min - hg;
          op = ly.east;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	max -= cg;
            }
            if(!op.hidden && !op.contexted)
            	max -= op.width + (cfg2.gap == undefined ? lyh: cfg2.gap);
          }
          
          if(max > comp.maxW - comp.width)
          	max = comp.maxW - comp.width;
          if(Math.abs(min)>comp.width - comp.minW)
          	min = -1*(comp.width - comp.minW);
          break;
        case 'east':
          max = comp.width;
          min = -1 * cw + max + hg;
					op = ly.west;
          if (op) {
            cfg2 = op.layoutCfg[ly.type];
            
            if(cfg2.cbar && !cfg2.cbar.hidden){
            	cg = cfg2.cgap === undefined ? cbg: cfg2.cgap;
            	min += cg;
            }
            
            if(!op.hidden && !op.contexted)
            	min += op.width + (cfg2.gap == undefined ? lyh: cfg2.gap);
          }
          if(max > comp.width - comp.minW)
          	max = comp.width - comp.minW;
          if(Math.abs(min)>comp.maxW - comp.width)
          	min = -1*(comp.maxW - comp.width);
        }

        if (dir == 'west' || dir == 'east') {
          this.minLR = min;
          this.maxLR = max;
        } else {
          this.minTB = min;
          this.maxTB = max;
        }
      },

      applyDist: function(dt) {
        var c = this.layout[this.dir];
        //this.presize = this.enableH ? c.height:c.width;
        var wr = this.container;
        if (this.disableLR) {
          c.setHeight(this.dir == 'north' ? c.height + dt: c.height - dt);
        } else {
          c.setWidth(this.dir == 'west' ? c.width + dt: c.width - dt);
        }
        this.layout.doLayout();
      },

      onSplitEnd: function() {
        var c = this.layout[this.dir];
        //this.presize = this.enableH ? c.height:c.width;
        var wr = this.container;
        if (this.disableLR) {
          c.setHeight(this.dir == 'north' ? c.height + this.splitDY: c.height - this.splitDY);
        } else {
          c.setWidth(this.dir == 'west' ? c.width + this.splitDX: c.width - this.splitDX);
        }
        this.layout.doLayout();
      }
    };
  });
  
  CTemplate['CCollapseBarH'] = '<table cellspacing="0" cellpadding="0" border="0" class="g-layout-split"><tr><td class="cb-l"></td><td class="cb-c"><div class="expander" id="_expander"><a class="nav" id="_navblock" href="javascript:fGo()"></a></div></td><td class="cb-r"></td></tr></table>';
  CTemplate['CCollapseBarV'] = '<table cellspacing="0" cellpadding="0" border="0" class="g-layout-split"><tr><td class="cb-l"></td></tr><tr><td class="cb-c"><div class="expander" id="_expander"><a class="nav" id="_navblock" href="javascript:fGo()"></a></div></td></tr><tr><td class="cb-r"></td></tr></table>';
  var CBorderLayoutCollapseBar = CC.create(CContainerBase, {
		type : 'CBorderLayoutCollapseBar',
		
		hidden : true,
		
		inherentCS:'g-layout-cbar',
		
		container : '_expander',
		
		compContextedCS : 'g-layout-contexted',
		
		sliperCS : 'g-layout-sliper g-f1',
		
		navBlockCS : {
			       east:'g-nav-block-l',west:'g-nav-block-r',
			       south:'g-nav-block-u',north:'g-nav-block-d'
	  },
		
		initComponent : function(){
			this.template = (this.dir == 'south' || this.dir == 'north')?'CCollapseBarH' : 'CCollapseBarV';
			CContainerBase.prototype.initComponent.call(this);
		  if(this.dir == 'west' || this.dir == 'east'){
				this.addClass(this.inherentCS+'-v');
		  }else{
				this.itemOptions = {
					hoverCS:'g-smallbar-item-over',
					clickCS:'g-smallbar-item-click',
					inherentCS:'g-smallbar-item',
					focusCS : false,
					template : 'CBarItem'
				};
				this.ItemClass = CButton;
		  }
		  
			this.ItemClass = CBase['vbutton'];
			
			this.centerExpander = this.dom('_expander');
			this.navBlock = this.dom('_navblock');
			CC.fly(this.navBlock).addClass(this.navBlockCS[this.dir]).unfly();
			this.domEvent('mousedown', this.onBarClick, true);
			this.domEvent('mousedown', this.onNavBlockClick, true, null, this.navBlock);
			
			this.sliperEl = CC.$C({tagName:'A', className:this.sliperCS,href:'javascript:fGo()'});
			this.comp.wrapper.append(this.sliperEl);
			this.comp.domEvent('mousedown', this.sliperAction, false, null, this.sliperEl);
		},
		
		sliperAction : function(){
			this.parentContainer.layout.collapse(this, true);
		},
		
		/**
		 * 收缩按钮点击
		 */
		onNavBlockClick : function(){
			var c = this.comp;
			if(c.contexted)
				c.releaseContext();
			this.itsLayout.collapse(c, false);
		},
		
		/**
		 * 使得面板浮动
		 */
		makeFloat : function(){
			var c = this.comp;
			c.addClass(this.compContextedCS);
			c.display(true);
			this.setCompContextedBounds();
			var xy = c.absoluteXY();
			c.appendTo(document.body).setXY(xy);
			
			var cfg = c.layoutCfg[this.itsLayout.type];
			var sd = cfg.shadow;
			if(!sd){
				sd = cfg.shadow = new CShadow({inpactH:5,inpactY:-1});
				c.follow(sd);
			}
			
			sd.attachTarget(c)
			  .reanchor()
			  .display(true);
			if(!cfg.cancelAutoHide){
				this.resetAutoHideTimer();
				cfg.autoHideTimer = this.onTimeout.bind(this).timeout(cfg.autoHideTimeout||5000);
			}
		},
		
		onTimeout : function(){
			var c = this.comp;
			if(c.contexted)
				c.releaseContext();
			else this.unFloat();
			this.resetAutoHideTimer();
		},
		
		resetAutoHideTimer : function(){
			var cfg = this.comp.layoutCfg[this.itsLayout.type];
			if(cfg.autoHideTimer){
				clearTimeout(cfg.autoHideTimer);
				delete cfg.autoHideTimer;
			}
		},
		
		/**
		 * 面板复原
		 */
		unFloat : function(){
			var c = this.comp;
			var cfg = c.layoutCfg[this.itsLayout.type];
				
			if(cfg.autoHideTimer)
				this.resetAutoHideTimer();
				
			c.parentContainer._addNode(this.comp.view);
			c.delClass(this.compContextedCS);
			cfg.shadow.detachTarget();
		},
		
		/**
		 * 点击区域范围外时回调
		 */
		onCompReleaseContext : function(){
			var cfg = this.layoutCfg['CBorderLayout'];
			cfg.cbar.unFloat();
		},
		
		/**
		 * 侧边栏点击
		 */
		onBarClick : function(){
			var c = this.comp;
			if(c.contexted)
				c.releaseContext();
			//callback,cancel, caller, childId, cssTarget, cssName
			else {
				c.bindContext(this.onCompReleaseContext, true, null, null, this.navBlock, this.navBlockCS[this.dir]+'-on');
        this.makeFloat();
			}
		},
		
		/**
		 * 设置浮动面板浮动开始前位置与宽高
		 */
		setCompContextedBounds : function(){
			var c = this.comp, dir = this.dir;
			if(dir == 'west')
				c.setBounds(this.left+this.width+1, this.top, false, this.height);
			else if(dir == 'east')
				c.setBounds(this.left - c.width - 1, this.top, false, this.height);
			else if(dir == 'north')
				c.setBounds(this.left, this.top+this.height+1, this.width, false);
			else c.setBounds(this.left, this.top-c.height - 1, this.width, false);
		},
		
		setSize : function(){
			CContainerBase.prototype.setSize.apply(this, arguments);
			var v;
			if(this.dir == 'north' || this.dir == 'south'){
				v = Math.max(0, this.width - 6)+'px';
				this.centerExpander.style.width = v;
				if(CC.ie)
					this.centerExpander.parentNode.style.width = v;
			}
			else{
				v =  Math.max(0, this.height - 6)+'px';
				this.centerExpander.style.height = v;
				if(CC.ie)
					this.centerExpander.parentNode.style.height = v;				
			}
		}
		
  });
  
  return {
    /**
     * 水平方向分隔条高度,利用面板布置设置可覆盖该值.
     */
    hgap: 5,
    /**
     * 垂直方向分隔条高度,利用面板布置设置可覆盖该值.
     */
    vgap: 5,
    /**
     * 侧边栏宽度.
     */
		cgap : 32,
		/**
		 *
		 */
		cpgap : 5,
    
    wrCS : 'g-borderlayout-ct',
    itemCS :'g-borderlayout-item',
    
    addComponent: function(comp, dir) {
      superclass.addComponent.call(this, comp, dir);
      var d, s;
      if (dir === null || dir === undefined) d = 'center';
      if (typeof dir == 'object') {
        d = dir.dir;
        s = dir.split;
      }

      else d = dir;

      this[d] = comp;
      
      if (s && d != 'center') {
        var sp = dir.separator = new CBorderLayoutSpliter({
          dir: d,
          layout: this
        });
        if (d == 'west' || d == 'east') sp.addClass(this.separatorVCS || 'g-ly-split-v');
        else sp.addClass(this.separatorHCS || 'g-ly-split-h');
        sp.display(1).appendTo(this.ctNode);
        //
        comp.follow(sp);
      }
      
      comp.addClass(this.itemCS + '-' + (d||'center'));
      
      if(dir.collapsed)
      	this.collapse(comp, true);
      else this.doLayout();
    },
    
    getCollapseBar : function(c){
    	var cfg, cg, cbar;
      cfg = c.layoutCfg[this.type];
      cbar = cfg.cbar;
      if(!cbar && !cfg.noSidebar){
	      cbar = cfg.cbar = new CBorderLayoutCollapseBar({dir:cfg.dir, comp:c, itsLayout:this});
	      cbar.addClass(cbar.inherentCS+'-'+cfg.dir);
	      cbar.appendTo(this.ctNode);
	      this.container.follow(cbar);
      }
      return cbar;
    },
    
    collapse : function(comp, b){
    	var cbar = this.getCollapseBar(comp);
    	
    	var cfg = comp.layoutCfg[this.type];
    	cfg.collapsed = b;
    	if(cfg.separator)
    		cfg.separator.display(!b);
    	if(comp.fold)
    		comp.fold(b, true);
    	if(cbar)
    		cbar.display(b);
    	comp.display(!b);
    	this.doLayout();
    },
    
    onLayout: function() {
      var wr = this.wrapper;
      var w = wr.getWidth(true),
      h = wr.getHeight(true),
      l = 0,
      t = 0,
      c = this.north;

      var dd, n, sp, vg = this.vgap, cbg = this.cgap,cpg = this.cpgap,dcpg = cpg+cpg,
      hg = this.hgap,
      cfg, cg, cb;
      if (c) {
        cfg = c.layoutCfg[this.type];
        cb = cfg.cbar;
        
        if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	cb.setBounds(l+cpg,t+cpg,w-dcpg, cg - dcpg);
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	t += cg;
        }
        
        if(!c.hidden && !c.contexted){
        	dd = c.getHeight(true);
          c.setBounds(l, t, w, c.height);
          t += dd;
	        cg = cfg.gap === undefined ? vg: cfg.gap;
	        sp = cfg.separator;
	        if (sp) {
	          sp.setBounds(l, t, w, cg);
	        }
	        t += cg;
        }
        if(c.contexted)
        	c.releaseContext();
      }

      c = this.south;
      if (c) {
        cfg = c.layoutCfg[this.type];
        cb = cfg.cbar;
        if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	h -= cg;
          cb.setBounds(l+cpg,h+cpg,w-dcpg, cg - dcpg);
        }
        
        if(!c.hidden && !c.contexted){
        	dd = c.getHeight(true);
        	h -= dd;
        	c.setBounds(l, h, w, c.height);
        	cg = cfg.gap === undefined ? vg: cfg.gap;
        	sp = cfg.separator;
        	h -= cg;
        	if (sp) sp.setBounds(l, h, w, cg);
        }
        
        if(c.contexted)
        	c.releaseContext();
      }
      h -= t;

      c = this.east;
      if (c) {
        cfg = c.layoutCfg[this.type];
        cb = cfg.cbar;
        
        if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
        	w -= cg;
        	cb.setBounds(w+cpg, t, cg - dcpg, h);
        }else{
      		w -= cpg;
      	}
        
        if(!c.hidden && !c.contexted){
	        dd = c.getWidth(true);
	        w -= dd;
	        c.setBounds(w, t, c.width, h);
	        sp = cfg.separator;
	        cg = cfg.gap === undefined ? hg: cfg.gap;
	        w -= cg;
	        if (sp) sp.setBounds(w, t, cg, h);
        }
        if(c.contexted)
        	c.releaseContext();
      }

      c = this.west;
      if (c) {
      	cfg = c.layoutCfg[this.type];
      	cb = cfg.cbar;
      	if(cb && !cb.hidden){
        	cg = cfg.cgap === undefined ? cbg: cfg.cgap;
          cb.setBounds(l+cpg, t, cg - dcpg, h);
        	
        	l += cg;
        	w -= cg;
      	}else{
      		l += cpg;
      		w -= cpg;
      	}
      	
      	if(!c.hidden && !c.contexted){
	        dd = c.getWidth(true);
	        c.setBounds(l, t, c.width, h);
	        l += dd;
	        cg = cfg.gap === undefined ? hg: cfg.gap;
	        sp = cfg.separator;
	        w -= dd + cg;
	        if (sp) sp.setBounds(l, t, cg, h);
	        l += cg;
        }
        if(c.contexted)
        	c.releaseContext();
      }

      c = this.center;
      if (c) {
        c.setBounds(l, t, w, h);
      }
      
      CLayout.prototype.onLayout.call(this);
    },

    removeComponent: function(c) {
      var cfg = c.layoutCfg[this.type];
      this[cfg.dir] = null;
      var sp = cfg.separator;
      if (sp) {
      	sp.destoryComponent();
        cfg.separator = null;
      }
        
      var cb = cfg.cbar;
      if(cb){
        	cb.destoryComponent();
        	cfg.cbar = null;
      }
      return superclass.removeComponent.apply(this, arguments);
    },
    
    detach : function(){
    	var self = this;
    	this.invalidated = true;
    	CC.each(['east', 'sourth', 'west', 'north' , 'center'], function(){
    		if(self[this])
    			self.removeComponent(self[this]);
    	});
    	superclass.detach.call(this);
    }
  };
});

CLayout['border'] = CBorderLayout;
