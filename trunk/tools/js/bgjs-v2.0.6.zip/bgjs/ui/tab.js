CTemplate['CIconButton'] = '<table unselectable="on" class="g-unsel g-tab-item"><tbody><tr id="_ctx"><td class="tLe" id="_tLe"></td><td class="bdy"><nobr id="_tle" class="g-tle">选卡1</nobr></td><td class="btn" id="_btnC"><a href="javascript:fGo()" title="关闭" id="_trigger" class="g-ti-btn"></a></td><td class="tRi" id="_tRi"></td></tr></tbody></table>';

CC.create('CTabItem', CSelectedContainer, function(superclass) {

  function hideDDRBar() {
    Cache.put('CItemDDRBarUp', Cache.get('CItemDDRBarUp').display(false));
  }

  return {
    template: 'CIconButton',
    hoverCS: false,
    selectedCS: false,
    closeable: true,
    unselectable: true,
    container: '_ctx',
    ondropable: true,
    draggable: true,
    blockMode: '',

    initComponent: function() {
      superclass.initComponent.call(this);
      var c = this.cacheBtnNode = this.dom('_btnC');
      if (c) c.parentNode.removeChild(c);

      this._bindCloseEvent();
      this.setCloseable(this.closeable);

    },

    addButton: function(cfg) {
      var td = this.cacheBtnNode.cloneNode(true);
      cfg.view = td;
      td.id = cfg.id;
      cfg.iconNode = '_trigger';
      // apply the basic functionality to this button.
      var td = CBase.create(cfg);
      this.add(td);
      return td;
    },

    getContentPanel: function(autoCreate) {
      var p = this.panel;
      if (!p && autoCreate) {
        //iframe
        if (this.src) {
          p = this.panel = new CIFramePanel();
        }
        else {
          p = this.panel = new CPanel();
        }
      }
      return p;
    },

    _addNode: function(node) {
      if (this.buttonOrient != 'l') 
      	this.fly('_tRi').insertBefore(node).unfly();
      else this.fly('_tLe').insertAfter(node).unfly();
    },

    _closeTriggerFn: function() {
      this.parentContainer.close(this);
    },

    _bindCloseEvent: function() {
      var cls = this.$$(this.closeNode);
      if (!cls) {
        cls = this.addButton({
          id: '_clsBtn',
          blockMode: '',
          icon: 'g-ti-clsbtn'
        });
      }
      //close event.
      this.domEvent('click', this._closeTriggerFn, true, null, cls.view);
      this.domEvent('dblclick', this._closeTriggerFn, true);
      //不影响父容器mousedown事件.
      cls.view.onmousedown = Event.noUp;
    },

    setCloseable: function(b) {
      if (this.cacheBtnNode) {
        this.closeable = b;
        this.$('_clsBtn').display(b);
      }
      else superclass.setCloseable.call(this, b);

      return this;
    },

    dragStart: function() {
      var g = CGhost.instance;
      g.enableTip = true;
      g.setTitle('Drag \'' + this.title.truncate(10) + '\'');
    },

    dragSBOver: function(item) {
      var b = (item.parentContainer && item.parentContainer == this.parentContainer);
      if (b) {
        //显示方位条
        var pxy = this.absoluteXY(),
        bar = Cache.get('CItemDDRBarUp');
        pxy[0] -= 9;
        pxy[1] -= bar.getHeight(true) - 2;
        bar.setXY(pxy).display(true);
        Cache.put('CItemDDRBarUp', bar);
      }
      return b;
    },

    SBDrop: function(tar) {
      var ct = this.parentContainer;
      ct.insertBefore(tar, this);
      ct.select(tar);
    },

    dragSBOut: hideDDRBar,

    afterDrop: hideDDRBar
  };
});


CC.create('CTab', CSelectedPanel, function(superclass) {
  return {

    itemWidth: false,

    navKeyEvent: true,

    template: 'CAutoScrollLayout',

    movPanelCS: 'g-mov-tab',
    
    inherentCS :'g-tab',

    keyEventNode: '_scrollor',

    KEY_UP: Event.KEY_LEFT,

    KEY_DOWN: Event.KEY_RIGHT,
    maxH: 33,
    ItemClass: CTabItem,

    itemLoadCS: 'g-tabitem-loading',

    itemAutoConnect: false,
    
	  destoryItemOnclose : false,
	  /**
	   * 主要用于autoscrolllayout布局
	   */
	  layoutCfg : {
	      horizonMargin: 5,
        
        /**
         * 该值须与左边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navLeftWidth: 24,
        
        /**
         * 该值须与右边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navRightWidth: 24
	  },
	  
    initComponent: function() {
      superclass.initComponent.call(this);
      if (this.itemAutoConnect) {
        this.on('selected', this.onSelected);
      }
    },

    /**
         * 如果允许自动加载TabItem内容,监听选择事件并加载内容.
         * 当项选择后才会加载.
         */
    onSelected: function(item) {
      if ((!item.url && !item.src) || !this.itemAutoConnect) return;
      var p = item.panel;
      if (!p) {
        p = item.getContentPanel(true);
        p.defLoadSuccess = this._defItemLoadOnSuccess;
        if (this.contentPanel) this.contentPanel.add(p);
      }
      else if (p.loaded || p.busy) {
        return;
      }

      if (!p.loadIndicator) {
        //自定Loading标识
        p.getLoadIndicator({
          markIndicator: this.onItemMarkIndicator,
          stopIndicator: this.onItemStopIndicator
        });
      }

      //Panel指向TAB项的引用
      p.bindingTabItem = item;
      p.connect(item.src || item.url);
    },

    /**
         * TabItem内容面板加载时样式设置,这里主要在TabItem上显示一个loading图标.
         */
    onItemMarkIndicator: function() {
      var t = this.target.bindingTabItem;
      //此时的this为loading indicator.
      t.addClass(t.parentContainer.itemLoadCS);
      t._closeable = t.closeable;
      t.closeable = false;
    },

    onItemStopIndicator: function() {
      //此时的this为loading indicator.
      var tg = this.target,
      t = tg.bindingTabItem;
      if (t) {
        t.delClass(t.parentContainer.itemLoadCS);
        t.closeable = t._closeable;
        delete t._closeable;
        delete tg.bindingTabItem;
      }
    },

    /**
         * TabItem内容面板加载成功后默认的Ajax处理.
         */
    _defItemLoadOnSuccess: function(ajax) {
      this.wrapper.html(ajax.getText(), true);
    },

    /**
         * 关闭指定CTabItem,当只有一个CTabItem时忽略.
         */
    close: function(item) {
      item = this.$(item);
      if (!item.closeable || this.getDisc() == 1) return;
      if (this.fire('close', item) === false) return false;
      this.displayItem(item, 0);
      this.fire('closed', item);
	  if(this.destoryItemOnclose){
	  	if(item.panel){
			if(item.panel.view)
				item.panel.destoryComponent();
			else item.panel.parentNode.removeChild(item.panel);
		 }
		 this.remove(item);
		 item.destoryComponent();
	  }
    },

    //@override
    add: function(it) {
      if (superclass.add.call(this, it) === false) return false;
      //
      if (it.panel) {
      	it.panel.display(false);
      }

      if (this.itemWidth) it.setWidth(this.itemWidth);
      //this._ajust();
    },

    _ajust: fGo,

    //是否显示指定的TabItem,
    //参数a可为TabItem实例也可为TabItem的id,b为true或false.
    displayItem: function(a, b) {
      a = this.$(a);
      //Cann't change this attribute.
      if (!a.closeable && !b) {
        return false;
      }

      var isv = !a.hidden;

      superclass.displayItem.call(this, a, b);

      if (isv != b) {
        this._ajust();
      }

      //切换下一个CTabItem
      if (!b && this.selected == a) {
        var idx = this.indexOf(a);
        var tmp = idx - 1;
        var chs = this.children;
        while (tmp >= 0 && (chs[tmp].hidden || chs[tmp].disabled)) {
          tmp--;
        }
        if (tmp >= 0) {
          this.select(chs[tmp]);
          return;
        }

        tmp = chs.length;
        idx += 1;
        while (idx < tmp && (chs[idx].hidden || chs[idx].disabled)) {
          idx++;
        }
        if (idx < tmp) {
          this.select(chs[idx]);
        }
      }
    },

    //选择某个TabItem,
    //参数a可为TabItem实例也可为id.
    //b为强制选择
    onSelect: function(a) {
      superclass.onSelect.call(this, a);
      a = this.$(a);
      for (var i = 0, len = this.size(); i < len; i++) {
        var ch = this.children[i];
        if (ch != a && ch.panel) {
        	var p = ch.panel;
          if (!p.hidden)
          	p.display(false);
        }
      }

      if (!a) return;
      a.show();
      if (a.panel){
      	(function(){
        	a.panel.display(true);
      	}).timeout(20);
      }
    },

    //返回显示的TabItem个数.
    getDisc: function() {
      var cnt = 0;
      var chs = this.children;
      for (var i = 0, len = chs.length; i < len; i++) {
        if (!chs[i].hidden) {
          cnt++;
        }
      }
      return cnt;
    }
  };
});