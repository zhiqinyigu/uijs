/**
 * 容器控件遮掩层
 * @cfg target {CPanel}
 * @author Rock
 */
CC.create('CMask', CBase, {
    inherentCS: 'g-modal-mask',
	template : 'div',
	initComponent : function(){
		CBase.prototype.initComponent.call(this);
		if(this.target){
			this.bindTarget(this.target);
		}
		
		this.domEvent('mousedown', this.onMaskResponsed, true);
	},
	
	onMaskResponsed : function(){
	   this.fire('active', this);
	   if(this.onActive)
	   	this.onActive;
	},
	
	attachTarget : function(target){
	  this.target = target;
	  if(this.target.eventable){
	  	this.target.on('resized', this.onTargetResized, this);
	  }
	  this.appendTo(this.target);
	  var f = CC.fly(this.target);
	  this.setXY(0,0).setSize(f.getSize(true));
	  f.unfly();
	  return this;
	},
	
	detachTarget : function(){
	  if(this.target.eventable){
	  	this.target.un('resized', this.onTargetResized);
	  }
	  this.del();
	  this.target = null;
	  return this;
	},
	
	onTargetResized : function(a, b, c, d) {
		this.setSize(c, d);
	},
	
	destoryComponent : function(){
		if(this.target){
			this.detachTarget();
		}
		CBase.prototype.destoryComponent.call(this);
	}
});

CBase['masker'] = CMask;