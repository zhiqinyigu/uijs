CTemplate['CIFramePanel'] = '<iframe class="g-framepanel" frameBorder="no" scrolling="auto" hideFocus=""></iframe>';
CC.create('CIFramePanel', CPanel, {
	
	template : 'CIFramePanel',
	
	container : undefined,
	
	traceResize : false,
	
	traceLoad : true,
	
	onRender : function(){
		CPanel.prototype.onRender.call(this);
		var c = this.parentContainer;
		
		if(this.traceResize){
			c.on('resized', this.onContainerResize, this);
			this.onContainerResize(false, false, c.wrapper.getWidth(true), c.wrapper.getHeight(true));
	  }
	  
		if(this.traceLoad){
			this.domEvent(CC.isIE?'readystatechange':'load', this.traceFrameLoad,null, null, this.wrapper.view);
		}
		
		//����ҳ��
		if(this.autoConnect && (this.src || this.url)){
			this.connect();
		}
	},
	//
	// ʵ����ʱ����д�÷���,���Զ���IFRAME����.
	//
	onContainerResize : function(a,b,c,d){
		this.setSize(a, b);
	},
	
  //
  //@override IFRAME��AJAX���ط�ʽ��ͬ
  //
  connect: function(url, cfg) {
    if(!url)
      url = this.url || this.src;
    else this.url = url;
    	
    this.loaderConfig = cfg;
    
    if (!this.indicatorDisabled && !this.loadIndicator) {
      this.getLoadIndicator();
    }

		try{
			this.fire('open');
			var v = this.wrapper.view;
			(function(){v.src = url;}).timeout(0);
		}catch(e){
			console.warn(e);
		}
		
    return this;
  },
  
  onFrameLoad : function(evt){
  	try{
  		this.fire('success', evt);
  		if(this.loaderConfig && this.loaderConfig.onsuccess){
  			this.loaderConfig.onsuccess.call(this, evt);
  		}
    }catch(e){console.warn(e);}
  	this.fire('final');
  	if(this.loaderConfig && this.loaderConfig.onfinal){
  		this.loaderConfig.onfinal.call(this, evt);
  	}
  },
  
	traceFrameLoad : function(evt){
		var status = Event.element(evt).readyState || evt.type;
	  switch(status){
	  	case 'loading':  //IE  has several readystate transitions
	    	if(!this.busy)
	    		this.fire('open', evt);
		  break;
		  //
		  //���û��ֶ�ˢ��FRAMEʱ���¼�Ҳ�ᷢ��
	    //case 'interactive': //IE
	    case 'load': //Gecko, Opera
	    case 'complete': //IE
			  //May be ie would do a clean action before a new page loaded.
			  if((CC.ie && (this.src||this.url) != this.view.src))
			  	return;
			  this.onFrameLoad(evt);
	    break;
	  }
	},
	
	getLoadIndicator : function(opt){
		opt = CC.extendIf(opt, {markIndicator:fGo, stopIndicator:fGo});
		CPanel.prototype.getLoadIndicator.call(this , opt);
	},
	
	/**
	 * ���ݽ��id����IFrameҳ����Ԫ��dom���.
	 * ע:������IFrame������ɺ�ſ���������.
	 * @function
	 * @return {DOMElement}
	 */
	$ : function(id){
		return CC.frameDoc(this.view).getElementById(id);
	}
}
);
