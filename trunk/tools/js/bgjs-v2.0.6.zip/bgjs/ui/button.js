CTemplate['CButton'] = '<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="g-btn-l"><i>&nbsp;</i></td><td class="g-btn-c"><em unselectable="on"><button type="button" class="g-btn-text" id="_tle"></button></em></td><td class="g-btn-r"><i>&nbsp;</i></td></tr></tbody></table>';
CTemplate['CVerticalButton'] = '<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td class="g-btn-l"><i>&nbsp;</i></td></tr><tr><td class="g-btn-c"><em unselectable="on"><button type="button" class="g-btn-text" id="_tle"></button></em></td></tr><tr><td class="g-btn-r"><i>&nbsp;</i></td></tr></tbody></table>';
/**
 *@class CButton
 *@extend CBase
 */
CC.create('CButton', CBase, function(superclass){
    return {
        iconNode: '_tle',
        focusNode: '_tle',
        hoverCS: 'g-btn-over',
        clickCS: 'g-btn-click',
        iconCS: 'g-btn-icon',
        template: 'CButton',
        focusCS: 'g-btn-focus',
        tip : false,
        disableNode: '_tle',
        inherentCS: 'g-btn',
        blockMode: '',
        _onClick: function(){
            if (this.onClick) 
                this.onClick.call(this);
        },
        
        initComponent: function(){
            superclass.initComponent.call(this);
            if (!this.title || this.title == '') 
                this.addClass(this.noTxtCS || 'g-btn-notxt');
            this.element = this.dom('_tle');
            this.domEvent('mousedown', this._gotFocus);
            this.domEvent('click', this._onClick);
            if (this.focusCS) 
                this.bindFocusStyle(this.focusCS);
            if (this.dockable && this.docked) {
                this.setDocked(true);
            }
        },
        
        setDocked: function(b){
            this.docked = b;
            b ? this.addClass(this.clickCS) : this.delClass(this.clickCS);
            return this;
        },
        
        _gotFocus: function(ev){
            try {
                this.element.focus();
            } 
            catch (e) {
            }
        },
        
        mouseupCallback: function(){
            if (this.dockable) {
                this.docked = !this.docked;
                return this.docked;
            }
        }
    };
});

CC.create('CVerticalButton', CBase, CButton.constructors, {
  inherentCS: 'g-vbtn',
  hoverCS: 'g-vbtn-over',
  clickCS: 'g-vbtn-click',
  noTxtCS : 'g-vbtn-notxt',
  iconCS: 'g-vbtn-icon',
  template: 'CVerticalButton',
  focusCS: 'g-vbtn-focus',
  qtip : true,
  tip : true,
  brush : function(v){
  	if(!v || CC.ie)
  		return v;
  	v = v.toString().truncate(3,'..');
  	var ss = [];
  	for(var i=0,len=v.length-1;i<len;i++){
  		ss.push(v.charAt(i)+'<br>');
  	}
  	return ss.join('');
  }
});

CFormElement['button'] = CButton;
CFormElement['vbutton'] = CVerticalButton;
CBase['vbutton'] = CVerticalButton;