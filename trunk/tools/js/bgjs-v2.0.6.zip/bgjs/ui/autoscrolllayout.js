/**
 * 该布局管理器可以在不影响原有面板的情况下使得子项被遮掩后出现导航条，当且当前选择项终始处于可视范围内。
 * 利用该布局管理器布局的控件有<code>CToolbar</code>,<code>CTab</code>.
 * 一个容器应该具备以下特性才能获得正确的布局：
 * html模板结构：参见CAutoScrollLayout模板
 * @since v2.0.4
 * @author Rock
 */

CTemplate['CAutoScrollLayout'] = '<div class="g-panel"><div class="auto-margin" id="_margin"><a href="javascript:fGo()" id="_rigmov" class="auto-rigmov" style="right:0px;"></a><a href="javascript:fGo()" style="left:0px;" id="_lefmov" class="auto-lefmov"></a><div class="auto-scrollor" id="_scrollor" tabindex="1" hidefocus="on"><div class="auto-offset" id="_wrap"></div></div></div></div>';

CC.create('CAutoScrollLayout', CLayout, function(superclass){
    /**
     * 导航按钮点击事件,当键按下时小于300ms就被看作一次点击处理，
     * 将触发移至下一项可见，否则当按下处理，不断移动可视范围直至松开键。
     */
    function onNavMousedown(){
        var ly = this.parentContainer.layout;
        var mov = this;
        ly.mousedownTimer = (function(){
        
            var hids;
            if (ly.lefMov == mov) {
                hids = ly.getHorizonOutOfViewItems('l');
                if (hids.length) 
                    ly.scrollTo(hids[0][1]);
            }
            else {
                hids = ly.getHorizonOutOfViewItems('r');
                if (hids.length) 
                    ly.scrollTo(hids[0][1]);
            }
            
            if (ly.mousedownTimer != null) {
                clearTimeout(ly.mousedownTimer);
                ly.mousedownTimer = null;
            }
        }).timeout(300);
    }
    
    /**
     * @see onNavMousedown
     */
    function onNavMouseup(){
        var ct = this.parentContainer, ly = ct.layout;
        if (ly.mousedownTimer != null) {
            clearTimeout(ly.mousedownTimer);
            ly.mousedownTimer = null;
            var first;
            if (ly.scrollTimer == null) {
                first = this.view.id == '_lefmov' ? ly.getHorizonOutOfViewItems('l') : ly.getHorizonOutOfViewItems('r');
                if (first.length == 0) 
                    return;
                first[first.length - 1][0].scrollIntoView(ct.scrollor, true);
            }
        }
        else {
            ly.resetScrollTimer();
        }
    }
    
    /**
     * 将子项滑动到容器可视范围内。
     * 该方法重写子项类位于<code>CBase</code>类中的scrollIntoView方法，
     * 使得以动画形式滑动至容器可视处.
     * 注意:子项类原有方法scrollIntoView将被覆盖！
     * @override
     * @param {Mixed} scrollor 子项将滚动到该元素的可视范围内
     */
    function itemScrollIntoView(scrollor){
        var ly = this.parentContainer.layout;
        var to = this.getHiddenAreaOffsetHori(scrollor);
        if (to === false) 
            return;
        ly.scrollTo(to);
    }
    
    return {
    	  /**
    	   * 延迟布局.
    	   */
    	   
    	  defferLayout : 0,
        /**
         * @cfg {Boolean} CLayout类设置，通知容器当子项remove, insert, display时重新布局.
         */
        layoutOnChange: true,
        
        /**
         * @cfg {Number} 子项移动的累加速度
         */
        acceleration: 0.5,
        
        /**
         * 该值须与 CSS 中的.auto-margin值保持同步,因为这里margin并不是由JS控制.
         * 出于性能考虑,现在把它固定下来。
         * @cfg horizonMargin {Number} 水平方向空位大小
         */
        horizonMargin: 5,
        
        /**
         * 该值须与左边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navLeftWidth: 24,
        
        /**
         * 该值须与右边导航按钮宽度一致,出于性能考虑,现在把它固定下来。
         * @cfg {Number} navLeftWidth
         */
        navRightWidth: 24,
        
        ctCS : 'g-autoscroll-ly',

        disabledLeftMoverCS: 'auto-lefmov-disabled',

    		disabledRightMoverCS: 'auto-rigmov-disabled',
    
        /**
         * 当子项添加到容器时改写子项的scrollIntoView方法并重新布局容器。
         * @override
         * @param {CBase} comp
         */
        addComponent: function(comp){
            superclass.addComponent.apply(this, arguments);
            //override & replace
            comp.scrollIntoView = itemScrollIntoView;
            this.doLayout();
        },
        
        /**
         * 布局容器方法的主体实现
         * @override
         * @param {Object} a 当前容器宽度或false 或 undefined
         * @param {Object} b 当前容器高度或false 或 undefined
         * @param {Object} c 当前容器的wrapper宽度或false 或 undefined
         * @param {Object} d 当前容器的wrapper高度或false 或 undefined
         * @param {Object} dx 当前容器resize后在x轴的引起的增量
         * @param {Object} dy 当前容器resize后在y轴的引起的增量
         */
        onLayout: function(a, b, c, d, dx, dy){
            superclass.onLayout.apply(this, arguments);
            var ct = this.container, scrollor = ct.scrollor, selected = ct.selected;
            //
            // IE怪胎下固定宽度
            //
            if (CC.ie) {
                var w = a || ct.getWidth() - (this.marginLeft||this.horizonMargin) - (this.marginRight||this.horizonMargin); //margin of wrap.
                ct.fly('_margin').setWidth(w).unfly();
                w -= this.navLeftWidth + this.navRightWidth; //margin of nav bar.
                CC.fly(scrollor).setWidth(w).unfly();
            }
            
            // 是否由resized引起的布局
            if (a === undefined) {
                if (selected) {
                    this.checkMover(false);
                    selected.scrollIntoView(scrollor);
                }
                else 
                    this.checkMover();
                return;
            }
            
            var it, offR = false;
            if (dx) {
                //如果向右扩充
                if (dx > 0) {
                    //如果右边有隐藏，尽量显示,否则显示左边
                    it = this.getNextHiddenChild()[1];
                    
                    if (it === false) 
                        scrollor.scrollLeft = scrollor.scrollLeft - dx;
                }
                //向左缩小,不改变scrollLeft
                if (selected) {
                    this.checkMover(false);
                    selected.scrollIntoView(scrollor, true);
                }
                else 
                    this.checkMover();
            }
        },
        
        /**
         * 绑定布局管理器到容器控件。
         * @param {CBase} ct 布局管理器对应的容器控件
         */
        attach: function(ct){
            superclass.attach.call(this, ct);
            ct.getWrapperInsets = fGo;
			// 重置margin结点值，忽略CSS设置的值，使得当CSS值不同的不引起布局的混乱。
			var mgst = ct.dom('_margin').style;
			mgst.marginLeft = (this.marginLeft||this.horizonMargin) + 'px';
			mgst.marginRight = (this.marginRight||this.horizonMargin) + 'px';
            
			if (!ct.scrollor) 
                ct.scrollor = ct.dom('_scrollor');
            var lm = this.lefMov = ct.$$('_lefmov');
            var rm = this.rigMov = ct.$$('_rigmov');
            lm.disabledCS = this.disabledLeftMoverCS;
            rm.disabledCS = this.disabledRightMoverCS;
            lm.domEvent('mousedown', onNavMousedown).domEvent('mouseup', onNavMouseup);
            rm.domEvent('mousedown', onNavMousedown).domEvent('mouseup', onNavMouseup);
            ct.hscroll = true;
        },
        
        /**
         * 移除移动子项到可视范围的定时器.
         */
        resetScrollTimer: function(){
            if (this.scrollTimer) {
                clearTimeout(this.scrollTimer);
                this.scrollTimer = null;
            }
            this.checkMover();
        },
        
        /**
         * 将滚动条滑动至指定处。
         * @param {Number} to scrollor结点的scrollLeft值.
         */
        scrollTo: function(to){
            if (this.scrollTimer != null) 
                this.resetScrollTimer();
            var sc = this.container.scrollor;
            var current = sc.scrollLeft;
            var step = to - current;
            var seed = step / Math.abs(step) * this.acceleration;
            if (seed == 0) 
                return;
            var self = this;
            step = seed;
            this.scrollTimer = (function(){
                current = Math.floor(current + step);
                if (seed > 0) {
                    if (current > to) 
                        current = to;
                }
                else 
                    if (current < to) {
                        current = to;
                    }
                
                if (current == to) {
                    self.resetScrollTimer();
                }
                sc.scrollLeft = current;
                step += seed;
            }).timeout(this.scrollTimerInterval || 33, true);
        },
        
        /**
         * 检查导航按钮状态，是否应显示或禁用。
         */
        checkMover: function(timeout){
            var self = this;
            var func = (function(){
                var ct = self.container, has = self.getNextHiddenChild();
                self.lefMov.disable(!has[0]);
                self.rigMov.disable(!has[1]);
                
                if (!has[0] && !has[1]) {
                    ct.delClass(ct.movPanelCS);
                }
                
                else 
                    ct.addClassIf(ct.movPanelCS);
            });
            if (timeout !== false) 
                func.timeout(100);
            else 
                func();
        },
		
        /**
         * 返回左右两边下一个被遮掩的子项。
         * 注:不包括隐藏的
         */
        getNextHiddenChild: function(){
            var its = this.container.children, it, l = false, r = false, i = 0, j, len = its.length, sc = this.container.scrollor;
            for (; i < len; i++) {
                it = its[i];
                if (it.hidden) 
                    continue;
                if (it.getHiddenAreaOffsetHori(sc) !== false) {
                    l = it;
                }
                i++;
                break;
            }
            
            for (j = len - 1; j >= i; j--) {
                it = its[j];
                if (it.hidden) 
                    continue;
                if (it.getHiddenAreaOffsetHori(sc) !== false) {
                    r = it;
                }
                break;
            }
            return [l, r];
        },
        
        /**
         * 获得水平方向被遮掩的项列表。
         * 注:不包括隐藏的。
         * @param {Object} dir 左边或右边或两边都返回。'l'或'r'或者undefined.
         */
        getHorizonOutOfViewItems: function(dir){
            var ct = this.container, scrollor = ct.scrollor;
            var ls = [], rs = [], its = ct.children, len = its.length, it, i = 0, j, off;
            //left out of view items
            if (!dir || dir == 'l') {
                for (; i < len; i++) {
                    it = its[i];
                    if (it.hidden) 
                        continue;
                    off = it.getHiddenAreaOffsetHori(scrollor);
                    if (off === false) {
                        i++;
                        break;
                    }
                    ls[ls.length] = [it, off];
                }
            }
            
            //right out of view items
            if (!dir || dir == 'r') {
                for (j = len - 1; j >= i; j--) {
                    it = its[j];
                    if (it.hidden) 
                        continue;
                    off = it.getHiddenAreaOffsetHori(scrollor);
                    if (off === false) 
                        break;
                    rs[rs.length] = [it, off];
                }
            }
            
            if (!dir) 
                return [ls, rs];
            
            return dir == 'l' ? ls : rs;
        }
        
    };
});

CLayout['autoscroll'] = CAutoScrollLayout;