CC.create('CCardLayout', CLayout, {
	layoutChild : function(item){
		var sz = this.container.wrapper.getSize(true);
		item.setSize(sz);
	}
});

CLayout['card'] = CCardLayout;

CC.create('CQQLayout', CLayout, function(superclass){
	return {
		addComponent : function(comp, cfg){
			comp.makePositioned('absolute').setLeft(0);
			if(cfg && cfg.collapsed === false){
				comp.fold(false, true);
				this.frontOne = comp;
			}else {
				comp.fold(true, true);
			}
			superclass.addComponent.apply(this, arguments);
		},
		
		onLayout : function(){
			superclass.onLayout.apply(this, arguments);
			var c = this.frontOne,
			    ct = this.container, 
			    ch = ct.wrapper.height, 
			    cw = ct.wrapper.width,
			    i, it, t,j,
			    its = ct.children, 
			    len = ct.size();
			//由上而下
			for(i=0, t = 0;i<len;i++){
				it = its[i];
				
				if(it.hidden)
					continue;
				
				if(it == c)
					break;
					
				it.setBounds(false, t, cw, it.minH);
				ch -= it.height;
				t += it.height;
			}
			
			if(c)
				c.setTop(t);
			//由下而上
			for(j=len-1, t = ct.wrapper.height;j>i;j--){
				it = its[j];
				t -= it.minH;
				it.setBounds(false, t, cw, it.minH);
				ch -= it.height;
			}
			
			if(c)
				c.setSize(cw, ch);
		},
		
		collapse : function(comp, b){
			var cfg = comp.layoutCfg[this.type];
			if(cfg.collapsed == b)
				return;
			
			if(this.frontOne && this.frontOne !== comp){
				if(this.frontOne.fold)
					this.frontOne.fold(true, true);
				this.frontOne.layoutCfg[this.type].collapsed = true;
			}
			if(comp.fold)
				comp.fold(b, true);
			cfg.collapsed = b;
			this.frontOne = b?null:comp;
      this.doLayout();
		}
	};
});

CLayout['qq'] = CQQLayout;

/**
 * 行布局,该布局将对子控件宽度/高度进行布局,不干预控件坐标.
 * 控件配置方面:
 * <li>auto : 自动宽高,不进行干预</li>
 * <li>具体宽/高 : 如50px</li>
 * <li>leading : 平分宽高</li>
 */
CC.create('CRowLayout', CLayout, function(superclass) {

  return {
    onLayout: function() {
      var wr = this.container.wrapper;
      var w = wr.getWidth(true),
      h = wr.getHeight(true),
      i,len, it, its = this.items, cfg, ty = this.type, iv;
      //y direction
      var leH = [], leW = [];
      for(i=0,len=its.length;i<len;i++){
      	it = its[i];
      	if(it.hidden)
      		continue;
      	
      	cfg = it.layoutCfg[ty];
      	switch(cfg.h){
      		case 'auto' :
      		case undefined : 
      			h-=it.getHeight(true);
      			break;
      		case 'lead' :
      			leH[leH.length] = it;
      			break;
      		default :
      		  iv = cfg.h;
      		  if(CC.isNumber(iv)){
      		  	if(iv>=1){
      		  		it.setHeight(iv);
      		  		//may be maxH reached.
      		  		h-=it.height
      		  	}else if(iv>=0){
      		  		iv = Math.floor(iv*h);
      		  		it.setHeight(iv);
      		  		//may be maxH reached.
      		  		h-=it.height;
      		  	}
      		  }
      	}
      	it.setWidth(w);
       }
       
       for(i=0,len=leH.length;i<len;i++){
      		it = leH[i];
      		cfg = it.layoutCfg[ty];
      		iv = cfg.len;
      		if(CC.isNumber(iv)){
      		  	iv = Math.floor(iv*h);
      		  	it.setHeight(iv);
      		  	h-=it.height
      		}else {
      			iv = Math.floor(h/(len-i));
      			it.setHeight(iv);
      			h-=it.height;
      		}
       }
       
      for(i=0,len=its.length;i<len;i++){
      	it = its[i];
      	if (!it.rendered) it.render();
      }
    },
    
    addComponent : function(c, cfg){
      this.items[this.items.length] = c;
      superclass.addComponent.call(this, c, cfg);
    },
    
    attach: function(c) {
      superclass.attach.call(this, c);
      this.items = [];
    }
  };
});

CRowLayout.prototype.layoutChild = CRowLayout.prototype.onLayout;

CLayout['row'] = CRowLayout;

CLayout['row2'] = CQQLayout;