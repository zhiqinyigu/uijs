/**
 * 浮动提示框.
 */

if(!CC.ie)
  CTemplate['CFloatTip'] = '<div class="g-float-tip g-clear"><div class="tipbdy"><div id="_tle" class="important_txt"></div><div id="_msg" class="important_subtxt"></div></div><div class="btm_cap" id="_cap"></div></div>';
else 
	CTemplate['CFloatTip'] = '<table class="g-float-tip g-clear"><tr><td><table class="tipbdy"><tr><td id="_tle" class="important_txt"></td></tr><tr><td id="_msg" class="important_subtxt"></td></tr></table></td></tr><tr><td class="btm_cap" id="_cap"></td></tr></table>';
CC.create('CFloatTip', CPanel,function(superclass){

var instance;
var globalPos = [-10000,-10000];
var docEvtBinded = false;

function onDocMousemove(event){
	globalPos = Event.pageXY(event || window.event);
}

CUtil.ftip = function(msg, title, proxy, getFocus, timeout){
	if(!instance)
		instance = new CFloatTip({showTo:document.body, autoRender:true});
	CC.fly(instance.tail).show().unfly();
	instance.show(msg, title, proxy, getFocus, timeout);
	
	return instance;
};
  
CUtil.qtip = function(proxy, msg){
	if(!instance)
		instance = new CFloatTip({showTo:document.body, autoRender:true});
	instance.tipFor(proxy, msg);
};

return {
  /**
   *@cfg {Number} timeout = 2500 设置消失超时ms, 如果为0 或 false 不自动关闭.
   */
  timeout: 2500,
	
	delay : 500,
	
	type : "CFloatTip",
	
	template : 'CFloatTip',
	/**
	 *@cfg {Boolean} reuseable = false 是否可复用
	 */
	reuseable : true,
	
	shadow:true,
  
  qmode : false,
  
  zIndex : 10002,
  
  hoverTipCS : 'g-small-tip',
  
  initComponent: function() {
    CPanel.prototype.initComponent.call(this);
    if(this.msg)
    	this.setMsg(this.msg);
    this.tail = this.dom('_cap');
    this.setXY(-10000,-10000).setZ(this.zIndex);
    if(this.qmode)
    	this._returnQtip();
    else this._returnFtip();
  }
  ,	
  
  //@override
  display : function(b) {
    if(arguments.length == 0){
    	return CPanel.prototype.display.call(this);
    }

    //无论怎样,先清除前面一个timout
    this.killTimer();

    CPanel.prototype.display.call(this, b);
    
    if(!b)
    	return this;
    
    if(this.timeout)
    	this.timerId = this._timeoutCall.bind(this).timeout(this.timeout);
    return this;
  }
  ,
  
  setRightPosForTarget : function(target){
  	var f = CC.fly(target);
	    var xy = CC.fly(target).absoluteXY();
	    this.setXY(xy[0] - 2, xy[1] - this.view.offsetHeight - 2);
	  f.unfly();
  },
  
  setRightPosForHover : function(xy){
  	this.setXY(xy[0], xy[1] + 24);
  },
  
  _timeoutCall : function(){
  	CPanel.prototype.display.call(this, false);
  	this.killTimer(true);
  	if(this.ontimeout)
  		this.ontimeout();
  },
  
  /**
   * @param {boolean} check 是否作回收(reuseable)检查
   */
  killTimer : function(check){
    if(this.timerId){
    		clearTimeout(this.timerId);
    		this.timerId = false;
    }
    
    if(!this.reuseable && check)
  		this.destoryComponent();
  },
  
  setMsg: function(msg, title) {
  	this.fly('_msg').html(msg).unfly();
    if(title)
    	this.setTitle(title);
    return this;
  },
  
  /**
   * @override
   * @param {Mixed} target
   */
  show : function(msg, title, target, getFocus, timeout){
  	if(arguments.length == 0)
  		return CPanel.prototype.show.call(this);
  		
  	this.setMsg(msg, title);
  	
  	if(timeout !== undefined)
  		this.timeout = timeout;
  	
  	if(this.qmode)
  		this._returnFtip();
  	
  	this.display(true);
  	if(target){
    	this.setRightPosForTarget(target);
    	if(getFocus)
  			CC.fly(target).focus(true).unfly();
    }
  	return this;
  },
  
  _returnFtip : function(){
  	this.qmode = false;
    this.delClass(this.hoverTipCS);
  	if(this.shadow){
  		this.shadow.inpactY = -1;
  		this.shadow.inpactH = -12;
  	}
  },
  
  _returnQtip : function(){
  	this.qmode = true;
    this.addClassIf(this.hoverTipCS);
  	if(this.shadow){
  		this.shadow.inpactY = CShadow.prototype.inpactY;
  		this.shadow.inpactH = CShadow.prototype.inpactH;
  	}
  },
  
  tipFor : function(proxy, msg, title){
  	CC.fly(proxy)
  	  .domEvent('mouseover', 
  	    function(evt){
  	    	var self = this;
					if(!docEvtBinded){
						Event.addListener(document, 'mousemove', onDocMousemove);
						docEvtBinded = true;
					}
					
					this.timerId = (function(){
						self.setMsg(proxy.qtip || proxy.tip || proxy.title || msg, title);
						CC.fly(self.tail).hide().unfly();
  	    		if(!self.qmode)
  	    			self._returnQtip();
  	    		self.display(true)
  	    		    .setRightPosForHover(globalPos);
					}).timeout(this.delay);
					
  	  	}, true, this)
  	  .domEvent('mouseout', this.onTargetMouseout, true, this)
  	  .unfly();
  },
	
	onTargetMouseout : function(evt){
		if(this.qmode)
		   this.display(false);
		if(docEvtBinded){
			Event.removeListener(document, 'mousemove', onDocMousemove);
			docEvtBinded = false;
		}
	},
	
  getInstance : function(){
  	return instance;
  }
};
});