/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/decorator.js
 * author: berg
 * version: 1.0.0
 * date: 2010/08/17 
 */


///import baidu.ui;

/**
 * 装饰器控件，包定义
 */
baidu.ui.decorator = baidu.ui.decorator || {};
