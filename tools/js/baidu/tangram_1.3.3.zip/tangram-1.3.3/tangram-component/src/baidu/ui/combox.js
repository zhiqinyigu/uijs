///import baidu.ui;
//instances用于存放实例guid及其状态
baidu.ui.combox = baidu.ui.combox || {instances : {}};