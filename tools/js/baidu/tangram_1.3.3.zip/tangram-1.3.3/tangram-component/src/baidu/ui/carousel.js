/*
 * Tangram
 * Copyright 2010 Baidu Inc. All rights reserved.
 * 
 * path: ui/carousel.js
 * author: linlingyu
 * version: 1.0.0
 * date: 2010-09-09
 */
//import baidu.ui
/**
 * 定义名字空间
 * @type 
 */
baidu.ui.carousel = baidu.ui.carousel || {};