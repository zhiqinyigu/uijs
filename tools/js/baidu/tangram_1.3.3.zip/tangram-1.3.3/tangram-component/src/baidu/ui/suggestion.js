/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/suggestion.js
 * author: berg
 * version: 1.1.0
 * date: 2010-06-01 庆祝儿童节，晚上升级suggestion
 */

///import baidu.ui;

/**
 * 定义名字空间
 */
baidu.suggestion = baidu.ui.suggestion = baidu.ui.suggestion || {} ;
