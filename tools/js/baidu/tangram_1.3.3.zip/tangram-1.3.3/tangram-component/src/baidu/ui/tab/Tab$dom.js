/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/tab/Tab$dom.js
 * author: berg
 * version: 1.0.0
 * date: 2010-06-28
 */


///import baidu.ui.tab.Tab;
///import baidu.dom.setAttr;
///import baidu.dom.g;
///import baidu.array.each;

/**
 * addon
 *
 * 让tab可以直接从dom开始渲染
 */
