/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/button.js
 * author: zhangyao
 * version: 1.0.0
 * date: 2010-08-05
 */

///import baidu.ui;

/**
 * 定义名字空间
 */
baidu.ui.button = baidu.ui.button || {} ;
