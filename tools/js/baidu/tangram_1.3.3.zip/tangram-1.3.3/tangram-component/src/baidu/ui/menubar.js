///import baidu.ui;
//instances用于存放实例guid及其状态
baidu.ui.menubar = baidu.ui.menubar || {instances : {}};