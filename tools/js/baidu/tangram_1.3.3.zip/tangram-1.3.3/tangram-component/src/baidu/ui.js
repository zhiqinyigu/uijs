///import baidu;

baidu.ui = baidu.ui || {};
