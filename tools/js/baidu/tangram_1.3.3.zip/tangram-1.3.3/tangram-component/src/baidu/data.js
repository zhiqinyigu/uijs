/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/tab.js
 * author: berg
 * version: 1.0.0
 * date: 2010-06-13 
 */

///import baidu;

baidu.data = baidu.data || {};
