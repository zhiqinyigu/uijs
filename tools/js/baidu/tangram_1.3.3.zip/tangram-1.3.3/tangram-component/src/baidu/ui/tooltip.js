/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/tooltip.js
 * author: rocy
 * version: 1.0.0
 * date: 2010-07-14
 */

///import baidu.ui;

baidu.ui.tooltip = baidu.ui.tooltip || {mainId : null};
