/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/popup.js
 * author: rocy
 * version: 1.0.0
 * date: 2010-08-12
 */

///import baidu.ui;

/**
 * 定义名字空间
 * instances用于存放实例guid及其状态
 */
baidu.ui.popup = baidu.ui.popup || {instances : {}};
