/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/smartPosition.js
 * author: berg
 * version: 1.0.0
 * date: 2010-07-14
 */

///import baidu.ui;

/**
 * 定义名字空间
 */
baidu.ui.smartPosition = baidu.ui.smartPosition || {};
