///import baidu;

baidu.fx = baidu.fx || {} ;

