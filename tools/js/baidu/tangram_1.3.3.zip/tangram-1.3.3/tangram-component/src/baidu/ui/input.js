/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/input.js
 * author: zhangyao
 * version: 1.0.0
 * date: 2010-08-27
 */

///import baidu.ui;

/**
 * 定义名字空间
 */
baidu.ui.input = baidu.ui.input || {} ;
