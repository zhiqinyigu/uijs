/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: ui/tab.js
 * author: berg
 * version: 1.0.0
 * date: 2010-06-13 明天端午节
 */

///import baidu.ui;

/**
 * 定义名字空间
 */
baidu.ui.tab = baidu.ui.tab || {} ;
