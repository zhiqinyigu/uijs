/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/url.js
 * author: erik
 * version: 1.1.0
 * date: 2009/11/16
 */

///import baidu;
/**
 * @namespace baidu.url 操作url的方法。
*/
baidu.url = baidu.url || {};
