/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 *
 * path: baidu/array.js
 * author: erik
 * version: 1.1.0
 * date: 2009/12/02
 */

///import baidu;

/**
 * @namespace baidu.array 操作数组的方法。
 */

baidu.array = baidu.array || {};
