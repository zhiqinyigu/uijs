/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/lang/_instances.js
 * author: meizz, erik
 * version: 1.1.0
 * date: 2009/12/1
 */

///import baidu.lang;


/**
 * 所有类的实例的容器
 * key为每个实例的guid
 */

window[baidu.guid]._instances = window[baidu.guid]._instances || {};
