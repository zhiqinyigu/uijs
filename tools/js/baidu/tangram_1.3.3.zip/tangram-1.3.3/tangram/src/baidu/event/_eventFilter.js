/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/event/_eventFilter.js
 * author: rocy
 * version: 1.0.0
 * date: 2010/10/29
 */
///import baidu.event;

baidu.event._eventFilter = baidu.event._eventFilter || {};
