/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/object.js
 * author: erik
 * version: 1.1.0
 * date: 2009/11/15
 */

///import baidu;
/**
 * @namespace baidu.object 操作原生对象的方法。
 */
baidu.object = baidu.object || {};
