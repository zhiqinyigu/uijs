/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/browser.js
 * author: allstar, erik
 * version: 1.1.0
 * date: 2009/12/02
 */

///import baidu;

/**
 * @namespace baidu.browser 判断浏览器类型和特性的属性。
 */
baidu.browser = baidu.browser || {};
