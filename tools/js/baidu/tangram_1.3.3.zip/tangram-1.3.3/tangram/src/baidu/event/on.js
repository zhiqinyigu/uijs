/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/event/on.js
 * author: erik
 * version: 1.1.0
 * date: 2009/12/16
 */

///import baidu.event._listeners;
///import baidu.dom._g;

/**
 * 为目标元素添加事件监听器
 * @name baidu.event.on
 * @function
 * @grammar baidu.event.on(element, type, listener)
 * @param {HTMLElement|string|window} element 目标元素或目标元素id
 * @param {string} type 事件类型
 * @param {Function} listener 需要添加的监听器
 * @remark
 * 
1. 不支持跨浏览器的鼠标滚轮事件监听器添加<br>
2. 改方法不为监听器灌入事件对象，以防止跨iframe事件挂载的事件对象获取失败
		
 * @shortcut on
 * @meta standard
 * @see baidu.event.un
 *             
 * @returns {HTMLElement|window} 目标元素
 */
baidu.event.on = function (element, type, listener) {
    type = type.replace(/^on/i, '').toLowerCase();
    element = baidu.dom._g(element);
    var realListener = function (ev) {
            // 1. 这里不支持EventArgument,  原因是跨frame的时间挂载
            // 2. element是为了修正this
            listener.call(element, ev);
        },
        lis = baidu.event._listeners,
        filter = baidu.event._eventFilter,
        afterFilter,
        realType = type;
    // filter过滤
    if(filter && filter[type]){
    	afterFilter = filter[type](element, type, realListener);
    	realType = afterFilter.type;
    	realListener = afterFilter.listener;
    }
    
    // 事件监听器挂载
    if (element.addEventListener) {
		element.addEventListener(realType, realListener, false);
    } else if (element.attachEvent) {
        element.attachEvent('on' + realType, realListener);
    }
	// 将监听器存储到数组中
    lis[lis.length] = [element, type, listener, realListener, realType];
    return element;
};

// 声明快捷方法
baidu.on = baidu.event.on;
