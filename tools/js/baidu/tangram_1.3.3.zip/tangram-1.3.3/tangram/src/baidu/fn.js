/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 *
 * path: baidu/fn.js
 * author: berg
 * version: 1.0.0
 * date: 2010/11/02
 */

///import baidu;
/**
 * @namespace baidu.fn 对方法的操作，解决内存泄露问题。
 */
baidu.fn = baidu.fn || {};
