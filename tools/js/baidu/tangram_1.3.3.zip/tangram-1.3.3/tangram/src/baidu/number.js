/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/number.js
 * author: erik
 * version: 1.1.0
 * date: 2009/12/2
 */

///import baidu;
/**
 * @namespace baidu.number 操作number的方法。
 */
baidu.number = baidu.number || {};
