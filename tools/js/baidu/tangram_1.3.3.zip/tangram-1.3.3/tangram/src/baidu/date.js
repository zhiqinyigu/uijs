/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/date.js
 * author: erik
 * version: 1.1.0
 * date: 2009/12/04
 */

///import baidu;
/**
 * @namespace baidu.date 操作日期的方法。
 */
baidu.date = baidu.date || {};
