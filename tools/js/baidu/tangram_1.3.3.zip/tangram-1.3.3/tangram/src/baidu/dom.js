/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/dom.js
 * author: allstar, erik
 * version: 1.1.0
 * date: 2009/12/02
 */

///import baidu;
/**
 * @namespace baidu.dom 操作dom的方法。
 */
baidu.dom = baidu.dom || {};
