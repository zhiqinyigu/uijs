/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/lang/module.js
 * author: erik, berg
 * version: 1.1.1
 * date: 2010-04-19
 */

///import baidu.lang;

/**
 * 增加自定义模块扩展,默认创建在当前作用域
 * @name baidu.lang.module
 * @function
 * @grammar baidu.lang.module(name, module[, owner])
 * @param {string} name 需要创建的模块名
 * @param {Any} module 需要创建的模块对象
 * @param {Object} [owner] 模块创建的目标环境，默认为window
 * @remark
 * 
            从1.1.1开始，module方法会优先在当前作用域下寻找模块，如果无法找到，则寻找window下的模块
	
 * @meta standard
 */
baidu.lang.module = function (name, module, owner) {
    var packages = name.split('.'), 
        len = packages.length - 1,
        packageName, i = 0;        

    //如果没有owner，找当前作用域，如果当前作用域没有此变量，在window创建
    
    if(!owner){
        try{
            if(!(new RegExp("^[a-zA-Z_\x24][a-zA-Z0-9_\x24]*\x24")).test(packages[0])){
                throw "";
            }
            owner = eval(packages[0]);
            i=1;
        }catch(e){
            owner = window;
        }
    }/*else{
        i = 0;
    }*/
        
    for (; i < len; i++) {
        packageName = packages[i];
        if (!owner[packageName]) {
            owner[packageName] = {};
        }
        owner = owner[packageName];
    }
    
    if (!owner[packages[len]]) {
        owner[packages[len]] = module;
    }
};
