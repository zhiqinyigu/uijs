/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/json.js
 * author: erik
 * version: 1.1.0
 * date: 2009/12/02
 */

///import baidu;
/**
 * @namespace baidu.json 操作json对象的方法。
 */
baidu.json = baidu.json || {};
