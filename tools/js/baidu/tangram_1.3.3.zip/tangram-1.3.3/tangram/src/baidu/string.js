/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/string.js
 * author: erik
 * version: 1.1.0
 * date: 2009/11/15
 */

///import baidu;
/**
 * @namespace baidu.string 操作字符串的方法。
 */
baidu.string = baidu.string || {};
